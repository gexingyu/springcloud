package com.ule.wholesale.common.filter;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 通过Filter过滤器来防SQL注入攻击
 * 
 */
public class SQLAndXssFilter implements Filter {
	private static Logger logger = LoggerFactory.getLogger(SQLAndXssFilter.class);
	
	private static List<Pattern> patterns = null;

    private static List<Object[]> getXssPatternList() {
        List<Object[]> ret = new ArrayList<Object[]>();
        ret.add(new Object[]{"<(no)?script[^>]*>.*?</(no)?script>", Pattern.CASE_INSENSITIVE});
        ret.add(new Object[]{"eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL});
        ret.add(new Object[]{"expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL});
        ret.add(new Object[]{"(javascript:|vbscript:|view-source:)+", Pattern.CASE_INSENSITIVE});
        ret.add(new Object[]{"<(\"[^\"]*\"|\'[^\']*\'|[^\'\">])*>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL});
        ret.add(new Object[]{"(window\\.location|document\\.cookie|document\\.|alert\\(.*?\\)|window\\.open\\()+", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL});
        ret.add(new Object[]{"<+\\s*(oncontrolselect|oncopy|oncut|ondataavailable|ondatasetchanged|ondatasetcomplete|ondblclick|ondeactivate|ondrag|ondragend|ondragenter|ondragleave|ondragover|ondragstart|ondrop|onerror=|onerroupdate|onfilterchange|onfinish|onfocus|onfocusin|onfocusout|onhelp|onkeydown|onkeypress|onkeyup|onlayoutcomplete|onload|onlosecapture|onmousedown|onmouseenter|onmouseleave|onmousemove|onmousout|onmouseover|onmouseup|onmousewheel|onmove|onmoveend|onmovestart|onabort|onactivate|onafterprint|onafterupdate|onbefore|onbeforeactivate|onbeforecopy|onbeforecut|onbeforedeactivate|onbeforeeditocus|onbeforepaste|onbeforeprint|onbeforeunload|onbeforeupdate|onblur|onbounce|oncellchange|onchange|onclick|oncontextmenu|onpaste|onpropertychange|onreadystatechange|onreset|onresize|onresizend|onresizestart|onrowenter|onrowexit|onrowsdelete|onrowsinserted|onscroll|onselect|onselectionchange|onselectstart|onstart|onstop|onsubmit|onunload)+\\s*=+", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL});
        return ret;
    }
    private static List<Pattern> getPatterns() {
        if (patterns == null) {
            List<Pattern> list = new ArrayList<Pattern>();
            String regex = null;
            Integer flag = null;
            int arrLength = 0;
            for(Object[] arr : getXssPatternList()) {
                arrLength = arr.length;
                for(int i = 0; i < arrLength; i++) {
                    regex = (String)arr[0];
                    flag = (Integer)arr[1];
                    list.add(Pattern.compile(regex, flag));
                }
            }
            patterns = list;
        }
        return patterns;
    }

    public static boolean stripXssCheck(String value) {
        if(StringUtils.isNotBlank(value)) {

            Matcher matcher = null;

            for(Pattern pattern : getPatterns()) {
                matcher = pattern.matcher(value);
                // 匹配
                if(matcher.find()) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public static String stripXss(String value) {
        if(StringUtils.isNotBlank(value)) {

            Matcher matcher = null;

            for(Pattern pattern : getPatterns()) {
                matcher = pattern.matcher(value);
                // 匹配
                if(matcher.find()) {
                    // 删除相关字符串
                    value = matcher.replaceAll("");
                }
            }
            value = value.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
        }
        return value;
    }
    
    //效验 替换参数中的sql关键字
    public static String replaceSqlWord(String str) {
            str = str.toLowerCase();//统一转为小写
            String badStr = "'|and|exec|execute|insert|drop|table|from|grant|group_concat|column_name|frame|iframe|script|" +
                    "information_schema.columns|table_schema|union|where|select|delete|update|" +
                    "chr|mid|master|truncate|declare|like|#|<|>";//|//|/|--|+|\\|$|!|?";//过滤掉的sql关键字，可以手动添加
            
            Pattern pattern = Pattern.compile("\\s{1,}"+badStr+"\\s{1,}");
            Matcher matcher = pattern.matcher(str);
            if(matcher.find()){
            	return matcher.replaceAll("");
            }
            return str;
    }
	
	/**
	 * 
	 */
	public void destroy() {

	}
	
//	@SuppressWarnings("rawtypes")
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    	logger.info("ParameterRequestWrapper xss 过滤");
//		try{
	        HttpServletRequest req = (HttpServletRequest) request;
	        
	        req.setCharacterEncoding("UTF-8");
	        
	        if(req.getQueryString()!=null){
	        	URLDecoder.decode( req.getQueryString(), "UTF-8");
	        }
//	        HttpServletResponse res = (HttpServletResponse) response;
	        
	        ParameterRequestWrapper requestWrapper = new ParameterRequestWrapper(req);
	        chain.doFilter(requestWrapper, response);
	        //获得所有请求参数名
//	        Enumeration params = req.getParameterNames();
//	        String sql = "";
//	        boolean b = false;
	        //logger.info("遍历参数列表：");
//	        loop1:while (params.hasMoreElements()) {
//	             //得到参数名
//	             String name = params.nextElement().toString();
////	             logger.info("参数名称name="+name);
//	             //得到参数对应值
//	        	 String[] value = req.getParameterValues(name);
////	        	 logger.info("参数值value="+value);
//	        	 if(value != null && value.length > 0)
//	             for (int i = 0; i < value.length; i++) {
//	            	 if(StringUtils.isNotBlank(value[i])){
//	            	     //过滤XSS脚本注入
//	            		 if(stripXssCheck(value[i])){
//	            			 b = true;
//	            			 break loop1;
////	            		     value[i] = XssShieldUtil.stripXss(value[i]);
//	            		 }else
//	            		 sql = sql + value[i]+" "+name+" ";
//	            	 }
//	            	 if(b){
//	            	     break;
//	            	 }
//	             }
//	        }
	        //有sql关键字，跳转到error.html
//	        if (b) {
//	            //res.sendRedirect(req.getRequestURL()+"");
//	            HttpServletResponse httpResponse = (HttpServletResponse) response;
//	            httpResponse.setCharacterEncoding("UTF-8");
//				httpResponse.reset();
//				httpResponse.resetBuffer();
//				response.setContentType("text/html;charset=UTF-8");
//				PrintWriter printWriter = httpResponse.getWriter();
//				printWriter.println("<html>");
//				printWriter.println("<head><title></title></head>");
//				printWriter.println("<body>");
//				printWriter.println("<SCRIPT LANGUAGE=\"JavaScript\">");
//				printWriter.println("alert('查询字符串存在非法字符!');");
//				printWriter.println("var currentWindow = window;");
//				printWriter.println("if(currentWindow != null){");
//				printWriter.println(" location= \"logoutAction.action\";");
//				printWriter.println("}");
//				printWriter.println("</SCRIPT>");
//				printWriter.println("</body>");
//				printWriter.println("</html>");
//				printWriter.flush();
//				printWriter.close();
//	        } else {
//	            chain.doFilter(req, res);
//	        }
//		}catch(Exception ex){
//		    logger.error("SQLFilter doFilter error:"+ex.getMessage());
//			ex.printStackTrace();
//		}
    }

	public void init(FilterConfig arg0) throws ServletException {
	}
}
