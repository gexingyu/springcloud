package com.ule.wholesale.common.util;


import java.math.BigDecimal;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MD5Tools
{

  private final static Log log = LogFactory.getLog(MD5Tools.class);

  public static String getSysDate(String dateFormat)
  {
    if(dateFormat == null || "".equals(dateFormat))
    {
      dateFormat = "yyyy-MM-dd HH:mm:ss";
    }
    Calendar date = Calendar.getInstance();
    SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
    String dateStr = sdf.format(date.getTime());
    return dateStr;
  }

  public static String getFileName()
  {
    return String.valueOf(System.currentTimeMillis());
  }
  public static Date getSysDate()
  {
    java.util.Date utilDate = new Date();
    return utilDate;
  }

  public static Date getBeforeOrBehindDateofCurrentDate(final int i)
  {
    GregorianCalendar g = new GregorianCalendar();
    g.add(Calendar.DATE, i);
    return g.getTime();
  }

 
  

 
  public static String getOSFileSeparator()
  {
    return "/".equals(System.getProperty("file.separator")) ? "/" : "\\\\";
  }

  
 
  /**
   */
  public static void loadErrorInfos()
  {
  }

  /**
   * 
   * @param password
   */
  public final static String getMD5Password(final String password)
  {
    char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a',
        'b', 'c', 'd', 'e', 'f'};
    try
    {
      byte[] strTemp = password.getBytes();
      MessageDigest mdTemp = MessageDigest.getInstance("MD5");
      mdTemp.update(strTemp);
      byte[] md = mdTemp.digest();
      int j = md.length;
      char str[] = new char[j * 2];
      int k = 0;
      for(int i = 0; i < j; i++)
      {
        byte byte0 = md[i];
        str[k++] = hexDigits[byte0 >>> 4 & 0xf];
        str[k++] = hexDigits[byte0 & 0xf];
      }
      return new String(str);
    }
    catch(Exception e)
    {
      log.error("User " + password + " MD5 password make error. message is: "
          + e);
      return null;
    }
  }

  /**
   * 
   */
  public static String getActiveCodeByUsername(final String username)
  {
    if("".equals(username))
    {
      return null;
    }
    String md5un = getMD5Password(username);
    if("".equals(md5un))
    {
      return null;
    }
    return md5un.substring(md5un.length() - 6, md5un.length());
  }


  /**
   * 
   * @param date
   */
  public static int getYear(final Date date)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    return c.get(Calendar.YEAR);
  }

  /**
   * 
   * @param date
   */
  public static int getMonth(final Date date)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    return c.get(Calendar.MONTH) + 1;
  }

  /**
   * 
   * @param date
   */
  public static int getDay(final Date date)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    return c.get(Calendar.DATE);
  }

  /**
   * 
   * @param date
   */
  public static int getHour(final Date date)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    return c.get(Calendar.HOUR);
  }

  public static int getMinute(final Date date)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    return c.get(Calendar.MINUTE);
  }

  public static int getSecond(final Date date)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    return c.get(Calendar.SECOND);
  }

  public static Integer getYearMonth(final Date date)
  {
    return new Integer(format(date, "yyyyMM"));
  }

  
  public static Date addYear(final Date date, final int ammount)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    c.add(Calendar.YEAR, ammount);
    return c.getTime();
  }

  public static Date addHour(final Date date, final int ammount)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    c.add(Calendar.HOUR, ammount);
    return c.getTime();
  }

  public static Date addMin(final Date date, final int ammount)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    c.add(Calendar.MINUTE, ammount);
    return c.getTime();
  }

  /**
   * 
   * @param date
   * @param ammount
   */
  public static Date addMonth(final Date date, final int ammount)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    c.add(Calendar.MONTH, ammount);
    return c.getTime();
  }

  /**
   * 
   * @param date
   * @param ammount
   */
  public static Date addDay(final Date date, final int ammount)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    c.add(Calendar.DATE, ammount);
    return c.getTime();
  }

 
  /**
   * 
   * @param beforeDate
   * @param afterDate
   */
  public static int beforeYears(final Date beforeDate, final Date afterDate)
  {
    Calendar beforeCalendar = Calendar.getInstance();
    beforeCalendar.setTime(beforeDate);
    beforeCalendar.set(Calendar.MONTH, 1);
    beforeCalendar.set(Calendar.DATE, 1);
    beforeCalendar.set(Calendar.HOUR, 0);
    beforeCalendar.set(Calendar.SECOND, 0);
    beforeCalendar.set(Calendar.MINUTE, 0);
    Calendar afterCalendar = Calendar.getInstance();
    afterCalendar.setTime(afterDate);
    afterCalendar.set(Calendar.MONTH, 1);
    afterCalendar.set(Calendar.DATE, 1);
    afterCalendar.set(Calendar.HOUR, 0);
    afterCalendar.set(Calendar.SECOND, 0);
    afterCalendar.set(Calendar.MINUTE, 0);
    boolean positive = true;
    if(beforeDate.after(afterDate))
      positive = false;
    int beforeYears = 0;
    while(true)
    {
      boolean yearEqual = beforeCalendar.get(Calendar.YEAR) == afterCalendar
          .get(Calendar.YEAR);
      if(yearEqual)
      {
        break;
      }
      else
      {
        if(positive)
        {
          beforeYears++;
          beforeCalendar.add(Calendar.YEAR, 1);
        }
        else
        {
          beforeYears--;
          beforeCalendar.add(Calendar.YEAR, -1);
        }
      }
    }
    return beforeYears;
  }

  /**
   * 
   * @param beforeDate
   * @param afterDate
   */
  public static int beforeMonths(final Date beforeDate, final Date afterDate)
  {
    Calendar beforeCalendar = Calendar.getInstance();
    beforeCalendar.setTime(beforeDate);
    beforeCalendar.set(Calendar.DATE, 1);
    beforeCalendar.set(Calendar.HOUR, 0);
    beforeCalendar.set(Calendar.SECOND, 0);
    beforeCalendar.set(Calendar.MINUTE, 0);
    Calendar afterCalendar = Calendar.getInstance();
    afterCalendar.setTime(afterDate);
    afterCalendar.set(Calendar.DATE, 1);
    afterCalendar.set(Calendar.HOUR, 0);
    afterCalendar.set(Calendar.SECOND, 0);
    afterCalendar.set(Calendar.MINUTE, 0);
    boolean positive = true;
    if(beforeDate.after(afterDate))
      positive = false;
    int beforeMonths = 0;
    while(true)
    {
      boolean yearEqual = beforeCalendar.get(Calendar.YEAR) == afterCalendar
          .get(Calendar.YEAR);
      boolean monthEqual = beforeCalendar.get(Calendar.MONTH) == afterCalendar
          .get(Calendar.MONTH);
      if(yearEqual && monthEqual)
      {
        break;
      }
      else
      {
        if(positive)
        {
          beforeMonths++;
          beforeCalendar.add(Calendar.MONTH, 1);
        }
        else
        {
          beforeMonths--;
          beforeCalendar.add(Calendar.MONTH, -1);
        }
      }
    }
    return beforeMonths;
  }

  /**
   * 
   * @param beforeDate
   * @param afterDate
   */
  public static int beforeDays(final Date beforeDate, final Date afterDate)
  {
    Calendar beforeCalendar = Calendar.getInstance();
    beforeCalendar.setTime(beforeDate);
    beforeCalendar.set(Calendar.HOUR, 0);
    beforeCalendar.set(Calendar.SECOND, 0);
    beforeCalendar.set(Calendar.MINUTE, 0);
    Calendar afterCalendar = Calendar.getInstance();
    afterCalendar.setTime(afterDate);
    afterCalendar.set(Calendar.HOUR, 0);
    afterCalendar.set(Calendar.SECOND, 0);
    afterCalendar.set(Calendar.MINUTE, 0);
    boolean positive = true;
    if(beforeDate.after(afterDate))
      positive = false;
    int beforeDays = 0;
    while(true)
    {
      boolean yearEqual = beforeCalendar.get(Calendar.YEAR) == afterCalendar
          .get(Calendar.YEAR);
      boolean monthEqual = beforeCalendar.get(Calendar.MONTH) == afterCalendar
          .get(Calendar.MONTH);
      boolean dayEqual = beforeCalendar.get(Calendar.DATE) == afterCalendar
          .get(Calendar.DATE);
      if(yearEqual && monthEqual && dayEqual)
      {
        break;
      }
      else
      {
        if(positive)
        {
          beforeDays++;
          beforeCalendar.add(Calendar.DATE, 1);
        }
        else
        {
          beforeDays--;
          beforeCalendar.add(Calendar.DATE, -1);
        }
      }
    }
    return beforeDays;
  }

  /**
   * 
   * @param beforeDate
   * @param afterDate
   */
  public static int beforeRoundYears(final Date beforeDate, final Date afterDate)
  {
    Date bDate = beforeDate;
    Date aDate = afterDate;
    boolean positive = true;
    if(beforeDate.after(afterDate))
    {
      positive = false;
      bDate = afterDate;
      aDate = beforeDate;
    }
    int beforeYears = beforeYears(bDate, aDate);

    int bMonth = getMonth(bDate);
    int aMonth = getMonth(aDate);
    if(aMonth < bMonth)
    {
      beforeYears--;
    }
    else if(aMonth == bMonth)
    {
      int bDay = getDay(bDate);
      int aDay = getDay(aDate);
      if(aDay < bDay)
      {
        beforeYears--;
      }
    }

    if(positive)
    {
      return beforeYears;
    }
    else
    {
      return new BigDecimal(beforeYears).negate().intValue();
    }
  }

  /**
   * 
   * @param beforeDate
   * @param afterDate
   */
  public static int beforeRoundAges(final Date beforeDate, final Date afterDate)
  {
    Date bDate = beforeDate;
    Date aDate = afterDate;
    boolean positive = true;
    if(beforeDate.after(afterDate))
    {
      positive = false;
      bDate = afterDate;
      aDate = beforeDate;
    }
    int beforeYears = beforeYears(bDate, aDate);

    int bMonth = getMonth(bDate);
    int aMonth = getMonth(aDate);
    if(aMonth < bMonth)
    {
      beforeYears--;
    }

    if(positive)
    {
      return beforeYears;
    }
    else
    {
      return new BigDecimal(beforeYears).negate().intValue();
    }
  }

  /**
   * @param beforeDate
   * @param afterDate
   */
  public static int beforeRoundMonths(final Date beforeDate,
      final Date afterDate)
  {
    Date bDate = beforeDate;
    Date aDate = afterDate;
    boolean positive = true;
    if(beforeDate.after(afterDate))
    {
      positive = false;
      bDate = afterDate;
      aDate = beforeDate;
    }
    int beforeMonths = beforeMonths(bDate, aDate);

    int bDay = getDay(bDate);
    int aDay = getDay(aDate);
    if(aDay < bDay)
    {
      beforeMonths--;
    }

    if(positive)
    {
      return beforeMonths;
    }
    else
    {
      return new BigDecimal(beforeMonths).negate().intValue();
    }
  }

  public static Date getDate(final int year, final int month, final int date)
  {
    Calendar c = Calendar.getInstance();
    c.set(year + 1900, month, date);
    return c.getTime();
  }

  public static String format(final Date date, final String pattern)
  {
    DateFormat df = new SimpleDateFormat(pattern);
    return df.format(date);
  }

  
  public static boolean isYearMonth(final Integer yearMonth)
  {
    String yearMonthStr = yearMonth.toString();
    return isYearMonth(yearMonthStr);
  }

  public static boolean isYearMonth(final String yearMonthStr)
  {
    if(yearMonthStr.length() != 6)
      return false;
    else
    {
      String yearStr = yearMonthStr.substring(0, 4);
      String monthStr = yearMonthStr.substring(4, 6);
      try
      {
        int year = Integer.parseInt(yearStr);
        int month = Integer.parseInt(monthStr);
        if(year < 1800 || year > 3000)
        {
          return false;
        }
        if(month < 1 || month > 12)
        {
          return false;
        }
        return true;
      }
      catch(Exception e)
      {
        return false;
      }
    }
  }

 
  public static String getRandomString(int length)
  {
    length = length > 0 ? length : 6;
    char[] randchars = new char[length];
    String randstring = "23456789ABCDEFGHIJKLMNPQRSTUVWXYZabcdefghigkmnpqrstuvwxyz";
    Random rd = new Random();
    // return String.valueOf(randstring.charAt(num));
    for(int i = 0; i < length; i++)
    {
      randchars[i] = randstring.charAt(rd.nextInt(57));
    }
    return new String(randchars);
  }

  public static boolean isEmpty(String s)
  {
    if("".equals(s))
    {
      return true;
    }
    if(s == null)
    {
      return true;
    }
    if("0".equals(s))
    {
      return true;
    }
    return false;
  }



  public static String decimalToBinary(String x)
  {

    if(x == null || x.equals(""))
    {
      x = "0";
    }
    String[] str = {"0", "0", "0", "0", "0"};
    int a = 0;
    String s = "";
    int i = Integer.parseInt(x);
    for(a = 0; a < str.length; a++)
    {

      int j = i % 2;
      if(j == 1)
      {
        str[4 - a] = "1";
        i = (i - 1) / 2;
        System.out.println("------str[4]--------" + str[4]);
      }
      else
      {
        i = i / 2;
      }
    }
    for(a = 0; a < str.length; a++)
    {
      s += str[a];
    }
    return s;
  }
  
  /**
   * 验证加密算法
   * @param plainText
   * @return
   */
  public final static String md5(String plainText) {

      // 返回字符串
      String md5Str = null;
      try {
       // 操作字符串
       StringBuffer buf = new StringBuffer();

      /**
       * MessageDigest 类为应用程序提供信息摘要算法的功能，如 MD5 或 SHA 算法。
       * 信息摘要是安全的单向哈希函数，它接收任意大小的数据，并输出固定长度的哈希值。
       * 
       * MessageDigest 对象开始被初始化。
       * 该对象通过使用 update()方法处理数据。
       * 任何时候都可以调用 reset()方法重置摘要。
       * 一旦所有需要更新的数据都已经被更新了，应该调用digest()方法之一完成哈希计算。 
       * 
       * 对于给定数量的更新数据，digest 方法只能被调用一次。
       * 在调用 digest 之后，MessageDigest 对象被重新设置成其初始状态。
       */ 
       MessageDigest md = MessageDigest.getInstance("MD5");
      
       // 添加要进行计算摘要的信息,使用 plainText 的 byte 数组更新摘要。
       md.update(plainText.getBytes());

       // 计算出摘要,完成哈希计算。
       byte b[] = md.digest();
       int i;

       for (int offset = 0; offset < b.length; offset++) {

        i = b[offset];

        if (i < 0) {
         i += 256;
        }

        if (i < 16) {
         buf.append("0");
        }

        // 将整型 十进制 i 转换为16位，用十六进制参数表示的无符号整数值的字符串表示形式。
        buf.append(Integer.toHexString(i));

       }

       // 32位的加密
       //md5Str = buf.toString();

       // 16位的加密
        md5Str = buf.toString().substring(8,24);

      } catch (Exception e) {
       e.printStackTrace();
      }
      return md5Str;
   }
 

}
