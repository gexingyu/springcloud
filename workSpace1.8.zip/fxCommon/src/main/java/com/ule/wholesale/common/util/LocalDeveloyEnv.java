package com.ule.wholesale.common.util;


public class LocalDeveloyEnv {
	private final static String dev =System.getProperty("spring.profiles.active");
	public final static boolean isDev =(dev != null) && ("dev".equalsIgnoreCase(dev.trim()));
}
