package com.ule.wholesale.common.constants;


public enum FxPurchaseStateEnum {
	//操作日志类型枚举类型
	OPLOG_TYPE_1("供应商",1),
	OPLOG_TYPE_2("合同",2),
	OPLOG_TYPE_3("合同变更",3),
	OPLOG_TYPE_4("采购订单",4),
	OPLOG_TYPE_5("采购退货单",5),
	OPLOG_TYPE_6("批发单",6),
	OPLOG_TYPE_7("批发退货单",7),
	
	//供应商状态枚举值
	STATE_SUPPLIER_0("保存",0),
	STATE_SUPPLIER_1("保存并提交",1),
	STATE_SUPPLIER_2("审核通过",2),
	STATE_SUPPLIER_3("审核不通过",3),
	//合同状态
	STATE_CONTRACT_0("保存",0),
	STATE_CONTRACT_0_0("编辑",0),
	STATE_CONTRACT_0_1("提交",1),
	STATE_CONTRACT_0_2("删除",1),
	STATE_CONTRACT_1("保存并提交",1),
	STATE_CONTRACT_2("采购经理审核通过",2),
	STATE_CONTRACT_3("采购经理审核不通过",3),
	STATE_CONTRACT_4("财务审核通过",4),
	STATE_CONTRACT_5("财务审核不通过",5),
	STATE_CONTRACT_6("法务审核通过",6),
	STATE_CONTRACT_7("法务审核不通过",7),
	STATE_CONTRACT_8("作废",8),
	//合同变更状态
	STATE_CONTRACT_CHANGE_0("保存",0),
	STATE_CONTRACT_CHANGE_0_0("编辑",0),
	STATE_CONTRACT_CHANGE_0_1("提交",1),
	STATE_CONTRACT_CHANGE_0_2("删除",1),
	STATE_CONTRACT_CHANGE_1("保存并提交",1),
	STATE_CONTRACT_CHANGE_2("审核通过",2),
	STATE_CONTRACT_CHANGE_3("审核不通过",3),
	//采购订货和退货订单状态
	STATE_ORDER_0("未提交",0),
	STATE_ORDER_1("已提交",1),
	STATE_ORDER_2("审核通过",2),
	STATE_ORDER_3("审核不通过",3),
	STATE_ORDER_8("已收货",8),
	STATE_ORDER_8_1("已发货",8),
	STATE_ORDER_9("已作废",9),
	//采购订货和退货订单按钮名称
	STATE_ORDER_BTN_0("保存",0),
	STATE_ORDER_BTN_0_0("编辑",0),
	STATE_ORDER_BTN_0_1("提交",0),
	STATE_ORDER_BTN_0_2("删除",0),
	STATE_ORDER_BTN_1("保存并提交",1),
	STATE_ORDER_BTN_2("审核通过",2),
	STATE_ORDER_BTN_2_0("打印",2),
	STATE_ORDER_BTN_3("审核不通过",3),
	STATE_ORDER_BTN_9("作废",9),
	STATE_ORDER_BTN_10("支付预付款",10),
	
	//权限按钮--------------------------begin
	//供应商
	SUPPLIER_ADD("新建【供应商】",1),
	SUPPLIER_EDIT("编辑【供应商】",2),
	SUPPLIER_SUBMIT("提交【供应商】",3),
	SUPPLIER_DEL("删除【供应商】",4),
	SUPPLIER_AUDIT("审核【供应商】",5),
	SUPPLIER_ANO_EDIT("特殊编辑【供应商】",6),
	//合同
	CONTRACT_ADD("新建【合同】",1),
	CONTRACT_EDIT("编辑【合同】",2),
	CONTRACT_SUBMIT("提交【合同】",3),
	CONTRACT_DEL("删除【合同】",4),
	CONTRACT_PURCHASE_AUDIT("采购审核【合同】",5),
	CONTRACT_FINANCIAL_AUDIT("财务审核【合同】",6),
	CONTRACT_LAW_AUDIT("法务审核【合同】",7),
	CONTRACT_CANCEL("作废【合同】",8),
	CONTRACT_CHANGE("变更【合同】",9),
	//合同变更
	CHANGE_SUBMIT("提交【变更】",1),
	CHANGE_EDIT("编辑【变更】",2),
	CHANGE_DEL("删除【变更】",3),
	CHANGE_AUDIT("审核【变更】",4),
	//订单
	ORDER_ADD("新建【订单】",1),
	ORDER_SUBMIT("提交【订单】",2),
	ORDER_EDIT("编辑【订单】",3),
	ORDER_DEL("删除【订单】",4),
	ORDER_AUDIT("审核【订单】",5),
	ORDER_CANCEL("作废【订单】",6),
	ORDER_PRINT("打印【订单】",7),
	ORDER_PAY("支付预付款【订单】",8),
	ORDER_RECEPT("确认收货【订单】",9),
	//退单
	RETURN_ORDER_ADD("新建【退单】",1),
	RETURN_ORDER_SUBMIT("提交【退单】",2),
	RETURN_ORDER_EDIT("编辑【退单】",3),
	RETURN_ORDER_DEL("删除【退单】",4),
	RETURN_ORDER_AUDIT("审核【退单】",5),
	RETURN_ORDER_CANCEL("作废【退单】",6),
	RETURN_ORDER_PRINT("打印【退单】",7),
	//机构
	AGENCY_ADD("新建【机构】",1),
	AGENCY_EDIT("编辑【机构】",2),
	AGENCY_OPER("启用停用【机构】",3),
	//商品对照
	GOODS_COMPARE_ADD("新建【对照】",1),
	GOODS_COMPARE_EDIT("编辑【对照】",2),
	GOODS_COMPARE_DEL("删除【对照】",3),
	//批发单
	WHORDER_ADD("新建【批发单】",1),
	WHORDER_SUBMIT("提交【批发单】",2),
	WHORDER_EDIT("编辑【批发单】",3),
	WHORDER_DEL("删除【批发单】",4),
	WHORDER_AUDIT("审核【批发单】",5),
	WHORDER_CANCEL("作废【批发单】",6),
	//批发退货单
	WHRETURN_ORDER_ADD("新建【批发退单】",1),
	WHRETURN_ORDER_SUBMIT("提交【批发退单】",2),
	WHRETURN_ORDER_EDIT("编辑【批发退单】",3),
	WHRETURN_ORDER_DEL("删除【批发退单】",4),
	WHRETURN_ORDER_AUDIT("审核【批发退单】",5),
	WHRETURN_ORDER_CANCEL("作废【批发退单】",6),
	//-----------------------------------end
	//合同变更类型
	CONTRACT_CHANGE_TYPE_1("基本信息变更",1),
	CONTRACT_CHANGE_TYPE_2("账户变更",2),
	CONTRACT_CHANGE_TYPE_3("商品价格变更",3),
	CONTRACT_CHANGE_TYPE_4("终止商品",4),
	CONTRACT_CHANGE_TYPE_5("结算变更",5),
	//合同结算 帐期类型
	STATE_PERPAYTYPE_0("固定日期月结",0),
	STATE_PERPAYTYPE_1("自然月结",1),
	STATE_PERPAYTYPE_2("按单结",2),
	STATE_PERPAYTYPE_3("手工结账",3),
	//批发机构状态
	STATE_AGENCY_0("启用",0),
	STATE_AGENCY_1("停用",1),
	//批发单来源
	SOURCE_TYPE_0("手工新建",0),
	SOURCE_TYPE_1("要货清单",1),
	
	//批发单和批发退货单状态
	WHOLESALE_ORDER_0("未提交",0),
	WHOLESALE_ORDER_1("已提交",1),
	WHOLESALE_ORDER_2("审核通过",2),
	WHOLESALE_ORDER_3("审核不通过",3),
	WHOLESALE_ORDER_7("已发货",7),
	WHOLESALE_ORDER_8("已收货",8),
	WHOLESALE_ORDER_9("已作废",9),
	
	//批发单和批发退货单按钮名称
	WHOLESALE_ORDER_BTN_0("保存",0),
	WHOLESALE_ORDER_BTN_0_0("编辑",0),
	WHOLESALE_ORDER_BTN_0_1("提交",0),
	WHOLESALE_ORDER_BTN_0_2("删除",0),
	WHOLESALE_ORDER_BTN_1("保存并提交",1),
	WHOLESALE_ORDER_BTN_2("审核通过",2),
	WHOLESALE_ORDER_BTN_2_0("打印",2),
	WHOLESALE_ORDER_BTN_3("审核不通过",3),
	WHOLESALE_ORDER_BTN_9("作废",9),
	WHOLESALE_ORDER_BTN_10("支付预付款",10),
	//要货清单状态
	REQUIRE_STATUS_0("未分配",0),
	REQUIRE_STATUS_1("已分配",1),
	REQUIRE_STATUS_2("已完成",2),
	REQUIRE_STATUS_3("已作废",3);
	
	
	
	
	
	
	
	
	
	
	
	
	// 成员变量  
    private String name;  
    private int index; 
    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	// 构造方法  
    private FxPurchaseStateEnum(String name, int index) {  
        this.name = name;  
        this.index = index;  
    }
    
//    private String getName(FxPurchaseStateEnum stateEnum){
//		return name;
//    }
}
//class Test{
//	public static void main(String[] args) {
//		System.out.println(FxPurchaseStateEnum.STATE_SUPPLIER_0.getIndex());
//		System.out.println(FxPurchaseStateEnum.STATE_SUPPLIER_0.getName());
//	}
//}
