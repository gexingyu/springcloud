package com.ule.wholesale.common.util;

import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

public class DataUtil {

	public  static String parseString(HttpServletRequest request,String key){
		Object str = request.getParameter(key);
		if( str != null && !"".equals(str.toString())){
			return str.toString().trim();
		}
		else{
			return "";
		}
	}
	
	public  static Long parseLong(HttpServletRequest request,String key){
		Object str = request.getParameter(key);
		if( str != null && !"".equals(str.toString())){
			return Long.parseLong(str.toString());
		}
		else{
			return null;
		}
	}
	
	public  static Double parseDouble(HttpServletRequest request,String key){
		Object str = request.getParameter(key);
		if( str != null && !"".equals(str.toString())){
			return Double.parseDouble(str.toString());
		}
		else{
			return null;
		}
	}
	
	public  static Integer parseInt(HttpServletRequest request,String key){
		Object str = request.getParameter(key);
		if( str != null && !"".equals(str.toString())){
			return Integer.parseInt(str.toString());
		}
		else{
			return null;
		}
	}
	
	public static Short parseShort(HttpServletRequest request,String key){
		Object str = request.getParameter(key);
		if( str != null && !"".equals(str.toString())){
			return Short.parseShort(str.toString());
		}else{
			return null;
		}
	}
	
	public  static Integer parseInt(Object str){
		if(!isNumber(str.toString()))
			return null;
		if( str != null && !"".equals(str.toString())){
			return Integer.parseInt(str.toString());
		}
		else{
			return null;
		}
	}
	
	public static boolean isNumber(String str){
		Pattern pattern = Pattern.compile("[0-9]*");
		return pattern.matcher(str).matches(); 
	}
	
	/**
	 * 汉字转换成拼音
	 * @param input
	 * @return
	 */
	public static String toPinyin(String input) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < input.length(); i++) {
			char c = input.charAt(i);
			if (c <= 255) {
				sb.append(c);
			} else {
				String pinyin = null;
				try {
					String[] pinyinArray = PinyinHelper.toHanyuPinyinStringArray(c, PINYIN_FORMAT);
					pinyin = pinyinArray[0];
				} catch (BadHanyuPinyinOutputFormatCombination e) {
					e.printStackTrace();
				} catch (NullPointerException e) {
					e.printStackTrace();
				}
				if (pinyin != null) {
					sb.append(pinyin);
				}
			}
		}
		return sb.toString();
	}
	
	private static HanyuPinyinOutputFormat PINYIN_FORMAT = new HanyuPinyinOutputFormat();
	
	static {
		PINYIN_FORMAT.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
		PINYIN_FORMAT.setVCharType(HanyuPinyinVCharType.WITH_V);	
	}
	
	 public static String ToDBC(String input)
     {
         char[] c=input.toCharArray();
         for (int i = 0; i < c.length; i++)
         {
             if (c[i]==12288)
             {
                 c[i]= (char)32;
                 continue;
             }
             if (c[i]>65280 && c[i]<65375)
                 c[i]=(char)(c[i]-65248);
         }
         return new String(c);
     }
}
