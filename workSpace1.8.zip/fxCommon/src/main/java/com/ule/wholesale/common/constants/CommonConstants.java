package com.ule.wholesale.common.constants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;

//@Component
@PropertySource("classpath:platfrom-properties.yml")
@ConfigurationProperties(prefix="commom")
public class CommonConstants{
	
	public static String uploadTempDir;
	public static String uploadFileToDFSUrl;
	public static String uploadFileUrl;
	public static String globalStaticServer1;
	public static String globalStaticServer2;
	public static String globalStaticServer3;
	public static String searchDistrIpPort;
	
	@Value("${uploadTempDir}")
	public void setUploadTempDir(String uploadTempDir) {
		CommonConstants.uploadTempDir = uploadTempDir;
	}
	@Value("${uploadFileToDFSUrl}")
	public void setUploadFileToDFSUrl(String uploadFileToDFSUrl) {
		CommonConstants.uploadFileToDFSUrl = uploadFileToDFSUrl;
	}
	@Value("${uploadFileUrl}")
	public void setUploadFileUrl(String uploadFileUrl) {
		CommonConstants.uploadFileUrl = uploadFileUrl;
	}
	@Value("${globalStaticServer1}")
	public void setGlobalStaticServer1(String globalStaticServer1) {
		CommonConstants.globalStaticServer1 = globalStaticServer1;
	}
	@Value("${globalStaticServer2}")
	public void setGlobalStaticServer2(String globalStaticServer2) {
		CommonConstants.globalStaticServer2 = globalStaticServer2;
	}
	@Value("${globalStaticServer3}")
	public void setGlobalStaticServer3(String globalStaticServer3) {
		CommonConstants.globalStaticServer3 = globalStaticServer3;
	}
	@Value("${searchDistrIpPort}")
	public void setSearchDistrIpPort(String searchDistrIpPort) {
		CommonConstants.searchDistrIpPort = searchDistrIpPort;
	}
}
