package com.ule.wholesale.common.dbconfig;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;

import com.alibaba.druid.pool.DruidDataSource;

@Import({JDBC2MysqlConfiguration.class})
public class DataBaseMysqlConfiguration implements EnvironmentAware {

	private static Log log = LogFactory.getLog(DataBaseMysqlConfiguration.class);
	private RelaxedPropertyResolver propertyResolver;  
    @Autowired
    JDBC2MysqlConfiguration jdbc;
	@Override
	public void setEnvironment(Environment env) {
		this.propertyResolver = new RelaxedPropertyResolver(env, "spring.datasource.");
	}

	@Bean(name="dataSource", destroyMethod = "close", initMethod="init")  
    @Primary  
    public DataSource dataSource() {  
        log.debug("Configruing Write druid DataSource");  
          
        DruidDataSource dataSource = new DruidDataSource();  
        log.info("jdbc.getUsername()="+jdbc.getUsername());
        log.info("jdbc.getUrl()="+jdbc.getUrl());
        log.info("jdbc.getPassword()="+jdbc.getPassword());
        log.info("driver-class-name="+propertyResolver.getProperty("mysql-driver-class-name"));
        dataSource.setUrl(jdbc.getUrl()); 
        dataSource.setUsername(jdbc.getUsername());//用户名  
        dataSource.setPassword(jdbc.getPassword());//密码  
        dataSource.setDriverClassName(propertyResolver.getProperty("mysql-driver-class-name"));  
        dataSource.setInitialSize(jdbc.getInitialSize());  
        dataSource.setMaxActive(jdbc.getMaxActive());  
        dataSource.setMinIdle(jdbc.getMinIdle());  
        dataSource.setMaxWait(jdbc.getMaxWait());  
        dataSource.setTimeBetweenEvictionRunsMillis(Integer.parseInt(propertyResolver.getProperty("timeBetweenEvictionRunsMillis")));  
        dataSource.setMinEvictableIdleTimeMillis(Integer.parseInt(propertyResolver.getProperty("minEvictableIdleTimeMillis")));  
        dataSource.setValidationQuery(jdbc.getValidationQuery());  
        dataSource.setTestOnBorrow(Boolean.getBoolean(propertyResolver.getProperty("testOnBorrow")));  
        dataSource.setTestWhileIdle(Boolean.getBoolean(propertyResolver.getProperty("testWhileIdle")));  
        dataSource.setTestOnReturn(Boolean.getBoolean(propertyResolver.getProperty("testOnReturn")));  
        dataSource.setPoolPreparedStatements(Boolean.getBoolean(propertyResolver.getProperty("poolPreparedStatements")));  
        dataSource.setMaxPoolPreparedStatementPerConnectionSize(Integer.parseInt(propertyResolver.getProperty("maxOpenPreparedStatements")));  
        //配置监控统计拦截的filters，去掉后监控界面sql无法统计，'wall'用于防火墙  
        try {
			dataSource.setFilters(propertyResolver.getProperty("filters"));
		} catch (SQLException e) {
			e.printStackTrace();
		} 
          
        return dataSource;  
    } 
	
}
