package com.ule.wholesale.common;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.sleuth.sampler.AlwaysSampler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

import com.ule.wholesale.common.constants.CommonConstants;
import com.ule.wholesale.common.filter.SQLAndXssFilter;
//@EnableCircuitBreaker
@SpringBootApplication
@EnableDiscoveryClient
@Import({CommonConstants.class})
public abstract class CommonApplication extends SpringBootServletInitializer{
	
//	public static void main(String[] args) {
//        SpringApplication.run(CommonApplication.class, args);
//    }
	//该配置是把日志写到zipkin
	@Bean
    public AlwaysSampler defaultSampler(){
        return new AlwaysSampler();
    }
	
	/**  
     * 过滤请求参数中的xss脚本和sql关键字
     *  
     */  
    @Bean  
    public FilterRegistrationBean xssShellFilter() {  
        FilterRegistrationBean filterRegistration = new FilterRegistrationBean();  
        filterRegistration.setFilter(new SQLAndXssFilter());  
        filterRegistration.setEnabled(true);  
        filterRegistration.addUrlPatterns("/*");  
        filterRegistration.setOrder(0);  
        return filterRegistration;  
    } 
	
}
