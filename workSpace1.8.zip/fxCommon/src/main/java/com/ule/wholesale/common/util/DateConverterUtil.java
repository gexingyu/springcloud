package com.ule.wholesale.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.beanutils.Converter;

public class DateConverterUtil implements Converter  {

	private String format = "yyyy-MM-dd HH:mm:ss";
	public DateConverterUtil(){}
	
	public DateConverterUtil(String format) {
		this.format = format;
	}

	@Override
	public <T> T convert(Class<T> arg0, Object arg1) {
		 String p = (String)arg1;
	        if(p== null || p.trim().length()==0){
	            return null;
	        }
	        
	        try{
	            SimpleDateFormat df = new SimpleDateFormat(format);
	            return (T) df.parse(p.trim());
	        }
	        catch(Exception e){
	            try {
	                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	                return (T) df.parse(p.trim());
	            } catch (ParseException ex) {
	                return null;
	            }
	        }
	}

}
