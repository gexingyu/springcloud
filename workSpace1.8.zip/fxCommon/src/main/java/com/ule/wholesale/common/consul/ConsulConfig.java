package com.ule.wholesale.common.consul;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.consul.discovery.ConsulDiscoveryProperties;

import com.ule.wholesale.common.util.LocalDeveloyEnv;

public class ConsulConfig {
	private static Logger logger = LoggerFactory.getLogger(ConsulConfig.class);
	@Autowired
	ConsulDiscoveryProperties properties;
//	@Autowired
//	ConsulProperties consulProperties;
	public void initConsulConfig() throws Exception {
//		String port = System.getProperty("server.port");
//		if(StringUtils.isNotBlank(port)){
//			properties.setPort(Integer.valueOf(port));
//		}
		String hostIp = properties.getIpAddress();
		String serverProviderHost = null;
		Integer serverProviderPort = null;
		if(StringUtils.isNotBlank(properties.getHealthCheckUrl())){
			Pattern pattern = Pattern.compile("([a-zA-Z0-9]{0,32}[.])+[a-zA-Z0-9]{0,32}([:][1-9][0-9]{1,6})?",Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(properties.getHealthCheckUrl());
			if(matcher.find()){
				String tmpHost = matcher.group(0);
				String []tmp = tmpHost.split(":");
				if(tmp.length == 2){
					serverProviderHost = tmp[0];
					serverProviderPort = Integer.valueOf(tmp[1]);
				}else{
					serverProviderHost = tmp[0];
					serverProviderPort = 80;
				}
			}
		}
		logger.info("修改consul中instanceId的值，使用服务名+IP+端口,确保同一个服务在注册中心只有一条记录;hostIp="+hostIp);
		//如果是本地测试使用本地IP和HealthCheckPath，非本地环境使用域名和80端口，通过tag=dev来判断
		if(LocalDeveloyEnv.isDev || serverProviderHost == null){
			properties.setHealthCheckUrl(null);
		}else{
			properties.setIpAddress(serverProviderHost);
			properties.setHealthCheckPath(null);
			properties.setPort(serverProviderPort);
		}
		logger.info("start service serverPort="+properties.getPort());
		// InstanceId默认为applicationName+端口，使用applicationName+ip + 端口，防止集群时默认名字重复
		if(StringUtils.isBlank(properties.getInstanceId()))
			properties.setInstanceId(properties.getServiceName()+"-"+hostIp+"-"+properties.getPort());
	}
}
