package com.ule.wholesale.common.util;

import java.io.Serializable;


public final class ResultDTO<T> implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7768559982947817285L;
	
	private String code;
	private String msg;
	private String remark;
	private T data;
	
	
	
	public static ResultDTO<Object> success(){
		ResultDTO<Object> rst = new ResultDTO<Object>();
		rst.setCode("0000");
		return rst;
	}
	public static <T> ResultDTO<T> success(T data){
		ResultDTO<T> rst = new ResultDTO<T>();
		rst.setCode("0000");
		rst.setData(data);
		return rst;
	}
	public static ResultDTO<Object> fail(String msg){
		ResultDTO<Object> rst = new ResultDTO<Object>();
		rst.setCode("0001");
		rst.setMsg(msg);
		return rst;
	}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
}
