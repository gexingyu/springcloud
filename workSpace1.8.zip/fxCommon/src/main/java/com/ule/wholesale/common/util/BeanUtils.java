package com.ule.wholesale.common.util;

import org.apache.commons.beanutils.ConvertUtils;

public class BeanUtils {

	public static void copyProperties(Object dest,Object orig) throws Exception{
		ConvertUtils.register(new DateConverterUtil(), java.util.Date.class);
		try {
			org.apache.commons.beanutils.BeanUtils.copyProperties(dest, orig);
		} catch (Exception e) {
			throw new Exception(e);
		}
	}
}
