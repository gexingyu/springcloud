package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ule.wholesale.common.util.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.dto.FXSupplierParam;
import com.ule.wholesale.fxpurchase.server.service.FXSupplierInfoService;
import com.ule.wholesale.fxpurchase.server.vo.FXSupplierInfo;

@RestController
@RequestMapping("/api/supplier")
@Api(value = "供应商接口服务类",tags = "供应商服务接口")  
public class SupplierServerController {

	private static Logger logger = LoggerFactory.getLogger(SupplierServerController.class);
	
	@Autowired
	private FXSupplierInfoService supplierInfoService;
	
	@RequestMapping(value = "/getSupplierListByPage",method=RequestMethod.POST)
	@ApiOperation("分页获取供应商列表")
	public ResultDTO<Map<String,Object>> getSupplierListByPage(
			@ApiParam(name="fxSupplierInfo",value="供应商对象",required=true)@RequestBody FXSupplierInfo fxSupplierInfo,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize,String orderBy){
		logger.info("SupplierInfoController >>> getSupplierListByPage");
		ResultDTO<Map<String,Object>> rstDto = new ResultDTO<Map<String,Object>>();
		Map<String,Object> rstMap = new HashMap<String, Object>(); 
		PageInfo<FXSupplierInfo> pageInfo = supplierInfoService.getSupplierListByPage(fxSupplierInfo, pageNum, pageSize);
		rstMap.put("currentPage", pageInfo.getPageNum());
		rstMap.put("totalPage", pageInfo.getPages());
		rstMap.put("total", pageInfo.getTotal());
		rstMap.put("supplierList", pageInfo.getList());
		rstDto.setData(rstMap);
		rstDto.setCode("0");
		rstDto.setMsg("");
		return rstDto;
	}
	
	@RequestMapping(value = "/getSupplierList",method=RequestMethod.POST)
	@ApiOperation("获取供应商列表")
	public ResultDTO<List<FXSupplierInfo>> getSupplierList(
			@ApiParam(name="fxSupplierInfo",value="供应商对象",required=true)@RequestBody FXSupplierInfo fxSupplierInfo){
		logger.info("SupplierInfoController >>> getSupplierList");
		List<FXSupplierInfo> voList = supplierInfoService.getSupplierList(fxSupplierInfo);
		return ResultDTO.success(voList);
	}
	
	@RequestMapping(value = "/{id}/detail",method={RequestMethod.POST,RequestMethod.GET})
	 public ResultDTO<FXSupplierInfo> getSupplierDetail(@PathVariable("id")Long id){
		 FXSupplierInfo fxSupplierInfo =  supplierInfoService.getSupplierDetail(id);
		 ResultDTO<FXSupplierInfo> rstDto = new ResultDTO<FXSupplierInfo>();
		 rstDto.setData(fxSupplierInfo);
		 return rstDto;
	 }

	@RequestMapping(value = "/create",method=RequestMethod.POST)
	 public ResultDTO<Integer> saveFXSupplierInfo(@RequestBody Map<String,Object> supplierInfos){
		ResultDTO<Integer> rst = new ResultDTO<Integer>();
		FXSupplierInfo fxSupplierInfo = new FXSupplierInfo();
		FXSupplierParam fxSupplierParam = new FXSupplierParam();
		try {
			com.ule.wholesale.common.util.BeanUtils.copyProperties(fxSupplierInfo, supplierInfos.get("fxSupplierInfo"));
			com.ule.wholesale.common.util.BeanUtils.copyProperties(fxSupplierParam, supplierInfos.get("fxSupplierParam"));
		} catch (Exception e) {
			rst.setCode("1");
			rst.setMsg(e.getMessage());
			return rst;
		}
		
		int n = supplierInfoService.saveFXSupplierInfo(fxSupplierInfo, fxSupplierParam);
		rst.setCode("0");
		rst.setData(n);
		rst.setMsg(fxSupplierInfo.getId().toString());
		return rst;
	 }
	@RequestMapping(value = "/update",method=RequestMethod.POST)
	 public ResultDTO<Integer> updateFXSupplierInfo(@RequestBody Map<String,Object> supplierInfos){
		ResultDTO<Integer> rstDto = new ResultDTO<Integer>();
		Object obj = supplierInfos.get("fxSupplierParam");
		Object fxSupplierInfoObj = supplierInfos.get("fxSupplierInfo");
		
		FXSupplierParam fxSupplierParam = new FXSupplierParam();
		FXSupplierInfo fxSupplierInfo = new FXSupplierInfo();
		Map<String,Object> fxSupplierInfoMap = (Map<String,Object>)fxSupplierInfoObj;
		try {
			com.ule.wholesale.common.util.BeanUtils.copyProperties(fxSupplierInfo, fxSupplierInfoMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		int rst = 0;
		if(obj != null){
			Map<String,Object> paramMap = (Map<String,Object>)obj;
			try {
				org.apache.commons.beanutils.BeanUtils.copyProperties(fxSupplierParam, paramMap);
			} catch (Exception e) {
				e.printStackTrace();
			}
			rst = supplierInfoService.UpdateFXSupplierInfo(fxSupplierInfo, fxSupplierParam);
			
		}else{
			rst = supplierInfoService.updateFXSupplierInfo(fxSupplierInfo);
		}
		rstDto.setCode("0");
		rstDto.setData(rst);
		 return rstDto;
	 }
	@RequestMapping(value = "/{id}/delete",method={RequestMethod.POST,RequestMethod.GET})
	 public ResultDTO<Integer> deleteupdateFXSupplierInfo(@PathVariable("id")Long id){
		ResultDTO<Integer> rstDto = new ResultDTO<Integer>();
		 supplierInfoService.deleteupdateFXSupplierInfo(id);
		rstDto.setCode("0");
		rstDto.setData(1);
		return rstDto;
	 }
	
	@RequestMapping(value="/getSupplierInfoByItemId")
	public List<FXSupplierInfo> getSupplierInfoByItemId(@RequestBody List<Long> itemIdList){
		List<FXSupplierInfo> dtoList = new ArrayList<FXSupplierInfo>();
		try{
			List<FXSupplierInfo> voList = supplierInfoService.getSupplierInfoByItemId(itemIdList);
			if(voList!=null && voList.size()>0){
				for(FXSupplierInfo vo : voList){
					FXSupplierInfo dto = new FXSupplierInfo();
					BeanUtils.copyProperties(dto, vo);
					dtoList.add(dto);
				}
			}
		}catch(Exception e){
			logger.error("error", e);
		}
		return dtoList;
	}
}
