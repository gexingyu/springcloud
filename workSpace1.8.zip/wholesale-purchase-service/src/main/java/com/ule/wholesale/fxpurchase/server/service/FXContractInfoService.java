package com.ule.wholesale.fxpurchase.server.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.fxpurchase.server.dto.FXContractInfoDto;
import com.ule.wholesale.fxpurchase.server.mapper.FXContractInfoMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXOperationLogMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXSupplierInfoMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXContractInfo;

@Service
public class FXContractInfoService {
	
	private Logger log = LoggerFactory.getLogger(FXContractInfoService.class);
	@Autowired
	private FXContractInfoMapper fxContractInfoMapper;
	@Autowired
	private FXOperationLogMapper fxOperationLogMapper;
	@Autowired
	private FXSupplierInfoMapper fxSupplierInfoMapper;
	
	public FXContractInfo selectByPrimaryKey(Long id) {
		return fxContractInfoMapper.selectByPrimaryKey(id);
	}
	
	public FXContractInfoDto selectDtoByPrimaryKey(Long id) {
		return fxContractInfoMapper.selectDtoByPrimaryKey(id);
	}
	
	public List<FXContractInfoDto> selectByParams(Map<String,Object> params) {
		return fxContractInfoMapper.selectByParams(params);
	}
	
	public PageInfo<FXContractInfoDto> getPageByParams(Map<String,Object> params, Integer pageNum, Integer pageSize, String orderBy){
		if(orderBy == null)
			orderBy = "create_time desc";
		PageHelper.startPage(pageNum, pageSize, orderBy);
		List<FXContractInfoDto> infoList = fxContractInfoMapper.selectByParams(params);
		PageInfo<FXContractInfoDto> pageInfo = new PageInfo<FXContractInfoDto>(infoList);
		return pageInfo;
	}
	
	
	/**
	* @Description:设置合同审核按钮权限
	* @param request
	* @param status
	* @return int    返回类型 
	* @throws
	 *//*
	public int showButton(HttpServletRequest request,Integer status){
		int buttonStatus=0; 
		List<RecResource> resList = UserRoleClient.getResourceList(request);
		if(null!=resList&&!resList.isEmpty()){
			if(status==(FxPurchaseStateEnum.STATE_CONTRACT_1.getIndex())){//采购待审核
				for (RecResource res : resList) {
					if(res.getResName().equals(FxPurchaseStateEnum.CONTRACT_PURCHASE_AUDIT.getName())){
						buttonStatus=FxPurchaseStateEnum.CONTRACT_PURCHASE_AUDIT.getIndex();
						break;
					}
				}
			}else if(status==(FxPurchaseStateEnum.STATE_CONTRACT_2.getIndex())){//财务待审核
				for (RecResource res : resList) {
					if(res.getResName().equals(FxPurchaseStateEnum.CONTRACT_FINANCIAL_AUDIT.getName())){
						buttonStatus=FxPurchaseStateEnum.CONTRACT_FINANCIAL_AUDIT.getIndex();
						break;
					}
				}
				
			}else if(status==(FxPurchaseStateEnum.STATE_CONTRACT_4.getIndex())){//法务待审核
				for (RecResource res : resList) {
					if(res.getResName().equals(FxPurchaseStateEnum.CONTRACT_LAW_AUDIT.getName())){
						buttonStatus=FxPurchaseStateEnum.CONTRACT_LAW_AUDIT.getIndex();
						break;
					}
				}
				
			}
		}
		return buttonStatus;
	}*/
	
	
	@Transactional
	public void delContract(FXContractInfo info){
		fxContractInfoMapper.updateByPrimaryKey(info);
	}
	
	@Transactional
	public void submitContract(FXContractInfo info){
		fxContractInfoMapper.updateByPrimaryKey(info);
	}
	
	@Transactional
	public Long addContract(FXContractInfo record){
		fxContractInfoMapper.insertSelective(record);
		return record.getId();
	}
	
	@Transactional
	public void createContractCode(Long contractId){
		DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		FXContractInfo info = fxContractInfoMapper.selectByPrimaryKey(contractId);
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("createTime", info.getCreateTime());
		params.put("createDate", format1.format(info.getCreateTime()));
		Integer index = fxContractInfoMapper.getOrderSeq(params);
		String temp = "";
		if(index.toString().length()<6){
			for(int i=0; i<6-index.toString().length(); i++){
				temp += "0";
			}
		}
		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		String dayStr = format.format(new Date());
		String contractCode = dayStr + temp + index.toString();
		info.setContractCode(contractCode);
		fxContractInfoMapper.updateByPrimaryKey(info);
	}
	
	@Transactional
	public void editContract(FXContractInfo record){
		fxContractInfoMapper.updateByPrimaryKeySelective(record);
	}
	

	/**
	 * 供应商ID、合同ID、合同有效期开始、合约有效期结算
	 */
	public boolean compareContractAvailable(Long supplierId, Long contractId, Date availableBegin,Date availableEnd){
		//查询出此供应商的其他审核通过且未被删除的合同
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("supplierId", supplierId);
		paramMap.put("statusAttr", new Integer[]{FxPurchaseStateEnum.STATE_CONTRACT_0.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_1.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_2.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_3.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_4.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_5.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_6.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_7.getIndex()});
		paramMap.put("deleteFlag", 0);
		List<FXContractInfoDto> list = fxContractInfoMapper.selectByParams(paramMap);
		//比较其他合同的有效期与此变更的有效期是否重合
		boolean flag = true;
		if(list!=null && list.size()>0){
			for(FXContractInfoDto info : list){
				if(contractId!=null){
					if(info.getId().intValue()!=contractId.intValue()){
						if(availableEnd.before(info.getContractAvailableBegin()) 
								|| availableBegin.after(info.getContractAvailableEnd())){
							continue;
						}else {
							flag = false;
							break;
						}
					}
				}else{
					if(availableEnd.before(info.getContractAvailableBegin()) 
							|| availableBegin.after(info.getContractAvailableEnd())){
						continue;
					}else {
						flag = false;
						break;
					}
				}
			}
		}
		return flag;
	}
}
