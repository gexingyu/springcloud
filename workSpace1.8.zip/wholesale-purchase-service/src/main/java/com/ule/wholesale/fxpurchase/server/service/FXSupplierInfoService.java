package com.ule.wholesale.fxpurchase.server.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.fxpurchase.server.dto.FXSupplierParam;
import com.ule.wholesale.fxpurchase.server.mapper.FXSupplierInfoMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXSupplierInfo;

@Service
public class FXSupplierInfoService {
	
	 @Autowired
	 private FXSupplierInfoMapper fxSupplierInfoMapper;
	 
	 public PageInfo<FXSupplierInfo> getSupplierListByPage(FXSupplierInfo fxSupplierInfo,Integer pageNum,Integer pageSize){
		 PageHelper.startPage(pageNum, pageSize,"CREATE_TIME DESC,UPDATE_TIME DESC");
		 List<FXSupplierInfo> lists = fxSupplierInfoMapper.selectFxSupplierInfos(fxSupplierInfo);
		 PageInfo<FXSupplierInfo> pageInfo = new PageInfo<FXSupplierInfo>(lists);
		 return pageInfo;
	 }
	 
	 public FXSupplierInfo getSupplierDetail(Long id){
		 FXSupplierInfo fxSupplierInfo =  fxSupplierInfoMapper.selectByPrimaryKey(id);
		 return fxSupplierInfo;
	 }
	 
	 public int saveFXSupplierInfo(FXSupplierInfo fxSupplierInfo,FXSupplierParam fxSupplierParam){
		fxSupplierInfo = dealFxSupplierInfo(fxSupplierInfo,fxSupplierParam);
		return fxSupplierInfoMapper.insertSelective(fxSupplierInfo);
	 }
	 
	 public int UpdateFXSupplierInfo(FXSupplierInfo fxSupplierInfo,FXSupplierParam fxSupplierParam){
		 fxSupplierInfo = dealFxSupplierInfo(fxSupplierInfo,fxSupplierParam);
		 return fxSupplierInfoMapper.updateByPrimaryKeySelective(fxSupplierInfo);
	 }
	 
	 public int updateFXSupplierInfo(FXSupplierInfo fxSupplierInfo){
		return fxSupplierInfoMapper.updateByPrimaryKeySelective(fxSupplierInfo);
	 }
	 
	 public void deleteupdateFXSupplierInfo(Long id){
	//	 fxSupplierInfoMapper.deleteByPrimaryKey(id);
		 FXSupplierInfo fxSupplierInfo = fxSupplierInfoMapper.selectByPrimaryKey(id);
		 if(fxSupplierInfo!=null){
			 fxSupplierInfo.setDeleteFlag(1);
			 fxSupplierInfoMapper.updateByPrimaryKeySelective(fxSupplierInfo);
		 }
	 }
	 
	 private FXSupplierInfo dealFxSupplierInfo(FXSupplierInfo fxSupplierInfo,FXSupplierParam fxSupplierParam){
		 if(fxSupplierParam!=null){
			 if(fxSupplierParam.getProvinceOrg()!=null
					 &&!"".equals(fxSupplierParam.getProvinceOrg())){
				 fxSupplierInfo.setSignProvinceCode(fxSupplierParam.getProvinceOrg());
			 }
			 if(fxSupplierParam.getProvinceOrgName()!=null
					 &&!"".equals(fxSupplierParam.getProvinceOrgName())){
				 fxSupplierInfo.setSignProvinceName(fxSupplierParam.getProvinceOrgName());
			 }
			 if(fxSupplierParam.getCityOrg()!=null
					 &&!"".equals(fxSupplierParam.getCityOrg())){
				 fxSupplierInfo.setSignCityCode(fxSupplierParam.getCityOrg());
			 }
			 if(fxSupplierParam.getCityOrgName()!=null
					 &&!"".equals(fxSupplierParam.getCityOrgName())){
				 fxSupplierInfo.setSignCityName(fxSupplierParam.getCityOrgName());
			 }
			 if(fxSupplierParam.getCountyOrg()!=null
					 &&!"".equals(fxSupplierParam.getCountyOrg())){
				 fxSupplierInfo.setSignRegionCode(fxSupplierParam.getCountyOrg());
			 }
			 if(fxSupplierParam.getCountyOrg()!=null
					 &&!"".equals(fxSupplierParam.getCountyOrg())){
				 fxSupplierInfo.setSignRegionName(fxSupplierParam.getCountyOrgName());
			 }
			 if(fxSupplierParam.getBankParentCode()!=null
					 &&!"".equals(fxSupplierParam.getBankParentCode())){
				 fxSupplierInfo.setBankLicenceParentCode(fxSupplierParam.getBankParentCode());
			 }
			 if(fxSupplierParam.getBankParentName()!=null
					 &&!"".equals(fxSupplierParam.getBankParentName())){
				 fxSupplierInfo.setBankLicenceParentName(fxSupplierParam.getBankParentName());
			 }
			 if(fxSupplierParam.getBusiLicenseAvailableBeginStr()!=null
					 &&!"".equals(fxSupplierParam.getBusiLicenseAvailableBeginStr())){
				 try {
					fxSupplierInfo.setBusiLicenseAvailableBegin(new SimpleDateFormat("yyyy-MM-dd").parse(fxSupplierParam.getBusiLicenseAvailableBeginStr()));
				} catch (ParseException e) {
					e.printStackTrace();
				}
			 }
			 if(fxSupplierParam.getBusiLicenseAvailableEndStr()!=null
					 &&!"".equals(fxSupplierParam.getBusiLicenseAvailableEndStr())){
				 try {
					fxSupplierInfo.setBusiLicenseAvailableEnd(new SimpleDateFormat("yyyy-MM-dd").parse(fxSupplierParam.getBusiLicenseAvailableEndStr()));
				} catch (ParseException e) {
					e.printStackTrace();
				}
			 }
		 }
		return fxSupplierInfo;
	 }
	 
	 
	 /**
	  * 不需要分页
	  * @param fxSupplierInfo
	  * @return
	  */
	 public List<FXSupplierInfo> getSupplierList(FXSupplierInfo fxSupplierInfo){
		 return fxSupplierInfoMapper.selectFxSupplierInfos(fxSupplierInfo);
	 }
	 
	//更加itemId获取供应商信息
	public List<FXSupplierInfo> getSupplierInfoByItemId(List<Long> itemIdList){
		return fxSupplierInfoMapper.getSupplierInfoByItemId(itemIdList);
	}
}
