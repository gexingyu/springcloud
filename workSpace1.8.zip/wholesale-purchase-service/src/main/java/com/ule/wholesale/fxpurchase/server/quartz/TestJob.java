//package com.ule.wholesale.fxpurchase.server.quartz;
//
//import org.quartz.Job;
//import org.quartz.JobExecutionContext;
//import org.quartz.JobExecutionException;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.alibaba.fastjson.JSONObject;
//
//public class TestJob implements Job{
//
//	private static Logger logger = LoggerFactory.getLogger(TestJob.class);
//
//	@Override
//	public void execute(JobExecutionContext context) throws JobExecutionException {
//		logger.info("JobName: {} ，{}，{}", context.getJobDetail().getKey().getName(),context.getJobDetail().getDescription(),JSONObject.toJSON(context.getJobDetail().getJobDataMap()));
//	}
//}
