package com.ule.wholesale.fxpurchase.server.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.fxpurchase.server.mapper.FXGoodsCompareListMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXGoodsCompareList;

@Service("fxGoodsComparisonService")
public class FXGoodsComparisonService {
	
	@Autowired
	private FXGoodsCompareListMapper fxGoodsCompareListMapper;
	
	public int saveFXGoodsCompareList(FXGoodsCompareList fxGoodsCompareList){
		return fxGoodsCompareListMapper.insertSelective(fxGoodsCompareList);
	}
	
	public PageInfo<FXGoodsCompareList> getGoodsCompareListByPage(FXGoodsCompareList fxGoodsCompareList,int pageNum,int pageSize){
		PageHelper.startPage(pageNum, pageSize,"CREATE_TIME DESC,UPDATE_TIME DESC");
		List<FXGoodsCompareList> list = fxGoodsCompareListMapper.selectFXGoodsCompareListInfos(fxGoodsCompareList);
		PageInfo<FXGoodsCompareList> info = new PageInfo<FXGoodsCompareList>(list);
		return info;
	}
	public List<FXGoodsCompareList> getGoodsCompareList(FXGoodsCompareList fxGoodsCompareList){
		return fxGoodsCompareListMapper.selectFXGoodsCompareListInfos(fxGoodsCompareList);
	}
	
	public FXGoodsCompareList selectfxGoodsComparisonById(Long id){
		return fxGoodsCompareListMapper.selectByPrimaryKey(id);
	}
	
	public int updateFXGoodsComparison(FXGoodsCompareList fxGoodsCompareList){
		return fxGoodsCompareListMapper.updateByPrimaryKeySelective(fxGoodsCompareList);
	}
	public void deleteFXGoodsComparison(Long id){
		fxGoodsCompareListMapper.deleteByPrimaryKey(id);
	}
	
	public PageInfo<FXGoodsCompareList> selectItemList(FXGoodsCompareList fxGoodsCompareList,Integer pageNum,Integer pageSize){
		PageHelper.startPage(pageNum, pageSize);
		List<FXGoodsCompareList> list = fxGoodsCompareListMapper.selectFXGoodsCompareListInfos(fxGoodsCompareList);
		PageInfo<FXGoodsCompareList> pageInfo=new PageInfo<FXGoodsCompareList>(list);
		return pageInfo;
	}

}
