package com.ule.wholesale.fxpurchase.server.mapper;

import java.util.List;

import com.ule.wholesale.fxpurchase.server.vo.BankInfo;

public interface BankInfoMapper {

    List<BankInfo> selectBankInfoGroup1();
    List<BankInfo> selectBankInfoGroup2();
    List<BankInfo> selectBankInfoGroup3();
    List<BankInfo> selectBankInfoGroup4();
    List<BankInfo> selectBankInfoGroup5();
    
    
}