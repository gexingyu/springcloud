package com.ule.wholesale.fxpurchase.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;

import com.ule.wholesale.common.CommonApplication;

@ComponentScan({"com.ule.wholesale.fxpurchase.server.init","com.ule.wholesale.fxpurchase.server.config","com.ule.wholesale.fxpurchase.server.service","com.ule.wholesale.fxpurchase.server.controller"})
public class FxServerApplication extends CommonApplication{

	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		
        return builder.sources(FxServerApplication.class);
	}
	public static void main(String[] args) {
        SpringApplication.run(FxServerApplication.class, args);
    }
}
