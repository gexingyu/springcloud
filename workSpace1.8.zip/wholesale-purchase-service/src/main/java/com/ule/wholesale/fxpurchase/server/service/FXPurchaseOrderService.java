package com.ule.wholesale.fxpurchase.server.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.BeanUtils;
import com.ule.wholesale.fxpurchase.server.mapper.FXPurchaseOrderGoodsMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXPurchaseOrderMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXRequireGoodsListMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FxOrderMsgPublishMapper;
import com.ule.wholesale.fxpurchase.server.msghandler.KafkaProducerHandler;
import com.ule.wholesale.fxpurchase.server.vo.FXPurchaseOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXPurchaseOrderGoods;
import com.ule.wholesale.fxpurchase.server.vo.FXRequireGoodsList;
import com.ule.wholesale.fxpurchase.server.vo.FXWholesaleOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXWholesaleOrderGoods;
import com.ule.wholesale.fxpurchase.server.vo.FxOrderMsgPublish;

@Service
public class FXPurchaseOrderService {
	private static Logger logger = LoggerFactory.getLogger(FXPurchaseOrderService.class);
	@Autowired
	private FXPurchaseOrderMapper purchaseOrderMapper;
	@Autowired
	private FXPurchaseOrderGoodsMapper orderGoodsMapper;
	@Autowired
	private FxOrderMsgPublishMapper orderMsgPublishMapper;
	@Autowired
	private FXRequireGoodsListMapper fxRequireGoodsListMapper;
	@Autowired
	private FxCommonService commonService;
	@Autowired
	private FXWholesaleOrderService fxWholesaleOrderService;
	
//	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	@Transactional
	public FXPurchaseOrder saveOrder(FXPurchaseOrder order,List<FXPurchaseOrderGoods> itemList){
		logger.info("FXPurchaseOrderService>>>>>>>>save FXPurchaseOrder");
		if(order.getId() == null){
			purchaseOrderMapper.insert(order);
		}else{
			FXPurchaseOrder tmp = purchaseOrderMapper.selectLockByPrimaryKey(order.getId());
			if(tmp.getVersion() != order.getVersion()){
				//数据已被操作
				order.setState(-1);
				return order;
			}
			order.setVersion(order.getVersion() + 1);
			//订单编辑时先删除已有商品，重新插入
			logger.info("订单编辑操作，删除已有商品信息");
			orderGoodsMapper.deleteByOrderId(order.getId());
			purchaseOrderMapper.updateByPrimaryKey(order);
		}
		logger.info("FXPurchaseOrderService>>>>>>>>batch save FXPurchaseOrderGoods");
		for(FXPurchaseOrderGoods record :itemList){
			record.setOrderId(order.getId());
			orderGoodsMapper.insert(record);
		}
		logger.info("FXPurchaseOrderService>>>>>>>>order info save success");
		
		return order;
	}
	@Transactional
	public boolean createOrderNo(FXPurchaseOrder order){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String,Object> rst = new HashMap<String, Object>();
		rst.put("orderId", order.getId());
		rst.put("createTime", order.getCreateTime());
		rst.put("createDate", sdf.format(order.getCreateTime()));
		Long orderId = order.getId();
		logger.info("FXPurchaseOrderService>>>>>>>>createOrderNo orderId="+orderId);
		try {
			int orderSeq = purchaseOrderMapper.getOrderSeq(rst);
			String seqNo = String.format("%06d", orderSeq);
			String orderNo = rst.get("createDate").toString().replaceAll("-", "")+seqNo;
			logger.info("FXPurchaseOrderService>>>>>>>>create orderNo="+orderNo);
			//FXPurchaseOrder order = purchaseOrderMapper.selectByPrimaryKey(Long.valueOf(orderId.toString()));
			order.setOrderNo(orderNo);
			purchaseOrderMapper.updateByPrimaryKey(order);
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("orderNo", orderNo);
			params.put("orderId", orderId);
			orderGoodsMapper.updateOrderNo(params);
			fxRequireGoodsListMapper.updateOrderNo(params);
			logger.info("FXPurchaseOrderService>>>>>>>>orderNo update success");
			
			return true;
		} catch (Exception e) {
			purchaseOrderMapper.deleteByPrimaryKey(orderId);
			orderGoodsMapper.deleteByOrderId(orderId);
			logger.error("生成订单编号时发生异常，"+e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
	private void saveKafkaMsg(final FXPurchaseOrder order,final List<FXPurchaseOrderGoods> itemList){
		new Thread(){
			@Override
			public void run() {
				List<FXPurchaseOrderGoods> tmpItemList = null;
				logger.info("save purchanse order info to schedule");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				FxOrderMsgPublish orderMsg = new FxOrderMsgPublish();
				orderMsg.setBizNo(order.getOrderNo());
				orderMsg.setCreateTime(new Date());
				orderMsg.setStatus(0);
				orderMsg.setType(1);
				//入库通知单需要的信息
				Map<String,Object> msgMap = new HashMap<String, Object>();
				msgMap.put("customerOrderNo", order.getOrderNo());
				msgMap.put("warehouseId", order.getReceivingWarehouseId());
				msgMap.put("merchantId", order.getMerchantId());
				msgMap.put("reservedArrivalDate", (order.getPlanDeliveryTime() != null)? sdf.format(order.getPlanDeliveryTime()) : null);
				msgMap.put("remark", order.getRemark());
				msgMap.put("supplier", order.getSupplierName());
				if(itemList == null )
					tmpItemList = orderGoodsMapper.selectByOrderId(order.getId());
				else
					tmpItemList = itemList;
				List<Map<String,Object>> inDetailList = new ArrayList<Map<String,Object>>();
				for(FXPurchaseOrderGoods item : tmpItemList){
					Map<String,Object> tmp = new HashMap<String, Object>();
					tmp.put("itemId", item.getItemId());
					tmp.put("quantity", item.getPlanNum());
					inDetailList.add(tmp);
				}
				msgMap.put("inDetailList", inDetailList);
				orderMsg.setMessage(JSONObject.toJSONString(msgMap));
				try{
					logger.info("send purchase order info to kafka ");
					KafkaProducerHandler.sendOrderTopic(order.getOrderNo(), JSONObject.toJSONString(msgMap));
					orderMsg.setStatus(1);
					orderMsgPublishMapper.insert(orderMsg);
				}catch(Exception e){
					logger.error("send purchase order info to kafka error:"+e.getMessage());
					orderMsg.setStatus(0);
					orderMsgPublishMapper.insert(orderMsg);
				}
				
			}
			
		}.start();
	}
	/**
	 * 根据订单ID获取订单详细信息
	 * @param orderId
	 * @return
	 */
	public FXPurchaseOrder selectOrderByOrderId(Long orderId){
		logger.info("FXPurchaseOrderService>>>>>>>>fingdOrderByOrderId orderId="+orderId);
		try {
			FXPurchaseOrder order = purchaseOrderMapper.selectByPrimaryKey(orderId);
			return order;
		} catch (Exception e) {
			logger.error("fingdOrderByOrderId 获取订单详情时异常，"+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * 并发操作时更新订单信息，lock 当前记录，其他操作莫用
	 * @param orderId
	 * @return
	 */
	public FXPurchaseOrder fingdAndLokcByOrderId(Long orderId){
		logger.info("FXPurchaseOrderService>>>>>>>>fingdOrderByOrderId orderId="+orderId);
		try {
			FXPurchaseOrder order = purchaseOrderMapper.selectLockByPrimaryKey(orderId);
			return order;
		} catch (Exception e) {
			logger.error("fingdOrderByOrderId 获取订单详情时异常，"+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * 根据订单ID获取订单详细信息，包括订单商品列表
	 * @param orderId
	 * @return
	 */
	public Map<String,Object> selectdOrderDetailByOrderId(Long orderId){
		logger.info("FXPurchaseOrderService>>>>>>>>fingdOrderDetailByOrderId orderId="+orderId);
		try {
			FXPurchaseOrder order = purchaseOrderMapper.selectByPrimaryKey(orderId);
			List<FXPurchaseOrderGoods> itemList = orderGoodsMapper.selectByOrderId(orderId);
			Map<String,Object> orderDetail = new HashMap<String, Object>();
			orderDetail.put("order", order);
			orderDetail.put("itemList", itemList);
			return orderDetail;
		} catch (Exception e) {
			logger.error("fingdOrderDetailByOrderId 获取订单详情时异常，"+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	public PageInfo<FXPurchaseOrder> selectOrderList(Map<String,Object> params,Integer pageNum,Integer pageSize){
		PageHelper.startPage(pageNum, pageSize,"CREATE_TIME DESC,UPDATE_TIME DESC");
		List<FXPurchaseOrder> ordersList=purchaseOrderMapper.selectOrderListBySelective(params);
		PageInfo<FXPurchaseOrder> pageInfo=new PageInfo<FXPurchaseOrder>(ordersList);
		return pageInfo;
	}
	/**
	 * 查询指定供应商采购过的商品列表（限定为两年以内的商品）,已收货商品状态 8
	 * @param supplierId
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	public PageInfo<FXPurchaseOrderGoods> selectPurchaseItemList(Map<String,Object> params,Integer pageNum,Integer pageSize){
		PageHelper.startPage(pageNum, pageSize);
		Calendar c = Calendar.getInstance();
		c.add(Calendar.YEAR, -2);
		params.put("twoYearAgo", c.getTime());
		params.put("state", 8);
		List<FXPurchaseOrderGoods> ordersList=orderGoodsMapper.selectBySupplierId(params);
		PageInfo<FXPurchaseOrderGoods> pageInfo=new PageInfo<FXPurchaseOrderGoods>(ordersList);
		return pageInfo;
	}
	
	
@Transactional
public String updateOrderState(Long orderId,Integer state,String auditResult,Integer version,String user,Long userId){
	logger.info("updateOrderState state="+state);
	FXPurchaseOrder order = purchaseOrderMapper.selectLockByPrimaryKey(orderId);
	if(version != order.getVersion()){
		return "数据已被操作，请更新后再操作";
	}
	String orderNo = "orderNo:";
		if(state == 1){
			//提交订单
			order.setUpdateTime(new Date());
			order.setUpdateUser(user);
			order.setUpdateUserId(userId);
		}else if(state == 2){
			//审核通过
			order.setAuditTime(new Date());
			order.setAuditUser(user);
			order.setAuditUserId(userId);
			saveKafkaMsg(order,null);
		}else if(state == 3){
			//审核拒绝
			order.setAuditTime(new Date());
			order.setAuditUser(user);
			order.setAuditUserId(userId);
			order.setAuditResult(auditResult);
		}else if(state == 9){
			if(order.getState() == FxPurchaseStateEnum.STATE_ORDER_2.getIndex() 
					&& order.getSourceOrderType() == FxPurchaseStateEnum.SOURCE_TYPE_0.getIndex()){
				if(StringUtils.isBlank(order.getWhOrderNo())){
					return "与仓库信息同步中，请稍后再试！";
				}
				String rst = commonService.cancelPurcahseOrder(order.getOrderNo(), order.getReceivingWarehouseId());
				logger.info("commonService.cancelPurcahseOrder=====>>>>"+rst);
				if(!"".equals(rst)){
					JSONObject json = JSONObject.parseObject(rst);
					if("0000".equals(json.getString("code"))){
						//有包裹订单取消成功，取消本系统订单
					}else{
						return json.get("msg").toString();
					}
				}else{
					return "数据请求异常";
				}
			}
			if(order.getSourceOrderType() == FxPurchaseStateEnum.SOURCE_TYPE_1.getIndex()){
				//要货清单状态改为未分配
				FXRequireGoodsList fxRequireGoodsList = 
						fxRequireGoodsListMapper.getFXRequireGoodsListDtoByOrderNo(order.getOrderNo(),"1");
				fxRequireGoodsList.setState(FxPurchaseStateEnum.REQUIRE_STATUS_0.getIndex());
				fxRequireGoodsList.setBizOrderId(null);
				fxRequireGoodsList.setBizOrderNo(null);
				fxRequireGoodsList.setBizOrderType(null);
				fxRequireGoodsList.setDistributeTime(null);
				fxRequireGoodsListMapper.updateByPrimaryKey(fxRequireGoodsList);
			}
			order.setCancelTime(new Date());
			order.setCancelUser(user);
			order.setCancelUserId(userId);
		}
		order.setState(state);
		order.setUpdateTime(new Date());
		order.setUpdateUserId(userId);
		order.setUpdateUser(user);
		
		int rst = purchaseOrderMapper.updateByPrimaryKeySelective(order);
		if(rst > 0){
			return orderNo+order.getOrderNo();
		}
		return null;
	}

@Transactional
public String receiveOrder(Map<String, Object> params) throws Exception{
	
	Long orderId = Long.valueOf(params.get("orderId").toString());
	Integer state = Integer.valueOf(params.get("state").toString());
	Integer version = Integer.valueOf(params.get("version").toString());
	String userName = params.get("username").toString();
	Long userId = Long.valueOf(params.get("userId").toString());
	
	logger.info("updateOrderState state="+state);
	FXPurchaseOrder order = purchaseOrderMapper.selectLockByPrimaryKey(orderId);
	if(version != order.getVersion()){
		return "数据已被操作，请更新后再操作";
	}
	String whOrderId = "whOrderId:";
	order.setState(state);
	order.setUpdateTime(new Date());
	order.setUpdateUserId(userId);
	order.setUpdateUser(userName);
	int rst = purchaseOrderMapper.updateByPrimaryKeySelective(order);
	if(rst > 0){
		Object obj = params.get("order");
		List<Map<String,Object>> objList = (List<Map<String,Object>>)params.get("itemList");
		FXWholesaleOrder whOrder = new FXWholesaleOrder();
		List<FXWholesaleOrderGoods> itemList = new ArrayList<FXWholesaleOrderGoods>();
		BeanUtils.copyProperties(whOrder, obj);
		for(Map<String,Object> map :objList){
			FXWholesaleOrderGoods g = new FXWholesaleOrderGoods();
			BeanUtils.copyProperties(g, map);
			itemList.add(g);
		}
		whOrder = fxWholesaleOrderService.saveOrder(whOrder, itemList);
		fxWholesaleOrderService.createOrderNo(whOrder);
		//修改要货清单状态
		FXRequireGoodsList fxRequireGoodsList = 
				fxRequireGoodsListMapper.getFXRequireGoodsListDtoByOrderNo(order.getOrderNo(),"1");
		fxRequireGoodsList.setState(FxPurchaseStateEnum.REQUIRE_STATUS_2.getIndex());
		fxRequireGoodsList.setFinishTime(new Date());
		fxRequireGoodsListMapper.updateByPrimaryKey(fxRequireGoodsList);
		return whOrderId+whOrder.getId();
	}
	return null;
}

	@Transactional
	public String updateOrderPrepay(Long orderId,Integer prepay,Integer version,String user,Long userId){
		FXPurchaseOrder order = purchaseOrderMapper.selectLockByPrimaryKey(orderId);
		if(version != order.getVersion()){
			return "数据已被操作，请更新后再操作";
		}
		String orderNo = "orderNo:";
		if(order.getState() == FxPurchaseStateEnum.STATE_ORDER_2.getIndex()){
			order.setIsPrepay(prepay);
			order.setUpdateUser(user);
			order.setUpdateUserId(userId);
			order.setUpdateTime(new Date());
			int rst = purchaseOrderMapper.updateByPrimaryKeySelective(order);
			if(rst > 0){
				return orderNo+order.getOrderNo();
			}
		}
		return null;
	}	
	public String deleteOrder(Long orderId,String user,Long userId){
		FXPurchaseOrder order = purchaseOrderMapper.selectByPrimaryKey(orderId);
		//order.setId(orderId);
		order.setDeleteFlag(1);
		order.setCancelTime(new Date());
		order.setCancelUser(user);
		order.setCancelUserId(userId);
		order.setUpdateTime(new Date());
		order.setUpdateUserId(userId);
		order.setUpdateUser(user);
		int rst = purchaseOrderMapper.updateByPrimaryKeySelective(order);
		if(rst > 0){
			return order.getOrderNo();
		}
		return null;
	}
}
