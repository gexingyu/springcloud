package com.ule.wholesale.fxpurchase.server.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ule.wholesale.fxpurchase.server.mapper.FXContractItemChangeMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXContractItemChange;

@Service
public class FXContractItemChangeService {
	
	@Autowired
	private FXContractItemChangeMapper fxContractItemChangeMapper;
	
	public List<FXContractItemChange> selectByChangePaperId(Long changePaperId){
		return fxContractItemChangeMapper.selectByChangePaperId(changePaperId);
	}

}
