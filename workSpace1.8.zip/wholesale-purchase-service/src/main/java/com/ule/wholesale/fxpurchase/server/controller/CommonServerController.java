package com.ule.wholesale.fxpurchase.server.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.service.FxCommonService;

@RestController
@RequestMapping("/api/common")
public class CommonServerController {

	private static Logger logger = LoggerFactory.getLogger(CommonServerController.class);
	@Autowired
	FxCommonService commonService;
	@RequestMapping("/sendMsg")
	public ResultDTO<Object> sendMsg(){
		long start = System.currentTimeMillis();
        logger.info("CommonServerController.sendMsg start...");
		commonService.sendMsg();
		logger.info("CommonServerController.handlerOrderStateFeedback  end total use  " + (System.currentTimeMillis() - start) +" ms");
		return ResultDTO.success();
	}
	@RequestMapping("/handlerMsg")
	public ResultDTO<Object> handlerOrderStateFeedback(){
        long start = System.currentTimeMillis();
        logger.info("CommonServerController.handlerOrderStateFeedback start...");
        try {
			commonService.handlerMsg();
		} catch (Exception e) {
			e.printStackTrace();
		}
        logger.info("CommonServerController.handlerOrderStateFeedback  end total use  " + (System.currentTimeMillis() - start) +" ms");
        return ResultDTO.success();
    }
}
