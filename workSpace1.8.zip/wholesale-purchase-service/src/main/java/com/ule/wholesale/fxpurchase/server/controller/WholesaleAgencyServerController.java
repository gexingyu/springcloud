package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.service.FXOPcDmsOrgRelationService;
import com.ule.wholesale.fxpurchase.server.vo.FXOPcDmsOrgRelation;

/**
 * 批发机构
 * */
@RestController
@RequestMapping("/api/agency")
@Api(value = "批发机构接口服务类",tags = "批发机构服务接口")  
public class WholesaleAgencyServerController {
	
	private static Log logger = LogFactory.getLog(WholesaleAgencyServerController.class);  
	
	@Autowired
	private FXOPcDmsOrgRelationService fxOPcDmsOrgRelationService;
	
	@RequestMapping(value = "/{id}/edit")	
	public ResultDTO<FXOPcDmsOrgRelation> toEditAgency(@PathVariable("id") Long id){
		ResultDTO<FXOPcDmsOrgRelation> rst = new ResultDTO<FXOPcDmsOrgRelation>();
		FXOPcDmsOrgRelation fxoPcDmsOrgRelation = null;
		if(id != null){
			fxoPcDmsOrgRelation = fxOPcDmsOrgRelationService.selectFxoPcDmsOrgRelationById(id);
		}
		rst.setData(fxoPcDmsOrgRelation);
		return rst;
	}
	
	@RequestMapping(value = "/addAgency")
	public ResultDTO<Integer> addAgency(
			@ApiParam(name="fxoPcDmsOrgRelation",value="批发机构对象",required=true)@RequestBody FXOPcDmsOrgRelation fxoPcDmsOrgRelation){
		ResultDTO<Integer> rst = new ResultDTO<Integer>();
		try {
			int n = fxOPcDmsOrgRelationService.saveWholesaleAgency(fxoPcDmsOrgRelation);
			rst.setCode("0");
			rst.setData(n);
		} catch (Exception e) {
			rst.setCode("1");
			rst.setMsg(e.getMessage());
			logger.error("addAgency error "+e.getMessage(),e);
		}
		return rst;
	}
	/**
	 * 根据条件分页查询机构
	 * @param pageNo
	 * @param pageSize
	 * @return pageInfo
	 */
	@RequestMapping(value = "/list",method = RequestMethod.POST)
	public ResultDTO<Map<String, Object>> getAgencyListByPage(
			@ApiParam(name="fxoPcDmsOrgRelation",value="批发机构对象",required=true)@RequestBody FXOPcDmsOrgRelation fxoPcDmsOrgRelation,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize){
		ResultDTO<Map<String, Object>> rstDto = new ResultDTO<Map<String,Object>>();
		Map<String, Object> rstMap = new HashMap<String, Object>();
		PageInfo<FXOPcDmsOrgRelation> pageInfo = fxOPcDmsOrgRelationService.getAgencyListByPage(fxoPcDmsOrgRelation, pageNum, pageSize);
		rstMap.put("currentPage", pageInfo.getPageNum());
		rstMap.put("totalPage", pageInfo.getPages());
		rstMap.put("total", pageInfo.getTotal());
		rstMap.put("list", pageInfo.getList());
		rstDto.setData(rstMap);
		rstDto.setCode("0");
		rstDto.setMsg("");
		return rstDto;
	}
	
	@RequestMapping( value = "/edit")
	public ResultDTO<Integer> editAgency(@ApiParam(name="fxoPcDmsOrgRelation",value="批发机构对象",required=true)@RequestBody FXOPcDmsOrgRelation fxoPcDmsOrgRelatio){
			ResultDTO<Integer> rst = new ResultDTO<Integer>();
			try {
				int n =  fxOPcDmsOrgRelationService.updateFxoPcDmsOrgRelation(fxoPcDmsOrgRelatio);
				rst.setCode("0");
				rst.setData(n);
			} catch (Exception e) {
				rst.setCode("1");
				rst.setMsg(e.getMessage());
			}
			return rst;
	}
	
	
} 
