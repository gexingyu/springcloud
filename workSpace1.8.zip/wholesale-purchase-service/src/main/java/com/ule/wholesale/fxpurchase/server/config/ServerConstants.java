package com.ule.wholesale.fxpurchase.server.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

//@Component
@ConfigurationProperties(prefix="properties")
public class ServerConstants {
	
//	private static Logger logger = LoggerFactory.getLogger(PropertiesConfiguration.class);
	public static String clientName;
	public static String clientKey;
	public static String itemAppkey;
	public static String merchantWarehouse;
	public static String itemsStorage;
	public static String warehouseInfo;
	public static String cancelPurchaseOrder;
	public static String cancelReturnOrder;
	public static String uleSelfSupport;
	public static String betaTestMerchant;
	

	@Value("${clientName}")
	public void setClientName(String clientName) {
		ServerConstants.clientName = clientName;
	}
	@Value("${clientKey}")
	public void setClientKey(String clientKey) {
		ServerConstants.clientKey = clientKey;
	}
	@Value("${itemAppkey}")
	public void setItemAppkey(String itemAppkey) {
		ServerConstants.itemAppkey = itemAppkey;
	}
	@Value("${merchantWarehouse}")
	public void setMerchantWarehouse(String merchantWarehouse) {
		ServerConstants.merchantWarehouse = merchantWarehouse;
	}
	@Value("${itemsStorage}")
	public void setItemsStorage(String itemsStorage) {
		ServerConstants.itemsStorage = itemsStorage;
	}
	@Value("${warehouseInfo}")
	public void setWarehouseInfo(String warehouseInfo) {
		ServerConstants.warehouseInfo = warehouseInfo;
	}
	@Value("${cancelPurchaseOrder}")
	public void setCancelPurchaseOrder(String cancelPurchaseOrder) {
		ServerConstants.cancelPurchaseOrder = cancelPurchaseOrder;
	}
	@Value("${cancelReturnOrder}")
	public void setCancelReturnOrder(String cancelReturnOrder) {
		ServerConstants.cancelReturnOrder = cancelReturnOrder;
	}
	@Value("${uleSelfSupport}")
	public void setUleSelfSupport(String uleSelfSupport) {
		ServerConstants.uleSelfSupport = uleSelfSupport;
	}
	@Value("${betaTestMerchant:}")
	public void setBetaTestMerchant(String betaTestMerchant) {
		ServerConstants.betaTestMerchant = betaTestMerchant;
	}
}
