package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.dto.FXContractItemListDto;
import com.ule.wholesale.fxpurchase.server.service.FXContractItemListService;
import com.ule.wholesale.fxpurchase.server.vo.FXContractItemList;

@RestController
@Api(value="合同接口服务", tags="合同接口服务")  
@RequestMapping("/api/contractItem")
public class ContractItemServerController {
	
	@Autowired
	private FXContractItemListService fxContractItemListService;
	
	@RequestMapping(value="/getPageByParams", method=RequestMethod.POST)
	@ApiOperation("获取合同列表")
	public ResultDTO<PageInfo<FXContractItemList>> getPageByParams(
			@ApiParam(name="params",value="查询条件",required=true)@RequestBody Map<String, Object> params,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize,
			@ApiParam(name="orderBy",value="排序")String orderBy){
		ResultDTO<PageInfo<FXContractItemList>> rstDTO = new ResultDTO<PageInfo<FXContractItemList>>();
		
		PageInfo<FXContractItemList> pageInfo = fxContractItemListService.getPageByParams(params, pageNum, pageSize, orderBy);
		
		rstDTO.setData(pageInfo);
		rstDTO.setCode("0");
		rstDTO.setMsg("");
		return rstDTO;
	}
	
	@RequestMapping(value="/selectEffectiveItemListByContractId", method=RequestMethod.POST)
	@ApiOperation("获取合同列表")
	public ResultDTO<PageInfo<FXContractItemList>> selectEffectiveItemListByContractId(
			@ApiParam(name="params",value="查询条件",required=true)@RequestBody Map<String, Object> params,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize,
			@ApiParam(name="orderBy",value="排序")String orderBy){
		ResultDTO<PageInfo<FXContractItemList>> rstDTO = new ResultDTO<PageInfo<FXContractItemList>>();
		
		PageInfo<FXContractItemList> pageInfo = fxContractItemListService.selectEffectiveItemListByContractId(params, pageNum, pageSize, orderBy);
		
		rstDTO.setData(pageInfo);
		rstDTO.setCode("0");
		rstDTO.setMsg("");
		return rstDTO;
	}
	@RequestMapping(value="/findEffectiveItemList", method=RequestMethod.POST)
	@ApiOperation("获取合同有效商品列表")
	public ResultDTO<PageInfo<FXContractItemList>> findEffectiveItemList(
			@ApiParam(name="params",required=true)@RequestBody Map<String, Object> params,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize){
		ResultDTO<PageInfo<FXContractItemList>> rstDTO = new ResultDTO<PageInfo<FXContractItemList>>();
		Long supplierId = params.get("supplierId") == null ? null : Long.valueOf(params.get("supplierId").toString());
		Long merchantId = params.get("merchantId") == null ? null : Long.valueOf(params.get("merchantId").toString());
		Long itemId = params.get("itemId") == null ? null : Long.valueOf(params.get("itemId").toString());
		String itemName = params.get("params") == null ? null : params.get("params").toString();
		PageInfo<FXContractItemList> pageInfo = fxContractItemListService.selectEffectiveItemList(supplierId, merchantId, itemId, itemName, pageNum, pageSize);
		
		rstDTO.setData(pageInfo);
		rstDTO.setCode("0");
		rstDTO.setMsg("");
		return rstDTO;
	}
	
	@RequestMapping(value="/selectBySupplierIdAndItemId")
	public Map<String, Object> selectBySupplierIdAndItemId(Long supplierId, Long itemId){
		return fxContractItemListService.selectBySupplierIdAndItemId(supplierId, itemId);
	}
	
	@RequestMapping(value="/getMerchantIdsByItemIds")
	public List<Long> getMerchantIdsByItemIds(@RequestBody List<Long> itemIdList){
		return fxContractItemListService.getMerchantIdsByItemIds(itemIdList);
	}
	
	@RequestMapping(value="/selectByItemId")
	public List<FXContractItemListDto> selectByItemId(Long itemId){
		List<FXContractItemListDto> dtoList = new ArrayList<FXContractItemListDto>();
		try{
			List<FXContractItemList> voList = fxContractItemListService.selectByItemId(itemId);
			if(voList!=null && voList.size()>0){
				for(FXContractItemList vo : voList){
					FXContractItemListDto dto = new FXContractItemListDto();
					BeanUtils.copyProperties(dto, vo);
					dtoList.add(dto);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return dtoList;
	}
	
	@RequestMapping(value="/selectByPrimaryKey")
	public FXContractItemList selectByPrimaryKey(Long contractItemId){
		return fxContractItemListService.selectByPrimaryKey(contractItemId);
	}
}
