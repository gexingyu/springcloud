package com.ule.wholesale.fxpurchase.server.config;

import java.util.Properties;

import javax.annotation.Resource;
//import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.Environment;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

import com.github.pagehelper.PageHelper;
import com.ule.wholesale.common.dbconfig.DataBaseMysqlConfiguration;

@Configuration
@Import({ DataBaseMysqlConfiguration.class })
@MapperScan(basePackages = { "com.ule.wholesale.fxpurchase.server.mapper" })
@EnableTransactionManagement
public class MybatisConfiguration implements EnvironmentAware,
		TransactionManagementConfigurer {

	private static Logger logger = LoggerFactory
			.getLogger(MybatisConfiguration.class);

	private RelaxedPropertyResolver propertyResolver;

	@Resource(name = "dataSource")
	private DataSource dataSource;

	@Override
	public void setEnvironment(Environment env) {
		this.propertyResolver = new RelaxedPropertyResolver(env, "mybatis.");
	}

	@Bean
	@ConditionalOnMissingBean
	public SqlSessionFactory sqlSessionFactory() {
		try {
			SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
			// dataSource = SpringBeanUtil.getBean(DataSource.class);
			sessionFactory.setDataSource(dataSource);
			sessionFactory.setTypeAliasesPackage(propertyResolver.getProperty("typeAliasesPackage"));
			sessionFactory
					.setMapperLocations(new PathMatchingResourcePatternResolver()
							.getResources(propertyResolver
									.getProperty("mapperLocations")));
			sessionFactory
					.setConfigLocation(new DefaultResourceLoader()
							.getResource(propertyResolver
									.getProperty("configLocation")));
			//添加分页插件
			sessionFactory.setPlugins(new Interceptor[]{pageHelper()});

			return sessionFactory.getObject();
		} catch (Exception e) {
			logger.warn("Could not confiure mybatis session factory");
			e.printStackTrace();
			return null;
		}
	}

	@Bean
	public SqlSessionTemplate sqlSessionTemplate(
			SqlSessionFactory sqlSessionFactory) {
		return new SqlSessionTemplate(sqlSessionFactory);
	}

	@Bean
	@ConditionalOnMissingBean
	public DataSourceTransactionManager transactionManager() {
		return new DataSourceTransactionManager(dataSource);
	}

	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		return new DataSourceTransactionManager(dataSource);
	}

	@Bean
	public PageHelper pageHelper() {
		logger.info("MyBatisConfiguration.pageHelper()");
		PageHelper pageHelper = new PageHelper();
		Properties p = new Properties();
		p.setProperty("dialect", "mysql");
//		p.setProperty("dialect", "oracle");
		p.setProperty("offsetAsPageNum", "false");
		p.setProperty("rowBoundsWithCount", "false");
		p.setProperty("pageSizeZero", "true");
		p.setProperty("reasonable", "false");
		p.setProperty("supportMethodsArguments", "false");
		p.setProperty("returnPageInfo", "none");
		pageHelper.setProperties(p);
		return pageHelper;
	}
}
