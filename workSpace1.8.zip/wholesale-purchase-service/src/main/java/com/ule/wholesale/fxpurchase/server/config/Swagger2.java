package com.ule.wholesale.fxpurchase.server.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class Swagger2 {

    @Bean
    public Docket createRestApi() {
    	//添加header参数
    	ParameterBuilder tokenPar = new ParameterBuilder();  
    	ParameterBuilder appkeyPar = new ParameterBuilder();  
        List<springfox.documentation.service.Parameter> pars = new ArrayList<springfox.documentation.service.Parameter>();  
        tokenPar.name("token").description("令牌").modelRef(new ModelRef("string")).parameterType("header").required(true).build();  
        appkeyPar.name("appkey").description("APPKEY").modelRef(new ModelRef("string")).parameterType("header").required(true).build();  
        pars.add(tokenPar.build());  
        pars.add(appkeyPar.build());  
        
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.ule.wholesale.fxpurchase.server"))
                .paths(PathSelectors.any())
                .build()
                .globalOperationParameters(pars)
                .apiInfo(apiInfo())
                ;
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Spring Boot中使用Swagger2构建RESTful APIs")
                //.description("更多Spring Boot相关文章请关注")
                //.termsOfServiceUrl("")
                //.contact("")
                .version("1.0")
                .build();
    }

}