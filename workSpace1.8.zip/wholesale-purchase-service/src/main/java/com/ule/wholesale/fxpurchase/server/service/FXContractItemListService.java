package com.ule.wholesale.fxpurchase.server.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.fxpurchase.server.mapper.FXContractItemListMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXContractItemList;

@Service
public class FXContractItemListService {

	private static Logger logger = LoggerFactory.getLogger(FXContractItemListService.class);
	@Autowired
	private FXContractItemListMapper fxContractItemListMapper;
	
	public PageInfo<FXContractItemList> selectEffectiveItemList(Long supplierId,Long merchantId,Long itemId,String itemName,Integer pageNum,Integer pageSize){
		logger.info("获取指定供应商有效商品列表，supplierID="+supplierId+"  merchantId="+merchantId);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("supplierId", supplierId);
		paramMap.put("merchantId", merchantId);
		paramMap.put("itemId", itemId);
		paramMap.put("itemName", itemName);
		PageHelper.startPage(pageNum, pageSize);
		List<FXContractItemList> effectiveItemList = fxContractItemListMapper.selectEffectiveItemList(paramMap);
		PageInfo<FXContractItemList> pageInfo = new PageInfo<FXContractItemList>(effectiveItemList);
		return pageInfo;
	}
	
	public List<FXContractItemList> selectByContractId(Long contractId){
		return fxContractItemListMapper.selectByContractId(contractId);
	}
	
	public PageInfo<FXContractItemList> selectEffectiveItemListByContractId(Map<String,Object> params,Integer pageNum,Integer pageSize,String orderBy){
		PageHelper.startPage(pageNum, pageSize, orderBy);
		List<FXContractItemList> effectiveItemList = fxContractItemListMapper.selectEffectiveItemListByContractId(params);
		PageInfo<FXContractItemList> pageInfo = new PageInfo<FXContractItemList>(effectiveItemList);
		return pageInfo;
	}
	
	public PageInfo<FXContractItemList> getPageByParams(Map<String,Object> params,Integer pageNum,Integer pageSize ,String orderBy){
		PageHelper.startPage(pageNum, pageSize, orderBy);
		List<FXContractItemList> effectiveItemList = fxContractItemListMapper.getPageByParams(params);
		PageInfo<FXContractItemList> pageInfo = new PageInfo<FXContractItemList>(effectiveItemList);
		return pageInfo;
	}
	
	public Map<String, Object> selectBySupplierIdAndItemId(Long supplierId, Long itemId){
		Map<String, Object> retMap = new HashMap<String, Object>();
		//经过merchantId排序的list
		List<FXContractItemList> retList = fxContractItemListMapper.selectBySupplierIdAndItemId(supplierId, itemId);
		if(retList!=null && retList.size()>0){
			Long merchantId = null;
			List<FXContractItemList> tempList = null;
			int temp = 0;
			for(FXContractItemList item : retList){
				if(!(merchantId!=null && merchantId.intValue()==item.getMerchantId().intValue())){
					if(temp>0){
						retMap.put(merchantId.toString(), tempList);
						temp = 0;
					}
					tempList = new ArrayList<FXContractItemList>();
					merchantId = item.getMerchantId();
					temp++;
				}
				tempList.add(item);
			}
			retMap.put(merchantId.toString(), tempList);
		}
		return retMap;
	}
	
	public List<Long> getMerchantIdsByItemIds(List<Long> itemIdList){
		return fxContractItemListMapper.getMerchantIdsByItemIds(itemIdList);
	}
	
	public List<FXContractItemList> selectByItemId(Long itemId){
		return fxContractItemListMapper.selectByItemId(itemId);
	}
	
	public FXContractItemList selectByPrimaryKey(Long contractItemId){
		return fxContractItemListMapper.selectByPrimaryKey(contractItemId);
	}
	
}
