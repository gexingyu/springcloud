package com.ule.wholesale.fxpurchase.server.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ule.wholesale.fxpurchase.server.mapper.BankInfoMapper;
import com.ule.wholesale.fxpurchase.server.vo.BankInfo;

@Service
public class BankInfoService {

	@Autowired
	private BankInfoMapper bankInfoMapper;
	
	public Map<Object, Object> findBankInfoList(){
		Map<Object, Object> map = new HashMap<Object, Object>();
		List<BankInfo> group1 = bankInfoMapper.selectBankInfoGroup1();
		List<BankInfo> group2 = bankInfoMapper.selectBankInfoGroup2();
		List<BankInfo> group3 = bankInfoMapper.selectBankInfoGroup3();
		List<BankInfo> group4 = bankInfoMapper.selectBankInfoGroup4();
		List<BankInfo> group5 = bankInfoMapper.selectBankInfoGroup5();
		map.put("bankInfoGroupOne", group1);
		map.put("bankInfoGroupSecond", group2);
		map.put("bankInfoGroupThree", group3);
		map.put("bankInfoGroupfour", group4);
		map.put("bankInfoGroupfive", group5);
		return map;
	}
	
}
