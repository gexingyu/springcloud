package com.ule.wholesale.fxpurchase.server.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.fxpurchase.server.mapper.FXRequireGoodsListMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXWholesaleOrderGoodsMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXWholesaleOrderMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FxOrderMsgPublishMapper;
import com.ule.wholesale.fxpurchase.server.msghandler.KafkaProducerHandler;
import com.ule.wholesale.fxpurchase.server.vo.FXRequireGoodsList;
import com.ule.wholesale.fxpurchase.server.vo.FXWholesaleOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXWholesaleOrderGoods;
import com.ule.wholesale.fxpurchase.server.vo.FxOrderMsgPublish;

@Service
public class FXWholesaleOrderService {
	
	private static Logger logger = LoggerFactory.getLogger(FXWholesaleOrderService.class);
	
	@Autowired
	private FXWholesaleOrderMapper fxWholesaleOrderMapper;
	@Autowired
	private FXWholesaleOrderGoodsMapper fxWholesaleOrderGoodsMapper;
	@Autowired
	private FxOrderMsgPublishMapper orderMsgPublishMapper;
	@Autowired
	private FXRequireGoodsListMapper fxRequireGoodsListMapper;
	
	public FXWholesaleOrder fingdOrderByOrderId(Long id){
		return fxWholesaleOrderMapper.selectByPrimaryKey(id);
	}
	
	 public PageInfo<FXWholesaleOrder> getList(Map<String, Object> params,Integer pageNum,Integer pageSize){
		 PageHelper.startPage(pageNum, pageSize,"CREATE_TIME DESC,UPDATE_TIME DESC");
		 List<FXWholesaleOrder> lists = fxWholesaleOrderMapper.selectFXWholesaleOrderInfos(params);
		 PageInfo<FXWholesaleOrder> pageInfo = new PageInfo<FXWholesaleOrder>(lists);
		 return pageInfo;
	 }
	
	@Transactional
	public FXWholesaleOrder saveOrder(FXWholesaleOrder order,List<FXWholesaleOrderGoods> itemList) throws Exception{
		logger.info("FXWholesaleOrderService>>>>>>>>save FXWholesaleOrder");
		if(order.getId() == null){
			fxWholesaleOrderMapper.insert(order);
		}else{
			FXWholesaleOrder tmp = fxWholesaleOrderMapper.selectLockByPrimaryKey(order.getId());
			if(tmp.getVersion() != order.getVersion()){
				//数据已被操作
				order.setState(-1);
				return order;
			}
			order.setVersion(order.getVersion() + 1);
			//订单编辑时先删除已有商品，重新插入
			logger.info("批销订单编辑操作，删除已有商品信息");
			fxWholesaleOrderGoodsMapper.deleteByOrderId(order.getId());
			fxWholesaleOrderMapper.updateByPrimaryKey(order);
		}
		logger.info("FXWholesaleOrderService>>>>>>>>batch save FXWholesaleOrderGoods");
		for(FXWholesaleOrderGoods record :itemList){
			record.setOrderId(order.getId());
			fxWholesaleOrderGoodsMapper.insert(record);
		}
		logger.info("FXWholesaleOrderService>>>>>>>>order info save success");
		return order;
	}
	@Transactional
	public boolean createOrderNo(FXWholesaleOrder order){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String,Object> rst = new HashMap<String, Object>();
		rst.put("orderId", order.getId());
		rst.put("createTime", order.getCreateTime());
		rst.put("createDate", sdf.format(order.getCreateTime()));
		Long orderId = order.getId();
		logger.info("FXWholesaleOrderService>>>>>>>>createOrderNo orderId="+orderId);
		try {
			int orderSeq = fxWholesaleOrderMapper.getOrderSeq(rst);
			String seqNo = String.format("%06d", orderSeq);
			String orderNo = rst.get("createDate").toString().replaceAll("-", "")+seqNo;
			logger.info("FXWholesfxWholesaleOrderMapperaleOrderService>>>>>>>>create orderNo="+orderNo);
			//FXPurchaseOrder order = purchaseOrderMapper.selectByPrimaryKey(Long.valueOf(orderId.toString()));
			order.setOrderNo(orderNo);
			fxWholesaleOrderMapper.updateByPrimaryKey(order);
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("orderNo", orderNo);
			params.put("orderId", orderId);
			fxWholesaleOrderGoodsMapper.updateOrderNo(params);
			logger.info("FXWholesaleOrderService>>>>>>>>orderNo update success");
			
			return true;
		} catch (Exception e) {
			fxWholesaleOrderMapper.deleteByPrimaryKey(orderId);
			fxWholesaleOrderGoodsMapper.deleteByOrderId(orderId);
			logger.error("生成批发单编号时发生异常，"+e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * 根据批发单ID获取批发单详细信息，包括批发单商品列表
	 * @param orderId
	 * @return
	 */
	public Map<String,Object> selectdOrderDetailByOrderId(Long orderId){
		logger.info("FXWholesaleOrderService>>>>>>>>selectdOrderDetailByOrderId orderId="+orderId);
		try {
			FXWholesaleOrder order = fxWholesaleOrderMapper.selectByPrimaryKey(orderId);
			List<FXWholesaleOrderGoods> itemList = fxWholesaleOrderGoodsMapper.selectByOrderId(orderId);
			Map<String,Object> orderDetail = new HashMap<String, Object>();
			orderDetail.put("order", order);
			orderDetail.put("itemList", itemList);
			return orderDetail;
		} catch (Exception e) {
			logger.error("selectdOrderDetailByOrderId 获取批发单详情时异常，"+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	public PageInfo<FXWholesaleOrderGoods> selectWhOrderItemList(Map<String,Object> params,Integer pageNum,Integer pageSize){
		PageHelper.startPage(pageNum, pageSize);
		List<FXWholesaleOrderGoods> ordersList=fxWholesaleOrderGoodsMapper.selectByOrg(params);
		PageInfo<FXWholesaleOrderGoods> pageInfo=new PageInfo<FXWholesaleOrderGoods>(ordersList);
		return pageInfo;
	}
	public List<Map<String, Object>> getAgency(Long signCode,Long level){
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
		if(level== null || level > 2){
			return list;
		}
		List<FXWholesaleOrder> fxWholesaleOrders = fxWholesaleOrderMapper.getAgencys(signCode, level);
		if(fxWholesaleOrders != null && fxWholesaleOrders.size()>0){
			for(FXWholesaleOrder po : fxWholesaleOrders){
				if( po == null ) continue ;
				Map<String, Object> resultMap = new HashMap<String, Object>();
				if(level == 0){
					resultMap.put("id", po.getSignProvinceCode());
					resultMap.put("name", po.getSignProvinceName());
				}else if(level == 1){
					resultMap.put("id", po.getSignCityCode());
					resultMap.put("name", po.getSignCityName());
				}else if(level == 2){
					resultMap.put("id", po.getSignRegionCode());
					resultMap.put("name", po.getSignRegionName());
				}
				list.add(resultMap);
			}
		}
		return list;
	}
	
	
@Transactional
public String updateOrderState(Long orderId,Integer state,String auditResult,Integer version,String user,Long userId){
	logger.info("FXWholesaleOrderService >>>>> updateOrderState state="+state);
	FXWholesaleOrder order = fxWholesaleOrderMapper.selectLockByPrimaryKey(orderId);
	if(version != order.getVersion()){
		return "数据已被操作，请更新后再操作";
	}
	String orderNo = "orderNo:";
		if(state == 1){
			//提交订单
			order.setUpdateTime(new Date());
			order.setUpdateUser(user);
			order.setUpdateUserId(userId);
		}else if(state == 2){
			//审核通过
			order.setAuditTime(new Date());
			order.setAuditUser(user);
			order.setAuditUserId(userId);
//			saveKafkaMsg(order,null);
		}else if(state == 3){
			//审核拒绝
			order.setAuditTime(new Date());
			order.setAuditUser(user);
			order.setAuditUserId(userId);
			order.setReason(auditResult);
		}else if(state == 9){

//			if(order.getState() == FxPurchaseStateEnum.WHOLESALE_ORDER_2.getIndex()&&order.getSourceOrderType() == FxPurchaseStateEnum.SOURCE_TYPE_0.getIndex()){
//				if(StringUtils.isBlank(order.getWhOrderNo())){
//					return "与仓库信息同步中，请稍后再试！";
//				}
//				String rst = "";
//				logger.info("commonService.cancelwholesaleOrder=====>>>>"+rst);
//				if(!"".equals(rst)){
//					JSONObject json = JSONObject.parseObject(rst);
//					if("0000".equals(json.getString("code"))){
//						//有包裹订单取消成功，取消本系统订单
//					}else{
//						return json.get("msg").toString();
//					}
//				}else{
//					return "数据请求异常";
//				}
//			}
			if(order.getSourceOrderType() == FxPurchaseStateEnum.SOURCE_TYPE_1.getIndex()){
				//要货清单状态改为未分配
				FXRequireGoodsList fxRequireGoodsList = 
						fxRequireGoodsListMapper.getFXRequireGoodsListDtoByOrderNo(order.getOrderNo(),"2");
				fxRequireGoodsList.setState(FxPurchaseStateEnum.REQUIRE_STATUS_0.getIndex());
				fxRequireGoodsList.setBizOrderId(null);
				fxRequireGoodsList.setBizOrderNo(null);
				fxRequireGoodsList.setBizOrderType(null);
				fxRequireGoodsList.setDistributeTime(null);
				fxRequireGoodsListMapper.updateByPrimaryKey(fxRequireGoodsList);
			}
			order.setCancelTime(new Date());
			order.setCancelUser(user);
		}
		order.setState(state);
		order.setUpdateTime(new Date());
		order.setUpdateUserId(userId);
		order.setUpdateUser(user);
		
		int rst = fxWholesaleOrderMapper.updateByPrimaryKeySelective(order);
		if(rst > 0){
			return orderNo+order.getOrderNo();
		}
		return null;
	}

	public String deleteOrder(Long orderId,String user,Long userId){
		FXWholesaleOrder order = fxWholesaleOrderMapper.selectByPrimaryKey(orderId);
		order.setState(-1);
		order.setCancelTime(new Date());
		order.setCancelUser(user);
		order.setUpdateTime(new Date());
		order.setUpdateUserId(userId);
		order.setUpdateUser(user);
		int rst = fxWholesaleOrderMapper.updateByPrimaryKeySelective(order);
		if(rst > 0){
			return order.getOrderNo();
		}
		return null;
	}
	
	private void saveKafkaMsg(final FXWholesaleOrder order,final List<FXWholesaleOrderGoods> itemList){
		new Thread(){
			@Override
			public void run() {
				List<FXWholesaleOrderGoods> tmpItemList = null;
				logger.info("save FXWholesaleOrder info to schedule");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				FxOrderMsgPublish orderMsg = new FxOrderMsgPublish();
				orderMsg.setBizNo(order.getOrderNo());
				orderMsg.setCreateTime(new Date());
				orderMsg.setStatus(0);
				orderMsg.setType(3);
		
				Map<String,Object> msgMap = new HashMap<String, Object>();
					
				if(itemList == null )
					tmpItemList = fxWholesaleOrderGoodsMapper.selectByOrderId(order.getId());
				else
					tmpItemList = itemList;
				List<Map<String,Object>> inDetailList = new ArrayList<Map<String,Object>>();
				for(FXWholesaleOrderGoods item : tmpItemList){
					Map<String,Object> tmp = new HashMap<String, Object>();
					tmp.put("itemId", item.getItemId());
					tmp.put("quantity", item.getPlanNum());
					inDetailList.add(tmp);
				}
				msgMap.put("inDetailList", inDetailList);
				orderMsg.setMessage(JSONObject.toJSONString(msgMap));
				try{
					logger.info("send FXWholesaleOrder info to kafka ");
					KafkaProducerHandler.sendOrderTopic(order.getOrderNo(), JSONObject.toJSONString(msgMap));
					orderMsg.setStatus(1);
					orderMsgPublishMapper.insert(orderMsg);
				}catch(Exception e){
					logger.error("send FXWholesaleOrder info to kafka error:"+e.getMessage());
					orderMsg.setStatus(0);
					orderMsgPublishMapper.insert(orderMsg);
				}
				
			}
			
		}.start();
	}
}
