package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.BeanUtils;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.dto.FXContractChangeDto;
import com.ule.wholesale.fxpurchase.server.service.FXContractChangeService;
import com.ule.wholesale.fxpurchase.server.service.FXContractItemChangeService;
import com.ule.wholesale.fxpurchase.server.vo.FXContractChange;
import com.ule.wholesale.fxpurchase.server.vo.FXContractItemChange;

@RestController
@Api(value="合同接口服务", tags="合同接口服务")  
@RequestMapping("/api/contractChange")
public class ContractChangeServerController {
	
	private Log logger = LogFactory.getLog(ContractChangeServerController.class);
	@Autowired
	private FXContractChangeService fxContractChangeService;
	@Autowired
	private FXContractItemChangeService fxContractItemChangeService;
	
	@RequestMapping(value="/getPageByParams", method=RequestMethod.POST)
	@ApiOperation("获取合同列表")
	public ResultDTO<Map<String,Object>> getPageByParams(
			@ApiParam(name="params",value="查询条件",required=true)@RequestBody Map<String, Object> params,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize,
			@ApiParam(name="orderBy",value="排序")String orderBy){
		
		ResultDTO<Map<String,Object>> rstDTO = new ResultDTO<Map<String,Object>>();
		try{
			Map<String, Object> rstMap = new HashMap<String, Object>();
			PageInfo<FXContractChangeDto> pageInfo = fxContractChangeService.getPageByParams(params, pageNum, pageSize, orderBy);
			
			rstMap.put("list", pageInfo.getList());
			rstMap.put("pageNum", pageInfo.getPageNum());
			rstMap.put("pages", pageInfo.getPages());
			rstMap.put("total", pageInfo.getTotal());
			
			rstDTO.setCode("0000");
			rstDTO.setData(rstMap);
			return rstDTO;
		}catch(Exception e){
			logger.error("error", e);
			rstDTO.setCode("1111");
			rstDTO.setMsg(e.getMessage());
			return rstDTO;
		}
	}
	
	@RequestMapping(value="/selectByPrimaryKey")
	@ApiOperation("获取合同列表")
	public ResultDTO<FXContractChangeDto> selectByPrimaryKey(@ApiParam(name="changePaperId",value="变更单ID",required=true) Long changePaperId){
		ResultDTO<FXContractChangeDto> rstDTO = new ResultDTO<FXContractChangeDto>();
		try{
			FXContractChange contract = fxContractChangeService.selectByPrimaryKey(changePaperId);
			FXContractChangeDto contractDto = new FXContractChangeDto();
			BeanUtils.copyProperties(contractDto, contract);
			
			rstDTO.setCode("0000");
			rstDTO.setData(contractDto);
			return rstDTO;
		}catch(Exception e){
			logger.error("error", e);
			rstDTO.setCode("1111");
			rstDTO.setMsg(e.getMessage());
			return rstDTO;
		}
	}
	
	@RequestMapping(value="/selectByChangePaperId")
	@ApiOperation("获取合同列表")
	public List<FXContractItemChange> selectByChangePaperId(@ApiParam(name="changePaperId",value="变更单ID",required=true) Long changePaperId){
		return fxContractItemChangeService.selectByChangePaperId(changePaperId);
	}
	
	@RequestMapping(value="/selectDtoByPrimaryKey")
	@ApiOperation("获取合同列表")
	public FXContractChangeDto selectDtoByPrimaryKey(@ApiParam(name="changePaperId",value="变更单ID",required=true) Long changePaperId){
		return fxContractChangeService.selectDtoByPrimaryKey(changePaperId);
	}
	
	@RequestMapping(value="/delFXContractChange")
	public boolean delFXContractChange(Long changePaperId){
		try{
			fxContractChangeService.delFXContractChange(changePaperId);
			return true;
		}catch(Exception e){
			logger.error("error", e);
			return false;
		}
	}
	
	@RequestMapping(value="/delContractChange")
	public boolean delContractChange(@RequestBody FXContractChange fxContractChangeInfo){
		try{
			fxContractChangeService.delContractChange(fxContractChangeInfo);
			return true;
		}catch(Exception e){
			logger.error("error", e);
			return false;
		}
	}
	
	@RequestMapping(value="/updateContractChange")
	public boolean updateContractChange(@RequestBody FXContractChange fxContractChangeInfo){
		try{
			fxContractChangeService.updateContractChange(fxContractChangeInfo);
			return true;
		}catch(Exception e){
			logger.error("error", e);
			return false;
		}
	}
	
	@RequestMapping(value="/compareContractAvailable")
	@ApiOperation("获取合同列表")
	public boolean compareContractAvailable(Long contractId, Long contractChangeId, Date availableBegin, Date availableEnd){
		try{
			return fxContractChangeService.compareContractAvailable(contractId, contractChangeId, availableBegin, availableEnd);
		}catch(Exception e){
			logger.error("error", e);
			return false;
		}
	}
	
	@RequestMapping(value="/changeFXContractInfo")
	public boolean changeFXContractInfo(@RequestBody FXContractChange fxContractChangeInfo){
		try{
			fxContractChangeService.changeFXContractInfo(fxContractChangeInfo);
			return true;
		}catch(Exception e){
			logger.error("error", e);
			return false;
		}
	}
	
	@RequestMapping(value="/createChangePaperCode")
	public boolean createChangePaperCode(Long changePaperId){
		try{
			fxContractChangeService.createChangePaperCode(changePaperId);
			return true;
		}catch(Exception e){
			logger.error("error", e);
			return false;
		}
	}
	
	@RequestMapping(value="/saveItemPriceChange")
	public Long saveItemPriceChange(@RequestBody Map<String,Object> paramsMap){
		try {
			FXContractChange contractChange = new FXContractChange();
			BeanUtils.copyProperties(contractChange,paramsMap.get("contractChange"));
			List<FXContractItemChange> contractItemList = new ArrayList<FXContractItemChange>();
			List<Object> objList = (List<Object>) paramsMap.get("contractItemList");
			if(objList!=null && objList.size()>0){
				for(Object obj : objList){
					FXContractItemChange contractItem = new FXContractItemChange();
					BeanUtils.copyProperties(contractItem,obj);
					contractItemList.add(contractItem);
				}
			}
			return fxContractChangeService.saveItemPriceChange(contractChange, contractItemList);
		} catch (Exception e) {
			logger.error("error", e);
		}
		return null;
	}
	
	@RequestMapping(value="/editItemPriceChange")
	public boolean editItemPriceChange(@RequestBody Map<String,Object> paramsMap, Long userId, String userName){
		try{
			FXContractChange contractChange = new FXContractChange();
			BeanUtils.copyProperties(contractChange,paramsMap.get("contractChange"));
			List<FXContractItemChange> contractItemList = new ArrayList<FXContractItemChange>();
			List<Object> objList = (List<Object>) paramsMap.get("contractItemList");
			if(objList!=null && objList.size()>0){
				for(Object obj : objList){
					FXContractItemChange contractItem = new FXContractItemChange();
					BeanUtils.copyProperties(contractItem,obj);
					contractItemList.add(contractItem);
				}
			}
			fxContractChangeService.editItemPriceChange(contractChange, contractItemList, userId, userName);
			return true;
		} catch (Exception e) {
			logger.error("error", e);
			return false;
		}
	}
	
	@RequestMapping(value="/contractChangeCheck")
	public boolean contractChangeCheck(@RequestBody Map<String,Object> paramsMap, Long userId, String userName){
		try{
			FXContractChange contractChange = new FXContractChange();
			BeanUtils.copyProperties(contractChange,paramsMap.get("contractChange"));
			List<FXContractItemChange> contractItemList = new ArrayList<FXContractItemChange>();
			List<Object> objList = (List<Object>) paramsMap.get("contractItemList");
			if(objList!=null && objList.size()>0){
				for(Object obj : objList){
					FXContractItemChange contractItem = new FXContractItemChange();
					BeanUtils.copyProperties(contractItem,obj);
					contractItemList.add(contractItem);
				}
			}
			fxContractChangeService.contractChangeCheck(contractChange, contractItemList, userId, userName);
			return true;
		} catch (Exception e) {
			logger.error("error", e);
			return false;
		}
	}
	
	@RequestMapping(value="/contractItemStopCheck")
	public boolean contractItemStopCheck(@RequestBody Map<String,Object> paramsMap, Long userId, String userName){
		try{
			FXContractChange contractChange = new FXContractChange();
			BeanUtils.copyProperties(contractChange,paramsMap.get("contractChange"));
			List<FXContractItemChange> contractItemList = new ArrayList<FXContractItemChange>();
			List<Object> objList = (List<Object>) paramsMap.get("contractItemList");
			if(objList!=null && objList.size()>0){
				for(Object obj : objList){
					FXContractItemChange contractItem = new FXContractItemChange();
					BeanUtils.copyProperties(contractItem,obj);
					contractItemList.add(contractItem);
				}
			}
			fxContractChangeService.contractItemStopCheck(contractChange, contractItemList, userId, userName);
			return true;
		} catch (Exception e) {
			logger.error("error", e);
			return false;
		}
	}
}
