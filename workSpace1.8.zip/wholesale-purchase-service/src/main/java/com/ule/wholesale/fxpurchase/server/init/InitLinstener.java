package com.ule.wholesale.fxpurchase.server.init;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.ule.tools.client.kafka.core.config.KafkaClientsConfig;

@Component
public class InitLinstener implements ApplicationListener<ContextRefreshedEvent>{
	private static Log logger = LogFactory.getLog(InitLinstener.class);  
	private static KafkaClientsConfig config = KafkaClientsConfig.DEFAULT_INSTANCE;
	@Override
	public void onApplicationEvent(ContextRefreshedEvent arg0) {
		startRecevier();
		logger.info("consumer init end");
	}
	private static List<String> recevierIds = new ArrayList<String>();
	static{
//		recevierIds.add("kafka_wholesale_purchase_order_consumer_self");
//		recevierIds.add("kafka_wholesale_return_order_consumer_self");
		recevierIds.add("KAFKA_WMS_TO_WHOLESALE_PURCHASE_ORDER_FXPURCHASE");
		recevierIds.add("KAFKA_WMS_TO_WHOLESALE_RETURN_ORDER_FXPURCHASE");
		recevierIds.add("KAFKA_WMS_RECEIPT_TO_PURCHASE_FXPURCHASE");
		recevierIds.add("KAFKA_WMS_WAVE_TO_PURCHASE_FXPURCHASE");
	}
	
	/**
     * 启动消息监听程器
     */
	public static void startRecevier(){
	    try{
	    	if(config == null)
				config = new KafkaClientsConfig("kafka-clients-cfg.xml");//KafkaClientsConfig.DEFAULT_INSTANCE;
            for (int i = 0; i < recevierIds.size(); i++) {
                config.newConsumer(recevierIds.get(i)).startReceive();
                logger.info("开始启动消息监听程器：" + recevierIds.get(i));
            }
        } catch (Exception e) {
            logger.error("Kafka消息监听程器异常！", e);
        }
	}

}
