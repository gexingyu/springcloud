package com.ule.wholesale.fxpurchase.server.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cloud.client.ServiceInstance;
//import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ecwid.consul.v1.ConsulClient;
import com.ecwid.consul.v1.Response;
import com.ecwid.consul.v1.health.model.HealthService;
import com.ecwid.consul.v1.kv.KeyValueClient;
import com.ecwid.consul.v1.kv.model.GetValue;
//import com.ecwid.consul.v1.ConsulClient;
//import com.ecwid.consul.v1.Response;
//import com.ecwid.consul.v1.health.model.HealthService;
//import com.ecwid.consul.v1.kv.KeyValueClient;
//import com.ecwid.consul.v1.kv.model.GetValue;
import com.github.pagehelper.PageHelper;
import com.ule.tools.client.kafka.producer.Message;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.HttpClientUtil;
import com.ule.wholesale.common.util.MD5Tools;
import com.ule.wholesale.fxpurchase.server.config.ServerConstants;
import com.ule.wholesale.fxpurchase.server.init.SpringBeanUtil;
import com.ule.wholesale.fxpurchase.server.mapper.FXPurchaseOrderGoodsMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXPurchaseOrderMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXReturnOrderGoodsMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXReturnOrderMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FxOrderMsgConsumerMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FxOrderMsgPublishMapper;
import com.ule.wholesale.fxpurchase.server.msghandler.KafkaProducerHandler;
import com.ule.wholesale.fxpurchase.server.vo.FXOperationLog;
import com.ule.wholesale.fxpurchase.server.vo.FXPurchaseOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXPurchaseOrderGoods;
import com.ule.wholesale.fxpurchase.server.vo.FXReturnOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXReturnOrderGoods;
import com.ule.wholesale.fxpurchase.server.vo.FxOrderMsgConsumer;
import com.ule.wholesale.fxpurchase.server.vo.FxOrderMsgPublish;

@Service
public class FxCommonService {

	@Autowired
	FxOrderMsgPublishMapper msgPublishMapper;
	
	@Autowired
	FxOrderMsgConsumerMapper consumerMapper;
	@Autowired
	FXPurchaseOrderMapper purchaseOrderMapper;
	@Autowired
	FXPurchaseOrderGoodsMapper purchaseOrderGoodsMapper;
	@Autowired
	FXReturnOrderMapper returnOrderMapper;
	@Autowired
	FXReturnOrderGoodsMapper returnOrderGoodsMapper;
	@Autowired
	FXOperationLogService operationLogService;
	@Autowired
	FxOrderMsgPublishMapper publishMapper;
	
	private static Logger logger = LoggerFactory.getLogger(FxCommonService.class);
	public List<Map<String,Object>> getUleMerchantList(String orgId){
		 List<Map<String,Object>> merchantList = new ArrayList<Map<String,Object>>();
		 logger.info("当前登录账户的机构ID="+orgId);
		 String rst = getUleSelfSupportMerchantList(orgId);
		 if(rst != null && !"".equals(rst)){
			 JSONObject json = JSONObject.parseObject(rst);
			 if(json != null && json.get("returnCode") != null && "0000".equals(json.getString("returnCode"))){
				 JSONArray jsonArr = JSONArray.parseArray(json.getString("returnData"));
				 for(Object obj : jsonArr){
					 JSONObject d = (JSONObject) obj;
					 String mId = d.getString("usrOnlyid");
					 String mName = d.getString("usrTrueName");
					 Map<String,Object> map = new HashMap<String, Object>();
					 map.put("merchantId", mId);
					 map.put("merchantName", mName);
					 merchantList.add(map);
				 }
			 }
		 }
		 if(StringUtils.isNotBlank(ServerConstants.betaTestMerchant)){
			 Map<String,Object> map = new HashMap<String, Object>();
			 map.put("merchantId",ServerConstants.betaTestMerchant.split("-")[0]);
			 map.put("merchantName",ServerConstants.betaTestMerchant.split("-")[1]);
			 merchantList.add(map);
		 }
		 return merchantList;
	 }
	
	//获取kafka信息发送到kafka
	public void sendMsg(){
//		if(!isDefaultServer())
//			return;
		List<Long> publishList = new ArrayList<Long>();
		logger.info("发送schedule表中的消息到kafka");
		List<Message<String>> orderMsgList = new ArrayList<Message<String>>();
		List<Message<String>> returnOrderMsgList = new ArrayList<Message<String>>();
		//从消息表获取待发送消息列表  status 0
		List<FxOrderMsgPublish> msgList = msgPublishMapper.selectByStatusAndType(0, null);
		if(msgList == null || msgList.size() == 0){
			return ;
		}
		// 根据type判断是采购订单还是退货订单1采购订单消息，2退货订单消息
		for(FxOrderMsgPublish msg : msgList){
			if(msg.getType() == 1){
				FXPurchaseOrder order = purchaseOrderMapper.selectByOrderNo(msg.getBizNo());
				if(order!=null && order.getIsPrepay() == 1 
						|| (order.getPrepayAmt() == null || order.getPrepayAmt().floatValue() == 0)){
					Message<String> m = new Message<String>(msg.getBizNo(), msg.getMessage());
					orderMsgList.add(m);
					publishList.add(msg.getId());
				}
			}else if(msg.getType() == 2){
				Message<String> m = new Message<String>(msg.getBizNo(), msg.getMessage());
				returnOrderMsgList.add(m);
				publishList.add(msg.getId());
			}
		}
		//消息组装后批量发布到kafka KafakaProudcer
		logger.info("batchSendOrderTopic start");
		if(orderMsgList.size() > 0)
			KafkaProducerHandler.batchSendOrderTopic(orderMsgList);
		logger.info("batchSendOrderTopic end");
		logger.info("batchSendReturnOrderTopic start");
		if(returnOrderMsgList.size() > 0)
			KafkaProducerHandler.batchSendReturnOrderTopic(returnOrderMsgList);
		logger.info("batchSendReturnOrderTopic end");
		logger.info("消息发送成功后，更新消息表中的状态为已发送1");
		Map<String,Object> params = new HashMap<String, Object>();
		if(publishList != null && publishList.size()>0){
			params.put("idList", publishList);
			params.put("status", 1);
			msgPublishMapper.updateByIdList(params);
		}
	}
	/**
	 * 获取邮乐自营商家列表
	 * @param orgunitLev1
	 * @return
	 */
	public String getUleSelfSupportMerchantList(String orgunitLev1){
		logger.info("getUleSelfSupportMerchantList  orgunitLev1="+orgunitLev1);
		
		Map<String,String> headMap = new HashMap<String, String>();
		String requestTime = System.currentTimeMillis()+"";
//		try {
//			requestTime = (new SimpleDateFormat("yyyy-MM-dd HH:MM:ss").parse(WebDateUtils.getWebsiteDatetime(null)).getTime())+"";
//		} catch (ParseException e1) {
//			requestTime = System.currentTimeMillis()+"";
//		}//System.currentTimeMillis()+"";
		headMap.put("appKey", requestTime + "|" + MD5Tools.md5(requestTime.substring(2, 12)));
		
		Map<String,Object> paramMap = new HashMap<String, Object>();
		if(orgunitLev1 != null)
			paramMap.put("orgunitLev1",orgunitLev1);
		String result = "";
		try {
			result = HttpClientUtil.sendPost(ServerConstants.uleSelfSupport,headMap,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public String getMerchantItemStorage(Long merchantId,Long whId,List<Long> itemIds){
		logger.info("getMerchantWarehouseList  merchantId="+merchantId);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("merchantOnlyId",merchantId);
		paramMap.put("whId",whId);
		if(itemIds != null && itemIds.size() > 0)
			paramMap.put("itemIds",StringUtils.join(itemIds, ","));
		//?merchantOnlyId=1&whId=1&itemIds
		String result = "";
		try {
			result = HttpClientUtil.sendPost(ServerConstants.itemsStorage,null,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 作废入库通知单
	 * @param orderNo
	 * @param warehouseId
	 * @return
	 */
	public String cancelPurcahseOrder(String orderNo,Long warehouseId){
		logger.info("cancelPurcahseOrder  orderNo="+orderNo);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("customerOrderNo",orderNo);
		paramMap.put("warehouseId",warehouseId);
		String result = "";
		try {
			result = HttpClientUtil.sendPost(ServerConstants.cancelPurchaseOrder,null,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 作废出库通知单
	 * @param orderNo
	 * @return
	 */
	public String cancelReturnOrder(String orderNo){
		logger.info("cancelPurcahseOrder  orderNo="+orderNo);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("customerOrderNo",orderNo);
		String result = "";
		try {
			result = HttpClientUtil.sendPost(ServerConstants.cancelReturnOrder,null,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	
	//创建采购订单出库消息消费状态反馈，调用创建接口之后，返回消费状态
	public void purchaseOrderCreateConsumerFeedback(String key, String message){
		if(!isDefaultServer()){
			return ;
		}
		if(consumerMapper == null)
			consumerMapper = SpringBeanUtil.getBean(FxOrderMsgConsumerMapper.class);
		logger.info("purchaseOrderFinishFeedback>>>>>>>>>key="+key+" message="+message);
		List<FxOrderMsgConsumer> consumerList = consumerMapper.selectByBizCodeAndType(key, 1);
		if(consumerList != null && consumerList.size() > 0)
			return ;
		FxOrderMsgConsumer consumer = new FxOrderMsgConsumer();
		consumer.setBizNo(key);
		consumer.setMessage(message);
		consumer.setStatus(0);
		consumer.setType(1);
		consumer.setCreateTime(new Date());
		
		consumerMapper.insert(consumer);
		
	}
	
	//采购订单入库接口反馈,触发点，退货订单出库
	public void purchaseOrderFinishFeedback(String key, String message){
		if(!isDefaultServer()){
			return ;
		}
		if(consumerMapper == null)
			consumerMapper = SpringBeanUtil.getBean(FxOrderMsgConsumerMapper.class);
		logger.info("purchaseOrderFinishFeedback>>>>>>>>>key="+key+" message="+message);
		List<FxOrderMsgConsumer> consumerList = consumerMapper.selectByBizCodeAndType(key, 2);
		if(consumerList != null && consumerList.size() > 0)
			return ;
		FxOrderMsgConsumer consumer = new FxOrderMsgConsumer();
		consumer.setBizNo(key);
		consumer.setMessage(message);
		consumer.setStatus(0);
		consumer.setType(2);
		consumer.setCreateTime(new Date());
		
		consumerMapper.insert(consumer);
		
	}
		
	
	//创建退货订单出库消息消费状态反馈，调用创建接口之后，返回消费状态
	public void returnOrderCreateConsumerFeedback(String key, String message){
		if(!isDefaultServer()){
			return ;
		}
		if(consumerMapper == null)
			consumerMapper = SpringBeanUtil.getBean(FxOrderMsgConsumerMapper.class);
		logger.info("returnOrderCreateConsumerFeedback>>>>>>>>>key="+key+" message="+message);
		List<FxOrderMsgConsumer> consumerList = consumerMapper.selectByBizCodeAndType(key, 3);
		if(consumerList != null && consumerList.size() > 0)
			return ;
		FxOrderMsgConsumer consumer = new FxOrderMsgConsumer();
		consumer.setBizNo(key);
		consumer.setMessage(message);
		consumer.setStatus(0);
		consumer.setType(3);
		consumer.setCreateTime(new Date());
		
		consumerMapper.insert(consumer);
		
	}
	//退货订单入库接口反馈,触发点，退货订单出库
	public void returnOrderFinishFeedback(String key, String message){
		if(!isDefaultServer()){
			return ;
		}
		if(consumerMapper == null)
			consumerMapper = SpringBeanUtil.getBean(FxOrderMsgConsumerMapper.class);
		logger.info("returnOrderFinishFeedback>>>>>>>>>key="+key+" message="+message);
		List<FxOrderMsgConsumer> consumerList = consumerMapper.selectByBizCodeAndType(key, 4);
		if(consumerList != null && consumerList.size() > 0)
			return ;
		FxOrderMsgConsumer consumer = new FxOrderMsgConsumer();
		consumer.setBizNo(key);
		consumer.setMessage(message);
		consumer.setStatus(0);
		consumer.setType(4);
		consumer.setCreateTime(new Date());
		
		consumerMapper.insert(consumer);
		
	}
	
	//获取kafka保存到数据库信息并处理
	@Transactional
	public void handlerMsg() throws Exception{
		if(!isDefaultServer()){
			return ;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<Long> consumerList = new ArrayList<Long>();
		List<Long> consumerErrorList = new ArrayList<Long>();
//		List<String> errorConsumerOrderNoList = new ArrayList<String>();
//		List<String> errorConsumerReturnOrderNoList = new ArrayList<String>();
		logger.info("获取schedule表中的消息");
		//从消息表获取待发送消息列表  status 0，每次查询100条记录进行处理
		PageHelper.startPage(1, 100, "CREATE_TIME");
		List<FxOrderMsgConsumer> msgList = consumerMapper.selectByStatusAndType(0, null);
		if(msgList == null || msgList.size() == 0){
			logger.info(">>>>>>>>>>>>>>schedule 没有需要处理的任务");
			return ;
		}else{
			logger.info(">>>>>>>>>>>>>>schedule 待处理任务数为 "+msgList.size());
		}
		for(FxOrderMsgConsumer msg : msgList){
			logger.info("msg>>>>>>>>>>>>>"+msg.getMessage());
			try {
				
				if(msg.getType() == 1){
					logger.info("采购订单创建消息反馈，更新仓库订单编号到采购订单表");
					JSONObject json = JSONObject.parseObject(msg.getMessage());
					if("0".equals(json.getString("state"))){
						String whOrderNo = json.getString("storageOrderNo");
						if(whOrderNo != null){
							FXPurchaseOrder order = purchaseOrderMapper.selectByOrderNo(json.getString("orderNo"));
							order.setWhOrderNo(whOrderNo);
							
							order.setUpdateTime(new Date());
							order.setUpdateUserId(0L);
							order.setUpdateUser("System");
							purchaseOrderMapper.updateByPrimaryKey(order);
							
							logger.info("采购订单消息消费成功，入库通知单已创建成功");
							FXOperationLog log = new FXOperationLog();
							log.setUserName("System");
							log.setUserId(0L);
							log.setBizCode(order.getOrderNo());
							log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
							log.setEventType("邮包裹创建入库单成功");
							log.setOpDate(new Date());
							log.setRemark("入库单编号:"+whOrderNo);
							operationLogService.saveOpLog(log);
						}
					}else{
						//消费失败的订单消息是否需要重新发送订单消息
						//errorConsumerOrderNoList.add(json.getString("orderNo"));
						logger.info("采购订单消息消费成功，入库通知单创建失败");
						FXOperationLog log = new FXOperationLog();
						log.setUserName("System");
						log.setUserId(0L);
						log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
						log.setEventType("仓库订单创建失败");
						log.setOpDate(new Date());
						log.setRemark(json.get("message")== null?"":json.getString("message"));
						operationLogService.saveOpLog(log);
					}
				}else if(msg.getType() == 3){
					logger.info("退货订单创建消息反馈，更新仓库订单编号到退货订单表");
					JSONObject json = JSONObject.parseObject(msg.getMessage());
					if("0".equals(json.getString("state"))){
						String whOrderNo = json.getString("storageOrderNo");
						if(whOrderNo != null){
							FXReturnOrder order = returnOrderMapper.selectByOrderNo(json.getString("orderNo"));
							order.setWhOrderNo(whOrderNo);
							order.setUpdateTime(new Date());
							order.setUpdateUserId(0L);
							order.setUpdateUser("System");
							returnOrderMapper.updateByPrimaryKey(order);
							
							logger.info("退货订单消息消费成功，出库通知单已创建成功");
							FXOperationLog log = new FXOperationLog();
							log.setUserName("System");
							log.setUserId(0L);
							log.setBizCode(order.getOrderNo());
							log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
							log.setEventType("邮包裹创建退货单成功");
							log.setOpDate(new Date());
							log.setRemark("退货单编号:"+whOrderNo);
							operationLogService.saveOpLog(log);
							
						}
					}else if("-1".equals(json.getString("state"))){
						logger.info("此状态为邮包裹商品没有库存，邮包裹不会创建没有库存的退货订单，返回此状态是本系统默认为已收货，收货数量为0");
						FXReturnOrder order = returnOrderMapper.selectByOrderNo(json.getString("orderNo"));
						
						if(order != null && order.getState() != FxPurchaseStateEnum.STATE_ORDER_9.getIndex()){
							logger.info("更新无库存商品的收货数量为0");
							order.setReturnUser("System");
							order.setReturnTime(new Date());
							order.setWhReturnTime(new Date());
							order.setWhOrderNo("--");
							order.setState(8);//商品已出库。已退货
							order.setUpdateTime(new Date());
							order.setUpdateUserId(0L);
							order.setUpdateUser("System");
							order.setRemark(StringUtils.isNotEmpty(order.getRemark())?order.getRemark()+""+"<br/> ":""+"仓库无库存，系统自动按0退货");
							//更新实收数量到商品表中
							List<FXReturnOrderGoods> goodsList = returnOrderGoodsMapper.selectByOrderId(order.getId());
							if(goodsList != null && goodsList.size() > 0){
								for(FXReturnOrderGoods item : goodsList){
									item.setReceiptNum(0);
									item.setReceiptAmt(BigDecimal.ZERO);
									returnOrderGoodsMapper.updateByPrimaryKey(item);
								}
								order.setGoodsReceiptNum(0);
								order.setOrderActualAmt(BigDecimal.ZERO);
								returnOrderMapper.updateByPrimaryKey(order);
								
								logger.info("退货订单消息消费成功，商品库存为0，自动收货，收货数量为0");
								FXOperationLog log = new FXOperationLog();
								log.setUserName("System");
								log.setUserId(0L);
								log.setBizCode(order.getOrderNo());
								log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
								log.setEventType("出库成功");
								log.setOpDate(new Date());
								log.setRemark("仓库无库存，系统自动按0退货");
								operationLogService.saveOpLog(log);
							}
								
						}
						
					}else{
						//errorConsumerReturnOrderNoList.add(json.getString("orderNo"));
						logger.info("退货订单消息消费成功，出库通知单创建失败");
						FXOperationLog log = new FXOperationLog();
						log.setUserName("System");
						log.setUserId(0L);
						log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
						log.setEventType("仓库订单创建失败");
						log.setOpDate(new Date());
						log.setRemark(json.get("message")== null?"":json.getString("message"));
						operationLogService.saveOpLog(log);
					}
				}else if(msg.getType() == 2){
					logger.info("采购订单入库信息反馈");
					JSONObject json = JSONObject.parseObject(msg.getMessage());
					String consignee = json.getString("consignee");
					String receivingTime = json.getString("receivingTime");
					String inTime = json.getString("inTime");
					String whOrderNo = json.getString("storageOrderNo");
					FXPurchaseOrder order = purchaseOrderMapper.selectByOrderNo(json.getString("orderNo"));
					if(order != null){
						order.setReceiver(consignee);
						order.setReceiptTime(sdf.parse(inTime));
						order.setWhReceiptTime(sdf.parse(receivingTime));
						order.setWhOrderNo(whOrderNo);
						order.setState(8);
						order.setUpdateTime(new Date());
						order.setUpdateUserId(0L);
						order.setUpdateUser("System");
						logger.info("采购订单，更新实收数量到商品表中");
						List<FXPurchaseOrderGoods> goodsList = purchaseOrderGoodsMapper.selectByOrderId(order.getId());
						if(goodsList != null && goodsList.size() > 0){
							Map<Long,Integer> itemInfo = new HashMap<Long, Integer>();
							List<Long> erritemInfo = new ArrayList<Long>();
							if(json.get("detailList") != null){
								List<Long> itemIds = new ArrayList<Long>();
								for(FXPurchaseOrderGoods g : goodsList){
									itemIds.add(g.getItemId());
								}
								JSONArray jsonArr = JSONArray.parseArray(json.get("detailList").toString());
								logger.info("验证返回的商品列表是否存在非定点中的商品 detailList="+json.get("detailList"));
								for(Object obj : jsonArr){
									JSONObject data = (JSONObject) obj;
									Long itemId = data.getLong("skuCode");
									Integer num = data.getInteger("quantity");
									if(itemInfo.get(itemId) != null){
										itemInfo.put(itemId, itemInfo.get(itemId)+num);
									}else
										itemInfo.put(itemId, num);
									logger.info("itemId="+itemId);
									if(!itemIds.contains(itemId)){
										logger.info("itemId="+itemId+" 在采购订单中不存在");
										erritemInfo.add(itemId);
									}
								}
								if(erritemInfo.size() == 0){
									logger.info(">>>>>>>>>>>>>>>>>>>>更新订单信息和商品数量");
									Integer actNum = 0;
									BigDecimal actAmt = new BigDecimal(0);
									for(FXPurchaseOrderGoods item : goodsList){
										Long itemId = item.getItemId();
										if(itemInfo.containsKey(itemId)){
											item.setReceiptNum(itemInfo.get(itemId));
											BigDecimal receiptAmt = item.getUnitPrice().multiply(new BigDecimal(itemInfo.get(itemId)));
											item.setReceiptAmt(receiptAmt);
											actNum += itemInfo.get(itemId);
											actAmt = receiptAmt.add(actAmt);
											purchaseOrderGoodsMapper.updateByPrimaryKey(item);
										}else{
											item.setReceiptNum(0);
											item.setReceiptAmt(BigDecimal.ZERO);
											purchaseOrderGoodsMapper.updateByPrimaryKey(item);
										}
									}
									order.setGoodsReceiptNum(actNum);
									order.setOrderActualAmt(actAmt);
									purchaseOrderMapper.updateByPrimaryKey(order);
									
									logger.info("采购订单已收货");
									FXOperationLog log = new FXOperationLog();
									log.setUserName("System");
									log.setUserId(0L);
									log.setBizCode(order.getOrderNo());
									log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
									log.setEventType("入库单商品入库成功");
									log.setOpDate(new Date());
									log.setRemark("入库单编号:"+whOrderNo);
									operationLogService.saveOpLog(log);
								}else{
									//返回明细中存在非定单中的商品
									logger.info("返回的商品明细存在非采购订单采购的商品");
									FXOperationLog log = new FXOperationLog();
									log.setUserName("System");
									log.setUserId(0L);
									log.setBizCode(order.getOrderNo());
									log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
									log.setEventType("入库单商品不一致");
									log.setOpDate(new Date());
									log.setRemark("返回明细中存在非定单中的商品"+erritemInfo.toString());
									operationLogService.saveOpLog(log);
								}
							}
							
						}else{
							logger.info("采购订单没有商品信息");
							order.setGoodsReceiptNum(0);
							order.setOrderActualAmt(BigDecimal.ZERO);
							purchaseOrderMapper.updateByPrimaryKey(order);
							
							logger.info("采购订单没有商品信息");
							FXOperationLog log = new FXOperationLog();
							log.setUserName("System");
							log.setUserId(0L);
							log.setBizCode(order.getOrderNo());
							log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
							log.setEventType("采购订单没有商品信息");
							log.setOpDate(new Date());
							log.setRemark("入库单编号:"+whOrderNo);
							operationLogService.saveOpLog(log);
						}
					}
					
					
				}else if(msg.getType() == 4){
					logger.info("更新仓库退货单编号到退货订单表,采购订单入库信息反馈");
					JSONObject json = JSONObject.parseObject(msg.getMessage());
					String consignee = json.getString("consignee");
					String returnTime = json.getString("returnTime");
					String outTime = json.getString("outTime");
					String whOrderNo = json.getString("storageOrderNo");
					FXReturnOrder order = returnOrderMapper.selectByOrderNo(json.getString("orderNo"));
					
					if(order != null){
						order.setReturnUser(consignee);
						order.setReturnTime(sdf.parse(outTime));
						order.setWhReturnTime(sdf.parse(returnTime));
						order.setWhOrderNo(whOrderNo);
						order.setState(8);//商品已出库。已退货
						order.setUpdateTime(new Date());
						order.setUpdateUserId(0L);
						order.setUpdateUser("System");
						//更新实收数量到商品表中
						List<FXReturnOrderGoods> goodsList = returnOrderGoodsMapper.selectByOrderId(order.getId());
						if(goodsList != null && goodsList.size() > 0){
							Map<Long,Integer> itemInfo = new HashMap<Long, Integer>();
							List<Long> errItemInfo = new ArrayList<Long>();
							if(json.get("detailList") != null){
								List<Long> itemIds = new ArrayList<Long>();
								for(FXReturnOrderGoods g : goodsList){
									itemIds.add(g.getItemId());
								}
								JSONArray jsonArr = JSONArray.parseArray(json.get("detailList").toString());
								for(Object obj : jsonArr){
									JSONObject data = (JSONObject) obj;
									Long itemId = data.getLong("skuCode");
									Integer num = data.getInteger("quantity");
									if(itemInfo.get(itemId) != null){
										itemInfo.put(itemId, itemInfo.get(itemId)+num);
									}else
										itemInfo.put(itemId, num);
									if(!itemIds.contains(itemId)) errItemInfo.add(itemId);
								}
							}
							if(errItemInfo.size() == 0){
								Integer actNum = 0;
								BigDecimal actAmt = new BigDecimal(0);
								for(FXReturnOrderGoods item : goodsList){
									Long itemId = item.getItemId();
									if(itemInfo.containsKey(itemId)){
										item.setReceiptNum(itemInfo.get(itemId));
										BigDecimal receiptAmt = item.getUnitPrice().multiply(new BigDecimal(itemInfo.get(itemId)));
										item.setReceiptAmt(receiptAmt);
										actNum += itemInfo.get(itemId);
										actAmt = receiptAmt.add(actAmt);
									}else{
										item.setReceiptNum(0);
										item.setReceiptAmt(BigDecimal.ZERO);
									}
									returnOrderGoodsMapper.updateByPrimaryKey(item);
								}
								order.setGoodsReceiptNum(actNum);
								order.setOrderActualAmt(actAmt);
								returnOrderMapper.updateByPrimaryKey(order);
								
								logger.info("退货订单商品已出库");
								FXOperationLog log = new FXOperationLog();
								log.setUserName("System");
								log.setUserId(0L);
								log.setBizCode(order.getOrderNo());
								log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
								log.setEventType("出库单商品出库成功");
								log.setOpDate(new Date());
								log.setRemark("出库单编号:"+whOrderNo);
								operationLogService.saveOpLog(log);
							}else{
								//返回明细中存在非定单中的商品
								logger.info("返回的商品信息存在非退货单退货的商品");
								FXOperationLog log = new FXOperationLog();
								log.setUserName("System");
								log.setUserId(0L);
								log.setBizCode(order.getOrderNo());
								log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
								log.setEventType("出库单商品不一致");
								log.setOpDate(new Date());
								log.setRemark("返回明细中存在非定单中的商品"+errItemInfo.toString());
								operationLogService.saveOpLog(log);
							}
						}else{
							//没有商品信息
							order.setGoodsReceiptNum(0);
							order.setOrderActualAmt(BigDecimal.ZERO);
							returnOrderMapper.updateByPrimaryKey(order);
							
							logger.info("出库单没有商品明细");
							FXOperationLog log = new FXOperationLog();
							log.setUserName("System");
							log.setUserId(0L);
							log.setBizCode(order.getOrderNo());
							log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
							log.setEventType("出库单没有商品信息");
							log.setOpDate(new Date());
							log.setRemark("出库单编号:"+whOrderNo);
							operationLogService.saveOpLog(log);
						}
					}
					
				}
				consumerList.add(msg.getId());
			} catch (Exception e) {
				consumerErrorList.add(msg.getId());
				logger.error("处理反馈消息异常：下次定时时间会再次处理，如果是数据问题请手动处理");
				e.printStackTrace();
			}
			
		}
		if(consumerList.size() > 0){
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("idList", consumerList);
			params.put("status", 1);
			consumerMapper.updateByIdList(params);
		}
		//失败记录，更新执行次数+1，状态不变，下次继续执行
		if(consumerErrorList.size() > 0){
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("idList", consumerErrorList);
			params.put("status", 0);
			consumerMapper.updateByIdList(params);
		}
		
	}
	
	public List<FxOrderMsgPublish> getPublishList(String bizNo,Integer type){
		
		return publishMapper.selectByBizCodeAndType(bizNo, type);
	}
	public List<FxOrderMsgConsumer> getConsumerList(String bizNo,Integer type){
		
		return consumerMapper.selectByBizCodeAndType(bizNo, type);
	}
	
	@Autowired
	private DiscoveryClient discoveryClient;
	@Autowired
	private KeyValueClient keyValueClient;
	
	@Autowired
	private ConsulClient consulClient;
	
	@Value("${spring.application.name:FXPURCHASE-SERVER}")
	private String applicationName;
	
	/**
	 * 获取consul下的服务数量，用来判断定时和kafka的执行，如果服务数量为一就直接执行，如果是多个就要做处理了
	 * @return
	 */
	private boolean isDefaultServer(){
		logger.info("获取consul下的服务数量，用来判断定时和kafka的执行，如果服务数量为一就直接执行，如果是多个就要指定第一个启动的为默认执行定时和消息逻辑");
		
		List<HealthService> response = consulClient.getHealthServices(applicationName, false, null).getValue();
		if (response != null && response.size() > 0) {
			for (int n = 0; n < response.size(); n++) {
				HealthService service = response.get(n);
				// 先移除当前服务的down的服务
				for(com.ecwid.consul.v1.health.model.Check check : service.getChecks()){
					if (check.getStatus() != com.ecwid.consul.v1.health.model.Check.CheckStatus.PASSING) {
						logger.info("unregister : {}",check.getServiceId());
						consulClient.agentServiceDeregister(check.getServiceId());
					}
				}
			}
		}
		List<ServiceInstance> serviceList = discoveryClient.getInstances(applicationName);
		if(serviceList == null || serviceList.size() == 0 || serviceList.size() == 1){
			keyValueClient.deleteKVValue(applicationName);
		}
		if(serviceList.size() > 0){
			//判断key中存储的默认执行定时和kafka消息的服务是否还存在，如果不存在删除key值，重新制定执行服务
			boolean exist = false;
			String defServer = "";
			for(ServiceInstance serviceInstance : serviceList){
				String ip = serviceInstance.getHost();
				Integer port = serviceInstance.getPort();
				defServer = MD5Tools.md5(ip+":"+port)+(ip.substring(ip.lastIndexOf("."))+"."+port);
				String v = getOrSetConsulKV(applicationName);
				if(defServer.equals(v)){
					exist = true;
					break;
				}
			}
			
			logger.info(">>>>>>>Consul中启动了服务"+applicationName+">>>"+serviceList.toString());
			ServiceInstance serviceInstance = serviceList.get(0);
			String ip = serviceInstance.getHost();
			Integer port = serviceInstance.getPort();
			String md5 = MD5Tools.md5(ip+":"+port)+(ip.substring(ip.lastIndexOf("."))+"."+port);
			logger.info("通过consul的key value功能，设置第一个启动的服务为消息监听和Timer的执行者");
			if(!exist){
				keyValueClient.setKVValue(applicationName, md5);
			}else{
				return md5.equals(defServer);
			}
		}
		return true;
	}
	private String getOrSetConsulKV(String key){
		Response<GetValue> kv = keyValueClient.getKVValue(key);
		if(kv != null && kv.getValue() != null){
			String v = kv.getValue().getDecodedValue();
			return v;
		}
		
		return null;
	}
	
}
