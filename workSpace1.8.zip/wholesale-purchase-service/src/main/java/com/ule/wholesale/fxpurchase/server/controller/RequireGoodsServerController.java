package com.ule.wholesale.fxpurchase.server.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.dto.FXRequireGoodsListDto;
import com.ule.wholesale.fxpurchase.server.service.FXOperationLogService;
import com.ule.wholesale.fxpurchase.server.service.FXPurchaseOrderService;
import com.ule.wholesale.fxpurchase.server.service.FXRequireGoodsService;
import com.ule.wholesale.fxpurchase.server.vo.FXRequireGoodsList;

@RestController
@Api(value="要货清单接口服务", tags="要货清单接口服务")  
@RequestMapping("/api/require")
public class RequireGoodsServerController {
	
	private Log logger = LogFactory.getLog(RequireGoodsServerController.class);
	
	@Autowired
	private FXRequireGoodsService fxRequireGoodsService;
	@Autowired
	private FXOperationLogService fxOperationLogService;
	@Autowired
	private FXPurchaseOrderService fxPurchaseOrderService;
	
	@RequestMapping(value="/getPageByParams", method=RequestMethod.POST)
	@ApiOperation("要货清单列表")
	public ResultDTO<Map<String,Object>> getPageByParams(
			@ApiParam(name="params",value="查询条件",required=true)@RequestBody Map<String, Object> params,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize,
			@ApiParam(name="orderBy",value="排序")String orderBy){
		ResultDTO<Map<String,Object>> rstDTO = new ResultDTO<Map<String,Object>>();
		Map<String, Object> rstMap = new HashMap<String, Object>();
		
		PageInfo<FXRequireGoodsListDto> pageInfo = fxRequireGoodsService.getPageByParams(params, pageNum, pageSize, orderBy);
		rstMap.put("list", pageInfo.getList());
		rstMap.put("pageNum", pageInfo.getPageNum());
		rstMap.put("pages", pageInfo.getPages());
		rstMap.put("total", pageInfo.getTotal());
		
		rstDTO.setData(rstMap);
		rstDTO.setCode("0");
		rstDTO.setMsg("");
		return rstDTO;
	}
	
	@RequestMapping(value="/saveRequireGoods")
	public List<String> saveRequireGoods(@RequestBody FXRequireGoodsList rqGoods){
		List<FXRequireGoodsList> rqGoodsList = new ArrayList<FXRequireGoodsList>();
		rqGoodsList.add(rqGoods);
		return fxRequireGoodsService.saveRequireGoods(rqGoodsList);
	}
	
	@RequestMapping(value="/saveRequireGoodsOfBatch")
	public List<String> saveRequireGoodsOfBatch(@RequestBody List<FXRequireGoodsListDto> rqGoodsDtoList){
		try{
			List<FXRequireGoodsList> rqGoodsList = new ArrayList<FXRequireGoodsList>();
			if(rqGoodsDtoList!=null && rqGoodsDtoList.size()>0){
				for(FXRequireGoodsListDto rqGoodsDto : rqGoodsDtoList){
					FXRequireGoodsList rqGoods = new FXRequireGoodsList();
					BeanUtils.copyProperties(rqGoods,rqGoodsDto);
					rqGoodsList.add(rqGoods);
				}
			}
			return fxRequireGoodsService.saveRequireGoods(rqGoodsList);
		}catch(Exception e){
			logger.error("error", e);
		}
		return null;
	}
	
	@RequestMapping(value="/selectByPrimaryKey")
	@ApiOperation("根据主键ID查询要货清单")
	public FXRequireGoodsListDto selectByPrimaryKey(@ApiParam(name="requireId",value="主键ID",required=true)Long requireId){
		return fxRequireGoodsService.selectByPrimaryKey(requireId);
	}
	
	@RequestMapping(value="/{orderNo}/dto")
	@ApiOperation("根据订单号查一条要货清单")
	public FXRequireGoodsList getFXRequireGoodsListDtoByOrderNo(@PathVariable("orderNo") String orderNo,String orderType){
		return fxRequireGoodsService.getFXRequireGoodsListDtoByOrderNo(orderNo,orderType);
	}
	
	@RequestMapping(value="/updateRequireGoods")
	@ApiOperation("更新要货清单")
	public void updateRequireGoods(@ApiParam(name="rqGoods",value="rqGoods",required=true)@RequestBody FXRequireGoodsList rqGoods){
		fxRequireGoodsService.updateRequireGoods(rqGoods);
	}
	
	@RequestMapping(value="/updateBatchRequireGoods")
	@ApiOperation("批量更新要货清单")
	public void updateBatchRequireGoods(@ApiParam(name="rqGoodsList",value="rqGoodsList",required=true)@RequestBody List<FXRequireGoodsList> rqGoodsList){
		fxRequireGoodsService.updateBatchRequireGoods(rqGoodsList);
	}

}
