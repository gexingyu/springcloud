package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.BeanUtils;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.service.FXOperationLogService;
import com.ule.wholesale.fxpurchase.server.service.FXPurchaseOrderService;
import com.ule.wholesale.fxpurchase.server.service.FXReturnOrderService;
import com.ule.wholesale.fxpurchase.server.service.FXSupplierInfoService;
import com.ule.wholesale.fxpurchase.server.service.FxCommonService;
import com.ule.wholesale.fxpurchase.server.vo.FXOperationLog;
import com.ule.wholesale.fxpurchase.server.vo.FXReturnOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXReturnOrderGoods;



@RestController
@Api(value = "退货订单接口服务类",tags = "退货订单接口")  
@RequestMapping("/api/returnOrder")
public class ReturnOrderServerController {
	private static Log logger = LogFactory.getLog(ReturnOrderServerController.class);  
	@Autowired
	private FXSupplierInfoService supplierService;
	@Autowired
	FXPurchaseOrderService purchaseOrderService;
	@Autowired
	FxCommonService commonService;
	@Autowired
	FXReturnOrderService orderService;
	@Autowired
	FXOperationLogService operationLogService;
	@Autowired
	private FXReturnOrderService returnOrderService;
	
		@ApiOperation("查询退货订单列表")
		@RequestMapping(value="/findReturnOrderList",method=RequestMethod.POST)
		public ResultDTO<PageInfo<FXReturnOrder>> findReturnOrderList(
				@ApiParam(name="params",required=true) @RequestBody Map<String,Object> params,
				@ApiParam(name="pageNum",required=true) Integer pageNum,
				@ApiParam(name="pageSize",required=true) Integer pageSize){
			ResultDTO<PageInfo<FXReturnOrder>> rstDto = new ResultDTO<PageInfo<FXReturnOrder>>();
			PageInfo<FXReturnOrder> pageInfo = orderService.findReturnOrderList(params, pageNum,pageSize);
			rstDto.setCode("0");
			rstDto.setData(pageInfo);
			return rstDto;
		}
		//退货单详情
		@ApiOperation("退货单详情信息")
		@RequestMapping("/{orderId}/detail")
		public ResultDTO<Map<String,Object>> orderDetail(@PathVariable("orderId")Long orderId){
			ResultDTO<Map<String,Object>> rstDto = new ResultDTO<Map<String,Object>>();
			Map<String,Object> orderDetail = orderService.fingdOrderDetailByOrderId(orderId);
			rstDto.setCode("0");
			rstDto.setData(orderDetail);
			return rstDto;
		}
		/**
		 * 获取订单主表信息
		 * @param orderId
		 * @return
		 */
		@ApiOperation("获取退货订单主表信息")
		@RequestMapping(value="/{orderId}/orderinfo",method={RequestMethod.POST,RequestMethod.GET})
		public ResultDTO<FXReturnOrder> fingdOrderByOrderId(@PathVariable("orderId")Long orderId){
			ResultDTO<FXReturnOrder> rst = new ResultDTO<FXReturnOrder>();
			FXReturnOrder order = orderService.fingdOrderByOrderId(orderId);
			rst.setCode("0");
			rst.setData(order);
			return rst;
		}
		@ApiOperation("保存退货订单信息")
		@RequestMapping(value = "/save",method={RequestMethod.POST})
		public ResultDTO<Object> saveOrder(@RequestBody Map<String,Object> params){
			ResultDTO<Object> rstDto = new ResultDTO<Object>();
			Object obj = params.get("order");
			List<Map<String,Object>> objList = (List<Map<String,Object>>)params.get("itemList");
			FXReturnOrder order = new FXReturnOrder();
			List<FXReturnOrderGoods> itemList = new ArrayList<FXReturnOrderGoods>();
			Long orderId = null;
			try {
				BeanUtils.copyProperties(order, obj);
				orderId = order.getId();
				for(Map<String,Object> map :objList){
					FXReturnOrderGoods g = new FXReturnOrderGoods();
					org.apache.commons.beanutils.BeanUtils.copyProperties(g, map);
					itemList.add(g);
				}
			} catch (Exception e) {
				logger.error(e);
				e.printStackTrace();
				rstDto.setCode("3");
				rstDto.setMsg(e.getMessage());
				return rstDto;
			}
				//保存订单和订单商品
				order = orderService.saveOrder(order, itemList);
				
				//为订单生成订单流水号
				if((orderId != null&&order.getOrderNo()!=null) || orderService.createOrderNo(order)){
					FXOperationLog log = new FXOperationLog();
					log.setBizCode(order.getOrderNo());
					//根据状态从枚举项获取名字
					if(order.getState() == 1)
						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_1.getName());
					else{
						if(orderId != null){
							log.setEventType("编辑");
							log.setRemark("编辑保存");
						}else{
							log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_0.getName());
							log.setRemark("新建保存");
						}
					}
					
					log.setOpDate(new Date());
//					log.setRemark(remark);
					log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
					try {
						log.setUserId(order.getUpdateUserId() == null ? order.getCreateUserId() : order.getUpdateUserId());
						log.setUserName(order.getUpdateUser() == null ? order.getCreateUser() : order.getUpdateUser());
					} catch (Exception e) {
						logger.error("保存日志信息时获取用户信息异常"+e.getMessage());
					}
					operationLogService.saveOpLog(log);
					rstDto.setCode("0");
					rstDto.setMsg("");
				}else{
					rstDto.setCode("2");
					rstDto.setMsg("数据保存异常");
				}

			return rstDto;
		}
		@ApiOperation("更新订单状态params：orderId,state,auditResult,version,userName,userId")
		@RequestMapping("/updateOrderState")
		public ResultDTO<Object> updateOrderState(@RequestBody Map<String,Object> params){
			ResultDTO<Object> rstJson = new ResultDTO<Object>();
			rstJson.setCode("1");
			rstJson.setMsg("数据提交异常");
			try {
				Long orderId = Long.valueOf(params.get("orderId").toString());
				Integer state = Integer.valueOf(params.get("state").toString());
				String auditResult = params.get("auditResult").toString();
				Integer version = Integer.valueOf(params.get("version").toString());
				String userName = params.get("userName").toString();
				Long userId = Long.valueOf(params.get("userId").toString());
				String orderNo = orderService.updateOrderState(orderId, state,auditResult,version, userName, userId);
				if(orderNo != null && orderNo.startsWith("orderNo:")){
					FXOperationLog log = new FXOperationLog();
					log.setBizCode(orderNo.replace("orderNo:", ""));
					//根据状态从枚举项获取名字
					if(state == 1)
						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_0_1.getName());
					else if(state == 2)
						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_2.getName());
					else if(state == 3){
						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_3.getName());
						log.setRemark(auditResult);
					}else{
						//作废订单
						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_9.getName());
					}
					log.setOpDate(new Date());
					log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
					try {
						log.setUserId(userId);
						log.setUserName(userName);
					} catch (Exception e) {
						logger.error("保存日志信息时获取用户信息异常"+e.getMessage());
					}
					operationLogService.saveOpLog(log);
					rstJson.setCode("0");
					rstJson.setMsg("");
				}else{
					rstJson.setCode("1");
					rstJson.setMsg(orderNo);
				}
			} catch (Exception e) {
				rstJson.setMsg(e.getMessage());
				e.printStackTrace();
			}
			return rstJson;
		}
		@ApiOperation("根据订单ID删除订单")
		@RequestMapping(value = "/{orderId}/delete",method = {RequestMethod.POST,RequestMethod.GET})
		public ResultDTO<Object> deleteOrder(
				@ApiParam(name="orderId",required=true) @PathVariable("orderId") Long orderId,
				@ApiParam(name="userName",required=true) String userName,Long userId){
			if(userId == null ) userId = 0L;
			ResultDTO<Object> rstJson = new ResultDTO<Object>();
			rstJson.setCode("1");
			rstJson.setMsg("数据提交异常");
			try {
				String orderNo = orderService.deleteOrder(orderId, userName,userId);
				if(orderNo != null){
					FXOperationLog log = new FXOperationLog();
					log.setBizCode(orderNo);
					//根据状态从枚举项获取名字
//					if(status == 1)
					log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_0_2.getName());
//					else
//						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_0.getName());
					
					log.setOpDate(new Date());
//					log.setRemark(remark);
					log.setType(FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex());
					try {
						log.setUserId(userId);
						log.setUserName(userName);
					} catch (Exception e) {
						logger.error("保存日志信息时获取用户信息异常"+e.getMessage());
					}
					operationLogService.saveOpLog(log);
					rstJson.setCode("0");
					rstJson.setMsg("");
				}
			} catch (Exception e) {
				rstJson.setCode("2");
				rstJson.setMsg(e.getMessage());
				e.printStackTrace();
			}
			return rstJson;
		}
		
}
