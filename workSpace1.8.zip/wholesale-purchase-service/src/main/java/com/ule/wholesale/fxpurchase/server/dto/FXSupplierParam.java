package com.ule.wholesale.fxpurchase.server.dto;

public class FXSupplierParam {
	
	private String busiLicenseAvailableBeginStr;
	private String busiLicenseAvailableEndStr;
	private String provinceOrgName;
	private String provinceOrg;
	private String cityOrgName;
	private String cityOrg;
	private String countyOrgName;
	private String countyOrg;
	private String bankParentCode;
	private String bankParentName;
	
	
	public String getBusiLicenseAvailableBeginStr() {
		return busiLicenseAvailableBeginStr;
	}
	public void setBusiLicenseAvailableBeginStr(String busiLicenseAvailableBeginStr) {
		this.busiLicenseAvailableBeginStr = busiLicenseAvailableBeginStr;
	}
	public String getBusiLicenseAvailableEndStr() {
		return busiLicenseAvailableEndStr;
	}
	public void setBusiLicenseAvailableEndStr(String busiLicenseAvailableEndStr) {
		this.busiLicenseAvailableEndStr = busiLicenseAvailableEndStr;
	}
	public String getProvinceOrgName() {
		return provinceOrgName;
	}
	public void setProvinceOrgName(String provinceOrgName) {
		this.provinceOrgName = provinceOrgName;
	}
	public String getProvinceOrg() {
		return provinceOrg;
	}
	public void setProvinceOrg(String provinceOrg) {
		this.provinceOrg = provinceOrg;
	}
	public String getCityOrgName() {
		return cityOrgName;
	}
	public void setCityOrgName(String cityOrgName) {
		this.cityOrgName = cityOrgName;
	}
	public String getCityOrg() {
		return cityOrg;
	}
	public void setCityOrg(String cityOrg) {
		this.cityOrg = cityOrg;
	}
	public String getCountyOrgName() {
		return countyOrgName;
	}
	public void setCountyOrgName(String countyOrgName) {
		this.countyOrgName = countyOrgName;
	}
	public String getCountyOrg() {
		return countyOrg;
	}
	public void setCountyOrg(String countyOrg) {
		this.countyOrg = countyOrg;
	}
	public String getBankParentCode() {
		return bankParentCode;
	}
	public void setBankParentCode(String bankParentCode) {
		this.bankParentCode = bankParentCode;
	}
	public String getBankParentName() {
		return bankParentName;
	}
	public void setBankParentName(String bankParentName) {
		this.bankParentName = bankParentName;
	}

	
	

}
