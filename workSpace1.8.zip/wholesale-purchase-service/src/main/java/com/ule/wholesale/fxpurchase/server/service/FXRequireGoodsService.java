package com.ule.wholesale.fxpurchase.server.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.fxpurchase.server.dto.FXRequireGoodsListDto;
import com.ule.wholesale.fxpurchase.server.mapper.FXGoodsCompareListMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXPurchaseOrderGoodsMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXPurchaseOrderMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXRequireGoodsListMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXGoodsCompareList;
import com.ule.wholesale.fxpurchase.server.vo.FXRequireGoodsList;

@Service
public class FXRequireGoodsService {
	
	@Autowired
	private FXRequireGoodsListMapper fxRequireGoodsListMapper;
	@Autowired
	private FXGoodsCompareListMapper fxGoodsCompareListMapper;
	@Autowired
	private FXPurchaseOrderMapper fxPurchaseOrderMapper;
	@Autowired
	private FXPurchaseOrderGoodsMapper fxPurchaseOrderGoodsMapper;
	
	public PageInfo<FXRequireGoodsListDto> getPageByParams(Map<String,Object> params, Integer pageNum, Integer pageSize, String orderBy){
		PageHelper.startPage(pageNum, pageSize, orderBy);
		List<FXRequireGoodsListDto> infoList = fxRequireGoodsListMapper.selectByParams(params);
		PageInfo<FXRequireGoodsListDto> pageInfo = new PageInfo<FXRequireGoodsListDto>(infoList);
		return pageInfo;
	}
	
	@org.springframework.transaction.annotation.Transactional
	public List<String> saveRequireGoods(List<FXRequireGoodsList> rqGoodsList){
		List<String> ingoreData = new ArrayList<String>();
		if(rqGoodsList!=null && rqGoodsList.size()>0){
			for(FXRequireGoodsList rqGoods : rqGoodsList){
				Map<String, Object> params = new HashMap<String, Object>();
				String sourceOrderNo = rqGoods.getSourceOrderNo();
				String orderOrgCode = rqGoods.getOrderOrgCode();
				String dmsItemCode = rqGoods.getDmsItemCode();
				params.put("sourceOrderNo", sourceOrderNo);
				params.put("orderOrgCode", orderOrgCode);
				params.put("dmsItemCode", dmsItemCode);
				//根据来源单号（总订单号）、订单机构编码、dms商品编码确定要货清单的唯一性
				FXRequireGoodsList fxRqGoods = fxRequireGoodsListMapper.getOnlyByParams(params);
				if(fxRqGoods!=null){//存在 更新
					if(fxRqGoods.getState().intValue()==0){//未分配
						fxRqGoods.setOrderOrgName(rqGoods.getOrderOrgName());
						fxRqGoods.setReceiveAddress(rqGoods.getReceiveAddress());
						fxRqGoods.setRequireTime(rqGoods.getRequireTime());
						fxRqGoods.setExpectDeliveryTime(rqGoods.getExpectDeliveryTime());
						fxRqGoods.setDmsItemName(rqGoods.getDmsItemName()==null ? "" : rqGoods.getDmsItemName());
						fxRqGoods.setDmsItemSpec(rqGoods.getDmsItemSpec()==null ? "" : rqGoods.getDmsItemSpec());
						fxRqGoods.setDmsItemUnit(rqGoods.getDmsItemUnit()==null ? "" : rqGoods.getDmsItemUnit());
						fxRqGoods.setDmsItemPrice(rqGoods.getDmsItemPrice());
						fxRqGoods.setNumber(rqGoods.getNumber());
						fxRqGoods.setAmount(rqGoods.getAmount());
						fxRqGoods.setRemark(rqGoods.getRemark());
						fxRequireGoodsListMapper.updateByPrimaryKey(fxRqGoods);
					}else{
						ingoreData.add("总订单号为"+sourceOrderNo+"，订单机构编码为"+orderOrgCode+"，编号为"+dmsItemCode+"的商品已存在已分配的数据");
					}
				}else{//不存在 插入
					rqGoods.setDmsItemName(rqGoods.getDmsItemName()==null ? "" : rqGoods.getDmsItemName());
					rqGoods.setDmsItemSpec(rqGoods.getDmsItemSpec()==null ? "" : rqGoods.getDmsItemSpec());
					rqGoods.setDmsItemUnit(rqGoods.getDmsItemUnit()==null ? "" : rqGoods.getDmsItemUnit());
					fxRequireGoodsListMapper.insert(rqGoods);
				}
				FXGoodsCompareList goodsC = new FXGoodsCompareList();
				goodsC.setDmsItemCode(dmsItemCode);
				List<FXGoodsCompareList> goodsCList = fxGoodsCompareListMapper.selectFXGoodsCompareListInfos(goodsC);
				if(goodsCList==null || goodsCList.size()==0){
					FXGoodsCompareList record = new FXGoodsCompareList();
					record.setSignProvinceCode(orderOrgCode);
					record.setSignProvinceName(rqGoods.getOrderOrgName()==null ? "" : rqGoods.getOrderOrgName());
					record.setDmsItemCode(dmsItemCode);
					record.setDmsItemName(rqGoods.getDmsItemName()==null ? "" : rqGoods.getDmsItemName());
					record.setDmsItemSpec(rqGoods.getDmsItemSpec()==null ? "" : rqGoods.getDmsItemSpec());
					record.setDmsItemUnit(rqGoods.getDmsItemUnit()==null ? "" : rqGoods.getDmsItemUnit());
					record.setProvinceOrgCode(rqGoods.getProvinceOrgCode());
					record.setCityOrgCode(rqGoods.getCityOrgCode());
					record.setRegionOrgCode(rqGoods.getRegionOrgCode());
					record.setOrgLevel(rqGoods.getOrgLevel());
					record.setOrgName(rqGoods.getOrgName());
					record.setCreateTime(new Date());
					fxGoodsCompareListMapper.insert(record);
				}
				
			}
		}
		return ingoreData;
	}
	
	public FXRequireGoodsListDto selectByPrimaryKey(Long requireId){
		return fxRequireGoodsListMapper.selectByPrimaryKey(requireId);
	}
	
	public FXRequireGoodsList getFXRequireGoodsListDtoByOrderNo(String orderNo,String orderType){
		return fxRequireGoodsListMapper.getFXRequireGoodsListDtoByOrderNo(orderNo,orderType);
	}
	
	public void updateRequireGoods(FXRequireGoodsList rqGoods){
		fxRequireGoodsListMapper.updateByPrimaryKey(rqGoods);
	}
	
	@Transactional
	public void updateBatchRequireGoods(List<FXRequireGoodsList> rqGoodsList){
		if(rqGoodsList!=null && rqGoodsList.size()>0){
			for(FXRequireGoodsList rqGoods : rqGoodsList){
				fxRequireGoodsListMapper.updateByPrimaryKey(rqGoods);
			}
		}
	}
	
}
