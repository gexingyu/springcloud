package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.ule.merchant.ctoc.basic.dto.MerchantDTO;
import com.ule.merchant.merchant.ejb.client.SysPostMerchantClient;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.BeanUtils;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.service.FXContractItemListService;
import com.ule.wholesale.fxpurchase.server.service.FXOperationLogService;
import com.ule.wholesale.fxpurchase.server.service.FXPurchaseOrderService;
import com.ule.wholesale.fxpurchase.server.service.FXSupplierInfoService;
import com.ule.wholesale.fxpurchase.server.service.FxCommonService;
import com.ule.wholesale.fxpurchase.server.vo.FXContractItemList;
import com.ule.wholesale.fxpurchase.server.vo.FXOperationLog;
import com.ule.wholesale.fxpurchase.server.vo.FXPurchaseOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXPurchaseOrderGoods;
/**
 * @author zhengmingzhi
 *
 */

@Api(value = "订单接口服务类",tags = "采购订单接口")  
@RestController
@RequestMapping("/api/order")
public class OrderServerController {
	private static Log logger = LogFactory.getLog(OrderServerController.class);  
	@Autowired
	private FXSupplierInfoService supplierService;
	@Autowired
	FXContractItemListService itemService;
	@Autowired
	FXPurchaseOrderService orderService;
	@Autowired
	FXOperationLogService operationLogService;
	
	@Autowired
	FxCommonService commonService;
	
	@RequestMapping(value="/hello",method={RequestMethod.GET})
	@ApiOperation("手动发送和处理订单消息")
	public Object hello(HttpServletRequest req,@ApiParam(name="flag",value="消息类型，2发送，3处理",required=true) @RequestParam("flag")Integer flag){
		logger.info("hello");
		try {
			
			if(flag != null && flag == 1){
				SysPostMerchantClient client1 = com.ule.merchant.merchant.util.MerchantBaseTools.getInstance().getSysPostMerchantClient();
				logger.info("SysPostMerchantClient  init success ...............client="+client1);
				Map dto = client1.getMerchantListByParams("100", null, "101165", null, "11", null, null);
				System.out.println(dto);
				return dto;
			}
			if(flag != null && flag == 11){
				SysPostMerchantClient client1 = com.ule.merchant.merchant.util.MerchantBaseTools.getInstance().getSysPostMerchantClient();
				logger.info("SysPostMerchantClient  init success ...............client="+client1);
				MerchantDTO dto = client1.findMerchantDTOByMerchantId(101165L);
				System.out.println(dto);
				return dto;
			}
			
		} catch (Exception e) {
			logger.error("SysPostMerchantClient  init error "+e.getLocalizedMessage());
			e.printStackTrace();
		}
//		if(topic != null){
//			com.ule.wholesale.fxpurchase.server.msghandler.KafkaProducerHandler.sendTopic(topic,key,msg);
//		}//else
//		KafkaProducerHandler.sendTopic("KAFKA_WMS_TO_SO_PUR_FEED_BACK","hello","KAFKA_WMS_TO_SO_PUR_FEED_BACK");
		//KafkaProducerHandler.sendTopic("kafka_wholesale_purchase_return_order","hello","kafka_wholesale_purchase_return_order");
//		KafkaProducerHandler.sendTopic("WMS_PURCHASE_ORDER_RECEIPT","hello","kafka");
//		TaskInfo info = new TaskInfo();
//		info.setJobName("com.ule.fxpurchase.quartz.TestJob");
//		info.setJobGroup("zmzm");
//		info.setCronExpression("0 0/1 * * * ?");
//		info.setJobStatus("0");
//		info.setJobDescription("test ");
//		task.addJob(info);
		if(flag != null && flag == 2)
			commonService.sendMsg();
		else if(flag != null && flag == 3)
			try {
				commonService.handlerMsg();
			} catch (Exception e) {
				e.printStackTrace();
			}
		else if(flag != null && flag == 4){
			return commonService.getUleSelfSupportMerchantList(null);
		}
		return "Hello world"+">>>"+req.getServerPort();
	}
	
	@RequestMapping(value="/fingdDetail/{orderId}",method={RequestMethod.POST,RequestMethod.GET})
	@ApiOperation("根据订单ID获取订单详细信息，包括订单商品列表") 
	public ResultDTO<Map<String,Object>> fingdOrderDetailByOrderId(@ApiParam(name = "orderId",value = "订单ID",required = true)  @PathVariable("orderId")Long orderId){
		ResultDTO<Map<String,Object>> rstDto = new ResultDTO<Map<String,Object>>();
		Map<String,Object> orderDetail = orderService.selectdOrderDetailByOrderId(orderId);
		rstDto.setCode("0");
		rstDto.setData(orderDetail);
		return rstDto;
	}
	@RequestMapping("/findOrderList")
	public ResultDTO<Map<String,Object>> findOrderList(@RequestBody Map<String,Object> params){
		ResultDTO<Map<String,Object>> rstDto = new ResultDTO<Map<String,Object>>();
		Map<String,Object> rstMap = new HashMap<String, Object>();
		Integer pageNum = (params.get("pageNum") == null || Integer.valueOf(params.get("pageNum").toString()) == 0) ? 1 : Integer.valueOf(params.get("pageNum").toString());
		Integer pageSize = (params.get("pageSize") == null || Integer.valueOf(params.get("pageSize").toString()) < 1) ? 10 :Integer.valueOf(params.get("pageSize").toString());
		PageInfo<FXPurchaseOrder> pageInfo = orderService.selectOrderList(params, pageNum,pageSize);
		rstMap.put("orderList", pageInfo.getList());
		rstMap.put("currentPage", pageInfo.getPageNum());
		rstMap.put("totalPage", pageInfo.getPages());
		rstDto.setCode("0");
		rstDto.setData(rstMap);
		return rstDto;
	}
	@RequestMapping("/findEffectiveItemList")
	public ResultDTO<PageInfo<FXContractItemList>> findEffectiveItemList(@RequestBody Map<String,Object> params){
		ResultDTO<PageInfo<FXContractItemList>> rstDto = new ResultDTO<PageInfo<FXContractItemList>>();
		Long supplierId = Long.valueOf(params.get("supplierId").toString());
		Long merchantId = params.get("merchantId") == null ? null : Long.valueOf(params.get("merchantId").toString());
		Long itemId = params.get("itemId") == null ? null : Long.valueOf(params.get("itemId").toString());
		String itemName = params.get("itemName") == null ? null : params.get("itemName").toString();
		Integer pageNum = Integer.valueOf(params.get("pageNum").toString());
		Integer pageSize = Integer.valueOf(params.get("pageSize").toString());
		PageInfo<FXContractItemList> pageInfo = itemService.selectEffectiveItemList(supplierId, merchantId, itemId, itemName, pageNum, pageSize);
		rstDto.setCode("0");
		rstDto.setData(pageInfo);
		return rstDto;
	}
	@RequestMapping("/fingdOrder/{orderId}")
	public ResultDTO<FXPurchaseOrder> fingdOrderByOrderId(@PathVariable("orderId") Long orderId){
		ResultDTO<FXPurchaseOrder>  rstDto = new ResultDTO<FXPurchaseOrder>();
		FXPurchaseOrder order = orderService.selectOrderByOrderId(orderId);
		rstDto.setCode("0");
		rstDto.setData(order);
		return rstDto;
	}
	@RequestMapping("/saveOrderInfo")
	public ResultDTO<FXPurchaseOrder> saveOrderInfo(@RequestBody Map<String,Object> params){
		ResultDTO<FXPurchaseOrder> rstDto = new ResultDTO<FXPurchaseOrder>();
		
		Object obj = params.get("order");
		List<Map<String,Object>> objList = (List<Map<String,Object>>)params.get("itemList");
		FXPurchaseOrder order = new FXPurchaseOrder();
		List<FXPurchaseOrderGoods> itemList = new ArrayList<FXPurchaseOrderGoods>();
		Long orderId = null;
		try {
			BeanUtils.copyProperties(order, obj);
			orderId = order.getId();
			for(Map<String,Object> map :objList){
				FXPurchaseOrderGoods g = new FXPurchaseOrderGoods();
				org.apache.commons.beanutils.BeanUtils.copyProperties(g, map);
				itemList.add(g);
			}
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
			rstDto.setCode("3");
			rstDto.setMsg(e.getMessage());
			return rstDto;
		}
		
			order = orderService.saveOrder(order, itemList);
			if(order.getState() == -1){
				rstDto.setCode("3");
				rstDto.setMsg("数据已被操作，请更新后再操作");
				return rstDto;
			}
			
			//为订单生成订单流水号
			if((orderId != null&&order.getOrderNo()!=null) || orderService.createOrderNo(order)){
				FXOperationLog log = new FXOperationLog();
				log.setBizCode(order.getOrderNo());
				//根据状态从枚举项获取名字
				if(order.getState() == 1)
					log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_1.getName());
				else{
					if(orderId != null){
						log.setEventType("编辑");
						log.setRemark("编辑保存");
					}else{
						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_0.getName());
						log.setRemark("新建保存");
					}
				}
					
				
				log.setOpDate(new Date());
//				log.setRemark(remark);
				log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
				log.setUserName(order.getUpdateUser() == null ? order.getCreateUser() : order.getUpdateUser());
				operationLogService.saveOpLog(log);
				rstDto.setData(order);
				rstDto.setCode("0");
			}else{
				rstDto.setCode("2");
				rstDto.setMsg("数据保存异常");
			}
		return rstDto;
	}
	@RequestMapping("/submit")
	public ResultDTO<Object> updateOrderState(@RequestBody Map<String,Object> params){
		ResultDTO<Object> rstDto = new ResultDTO<Object>();
		rstDto.setCode("1");
		rstDto.setMsg("数据请求异常");
		try {
			Long orderId = Long.valueOf(params.get("orderId").toString());
			Integer state = Integer.valueOf(params.get("state").toString());
			String auditResult = params.get("auditResult").toString();
			Integer version = Integer.valueOf(params.get("version").toString());
			String userName = params.get("username").toString();
			Long userId = Long.valueOf(params.get("userId").toString());
			String orderNo  = orderService.updateOrderState(orderId, state,auditResult,version,userName,userId);
			
			if(orderNo != null && orderNo.startsWith("orderNo:")){
				FXOperationLog log = new FXOperationLog();
				log.setBizCode(orderNo.replace("orderNo:", ""));
				//根据状态从枚举项获取名字
				if(state == 1)
					log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_0_1.getName());
				else if(state == 2)
					log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_2.getName());
				else if(state == 3){
					log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_3.getName());
					log.setRemark(auditResult);
				}else if(state == 8){
						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_8.getName());	
				}else{
					//作废订单
					log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_9.getName());
				}
				log.setOpDate(new Date());
				log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
				try {
					log.setUserId(userId);
					log.setUserName(userName);
				} catch (Exception e) {
					logger.error("保存日志信息时获取用户信息异常"+e.getMessage());
				}
				operationLogService.saveOpLog(log);
				rstDto.setCode("0");
			}else{
				rstDto.setCode("1");
				rstDto.setMsg(orderNo);
			}
		} catch (Exception e) {
			rstDto.setMsg(e.getMessage());
			e.printStackTrace();
		}
		return rstDto;
	}
	
	@RequestMapping("/receiveOrder")
	public ResultDTO<Object> receiveOrder(@RequestBody Map<String,Object> params){
		ResultDTO<Object> rstDto = new ResultDTO<Object>();
		String whOrderId;
		try {
			whOrderId = orderService.receiveOrder(params);
			if(whOrderId != null && whOrderId.startsWith("whOrderId:")){
				rstDto.setCode("0000");
			}else {
				rstDto.setCode("0001");
				rstDto.setMsg("操作失败");
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			rstDto.setCode("0001");
			rstDto.setMsg("操作失败");
			e.printStackTrace();
		}
		return rstDto;
	}
	
	@RequestMapping("/pay/{orderId}")
	public ResultDTO<Object> payOrder(@PathVariable("orderId") Long orderId,Integer version,String username,Long userId){
		 ResultDTO<Object> rstDto = new  ResultDTO<Object>();
		 rstDto.setCode("1");
		 rstDto.setMsg("数据请求异常");
		try {
			//预付款支付状态 1:已支付
			String orderNo  = orderService.updateOrderPrepay(orderId,1,version,username, userId);
			if(orderNo != null && orderNo.startsWith("orderNo:")){
				FXOperationLog log = new FXOperationLog();
				log.setBizCode(orderNo.replace("orderNo:", ""));
				log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_10.getName());
				log.setOpDate(new Date());
				log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
				try {
					log.setUserId(userId);
					log.setUserName(username);
				} catch (Exception e) {
					logger.error("保存日志信息时获取用户信息异常"+e.getMessage());
				}
				operationLogService.saveOpLog(log);
				rstDto.setCode("0000");
				rstDto.setMsg("");
			}else{
				rstDto.setCode("0001");
				rstDto.setMsg(orderNo);
			}
		} catch (Exception e) {
			rstDto.setMsg(e.getMessage());
			e.printStackTrace();
		}
		return rstDto;
	}
	@RequestMapping("/{orderId}/delete")
	public ResultDTO<Object> deleteOrder(@PathVariable("orderId") Long orderId,String username,Long userId){
		ResultDTO<Object> rstJson = new ResultDTO<Object>();
		rstJson.setCode("1");
		rstJson.setMsg("数据请求异常");
		try {
			String orderNo = orderService.deleteOrder(orderId, username, userId);
			if(orderNo != null){
				FXOperationLog log = new FXOperationLog();
				log.setBizCode(orderNo);
				log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_0_2.getName());
				log.setOpDate(new Date());
				log.setType(FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex());
				log.setUserId(userId);
				log.setUserName(username);
				operationLogService.saveOpLog(log);
				rstJson.setCode("0");
				rstJson.setMsg("");
			}
		} catch (Exception e) {
			rstJson.setMsg(e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	@RequestMapping("/publish/{orderNo}/{type}")
	public Object getPublishList(@PathVariable("orderNo")String bizCode,@PathVariable("type")Integer type){
		return JSONObject.toJSON(commonService.getPublishList(bizCode, type));
	}
	@RequestMapping("/consumer/{orderNo}/{type}")
	public Object getConsumerList(@PathVariable("orderNo")String bizCode,@PathVariable("type")Integer type){
		return JSONObject.toJSON(commonService.getConsumerList(bizCode, type));
	}
	/**
	 * 查询指定供应商采购过的商品列表（限定为两年以内的商品）,已收货商品状态 8
	 * @param supplierId
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */

	@RequestMapping(value="/findPurchaseItemList",method={RequestMethod.POST,RequestMethod.GET})
	public ResultDTO<PageInfo<FXPurchaseOrderGoods>> findPurchaseItemList(@RequestBody Map<String,Object> params,Integer pageNum,Integer pageSize){
		ResultDTO<PageInfo<FXPurchaseOrderGoods>> rstDto = new ResultDTO<PageInfo<FXPurchaseOrderGoods>>();
//		Map<String,Object> params = new HashMap<String, Object>();
//		params.put("supplierId", supplierId);
//		params.put("merchantId", merchantId);
//		params.put("itemId", itemId);
//		Long supplierId = Long.valueOf(params.get("supplierId").toString());
//		Long merchantId = params.get("merchantId") == null ? null :Long.valueOf(params.get("merchantId").toString());
//		Long itemId = params.get("itemId") == null ? null :Long.valueOf(params.get("itemId").toString());
		PageInfo<FXPurchaseOrderGoods> pageInfo = orderService.selectPurchaseItemList(params, pageNum, pageSize);
		rstDto.setCode("0");
		rstDto.setData(pageInfo);
		return rstDto;
	}
	
}
