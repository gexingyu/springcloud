package com.ule.wholesale.fxpurchase.server.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.fxpurchase.server.mapper.FXOPcDmsOrgRelationMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXOPcDmsOrgRelation;

@Service("fxOPcDmsOrgRelationService")
public class FXOPcDmsOrgRelationService {
	
	@Autowired
	private FXOPcDmsOrgRelationMapper fxoPcDmsOrgRelationMapper;
	
	public int saveWholesaleAgency(FXOPcDmsOrgRelation fxoPcDmsOrgRelation){
		return fxoPcDmsOrgRelationMapper.insert(fxoPcDmsOrgRelation);
	}
	
	public PageInfo<FXOPcDmsOrgRelation> getAgencyListByPage(FXOPcDmsOrgRelation fxoPcDmsOrgRelation,int pageNum,int pageSize){
		PageHelper.startPage(pageNum, pageSize,"CREATE_TIME DESC,UPDATE_TIME DESC");
		List<FXOPcDmsOrgRelation> list = fxoPcDmsOrgRelationMapper.selectFXOPcDmsOrgRelationInfos(fxoPcDmsOrgRelation);
		PageInfo<FXOPcDmsOrgRelation> info = new PageInfo<FXOPcDmsOrgRelation>(list);
		return info;
	}
	
	public FXOPcDmsOrgRelation selectFxoPcDmsOrgRelationById(Long id){
		return fxoPcDmsOrgRelationMapper.selectByPrimaryKey(id);
	}
	
	public int updateFxoPcDmsOrgRelation(FXOPcDmsOrgRelation fxoPcDmsOrgRelation){
		return fxoPcDmsOrgRelationMapper.updateByPrimaryKeySelective(fxoPcDmsOrgRelation);
	}
	
	public List<Map<String, Object>> getAgency(Long signCode,Long level){
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
		if(level== null || level > 2){
			return list;
		}
		List<FXOPcDmsOrgRelation> fxoPcDmsOrgRelations = fxoPcDmsOrgRelationMapper.getAgencys(signCode, level);
		if(fxoPcDmsOrgRelations != null && fxoPcDmsOrgRelations.size()>0){
			for(FXOPcDmsOrgRelation po : fxoPcDmsOrgRelations){
				if(po == null) continue;
				Map<String, Object> resultMap = new HashMap<String, Object>();
				if(level == 0){
					resultMap.put("id", po.getSignProvinceCode());
					resultMap.put("name", po.getSignProvinceName());
				}else if(level == 1){
					resultMap.put("id", po.getSignCityCode());
					resultMap.put("name", po.getSignCityName());
				}else if(level == 2){
					resultMap.put("id", po.getSignRegionCode());
					resultMap.put("name", po.getSignRegionName());
				}
				list.add(resultMap);
			}
		}
		return list;
	}

}
