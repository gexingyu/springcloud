package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.service.FXGoodsComparisonService;
import com.ule.wholesale.fxpurchase.server.service.FXOPcDmsOrgRelationService;
import com.ule.wholesale.fxpurchase.server.vo.FXGoodsCompareList;

@RestController
@RequestMapping("/api/goods")
@Api(value = "商品对照接口服务类",tags = "商品对照服务接口")  
public class GoodsComparisonServerController {
	
	private static Log logger = LogFactory.getLog(GoodsComparisonServerController.class);  
	
	public static final Integer PAGESIZE = 10;
	
	@Autowired
	private FXGoodsComparisonService fxGoodsComparisonService;
	@Autowired
	private FXOPcDmsOrgRelationService fxOPcDmsOrgRelationService;
	
	
	@RequestMapping(value = "/{id}/detail")	
	public ResultDTO<FXGoodsCompareList> selectfxGoodsComparisonById(@PathVariable("id") Long id){
		ResultDTO<FXGoodsCompareList> rst = new ResultDTO<FXGoodsCompareList>();
		FXGoodsCompareList fxGoodsCompareList = fxGoodsComparisonService.selectfxGoodsComparisonById(id);
		rst.setData(fxGoodsCompareList);
		return rst;
	}
	@RequestMapping(value = "/{id}/delete")	
	public ResultDTO<Integer> deleteGoodsComparison(@PathVariable("id")Long id){
		ResultDTO<Integer> rst = new ResultDTO<Integer>();
		if(id!=null){
			logger.info("------ deleteGoodsComparison id="+id+ "-------");
			fxGoodsComparisonService.deleteFXGoodsComparison(id);
			rst.setCode("0");
			rst.setData(1);
			return rst;
		}
		return rst;
	}
	
	@RequestMapping(value = "/save")
	public ResultDTO<Integer> saveGoodsComparison(@ApiParam(name="fxGoodsCompareList",value="商品对照对象",required=true)@RequestBody FXGoodsCompareList fxGoodsCompareList){
		ResultDTO<Integer> rst = new ResultDTO<Integer>();
		try {
			int n = fxGoodsComparisonService.saveFXGoodsCompareList(fxGoodsCompareList);
			rst.setCode("0");
			rst.setData(n);
		} catch (Exception e) {
			rst.setCode("1");
			rst.setMsg(e.getMessage());
			logger.error("saveGoodsComparison error : "+e.getMessage(),e);
		}
		return rst;
	}
	
	@RequestMapping(value = "/edit")
	public ResultDTO<Integer> editComparison(@ApiParam(name="fxGoodsCompareList",value="商品对照对象",required=true)@RequestBody FXGoodsCompareList fxGoodsCompareList){
		ResultDTO<Integer> rst = new ResultDTO<Integer>();
		try {
				int n = fxGoodsComparisonService.updateFXGoodsComparison(fxGoodsCompareList);
				rst.setCode("0");
				rst.setData(n);
		} catch (Exception e) {
			rst.setCode("0");
			rst.setMsg(e.getMessage());
			logger.error("editComparison error : "+e.getMessage(),e);
		}
		return rst;
	}
	
	/**
	 * 根据条件分页查询
	 * @param pageNo
	 * @param pageSize
	 * @return pageInfo
	 */
	@RequestMapping(value = "/list",method = RequestMethod.POST)
	public ResultDTO<Map<String, Object>> getGoodsCompareListByPage(
			@ApiParam(name="fxGoodsCompareList",value="商品对照对象",required = true)@RequestBody FXGoodsCompareList fxGoodsCompareList,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize){
		ResultDTO<Map<String, Object>> rstDto = new ResultDTO<Map<String,Object>>();
		Map<String, Object> rstMap = new HashMap<String, Object>();
		PageInfo<FXGoodsCompareList> pageInfo = fxGoodsComparisonService.getGoodsCompareListByPage(fxGoodsCompareList, pageNum, pageSize);
		rstMap.put("currentPage", pageInfo.getPageNum());
		rstMap.put("totalPage", pageInfo.getPages());
		rstMap.put("total", pageInfo.getTotal());
		rstMap.put("list", pageInfo.getList());
		rstDto.setData(rstMap);
		rstDto.setCode("0");
		rstDto.setMsg("");
		return rstDto;
	}
	@RequestMapping(value = "/getFXGoodsCompareListByParam",method = RequestMethod.POST)
	public ResultDTO<List<FXGoodsCompareList>> getGoodsCompareListByPage(
			@ApiParam(name="fxGoodsCompareList",value="商品对照对象",required = true)@RequestBody FXGoodsCompareList fxGoodsCompareList){
		List<FXGoodsCompareList> list = fxGoodsComparisonService.getGoodsCompareList(fxGoodsCompareList);
		return ResultDTO.success(list);
	}
	
	/**
	 * 获取已启用的批发机构
	 * */
	@RequestMapping(value = "/getAgency")
	public ResultDTO<List<Map<String, Object>>> getAgency(
			@ApiParam(name="signCode",value="机构code",required=true)Long signCode,
			@ApiParam(name="level",value="机构级别",required=true)Long level){
		List<Map<String, Object>> list = fxOPcDmsOrgRelationService.getAgency(signCode, level);
		return ResultDTO.success(list);
	}
	
	@RequestMapping(value="/findItemList",method={RequestMethod.POST,RequestMethod.GET})
	public ResultDTO<PageInfo<FXGoodsCompareList>> findPurchaseItemList(@RequestBody FXGoodsCompareList fxGoodsCompareList,Integer pageNum,Integer pageSize){
		ResultDTO<PageInfo<FXGoodsCompareList>> rstDto = new ResultDTO<PageInfo<FXGoodsCompareList>>();
		PageInfo<FXGoodsCompareList> pageInfo = fxGoodsComparisonService.selectItemList(fxGoodsCompareList, pageNum, pageSize);
		rstDto.setCode("0");
		rstDto.setData(pageInfo);
		return rstDto;
	}
}
