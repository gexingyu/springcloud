package com.ule.wholesale.fxpurchase.server.msghandler;

import kafka.utils.VerifiableProperties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ule.tools.client.kafka.consumer.handler.AbstractConsumerHandler;
import com.ule.wholesale.fxpurchase.server.service.FxCommonService;

public class ReturnOrderCreateConsumerFeedbackHandler extends AbstractConsumerHandler<String>{
	private final static Logger logger= LoggerFactory.getLogger(ReturnOrderCreateConsumerFeedbackHandler.class);
	@Autowired
	FxCommonService commonService;
	
	public ReturnOrderCreateConsumerFeedbackHandler(VerifiableProperties props) {
		super(props);
	}

	@Override
	public void handle(String key, String message) {
		logger.error("ReturnOrderCreateConsumerFeedbackHandler========================key="+key+"  message="+message);
		try {
			if(commonService == null)
				commonService = new FxCommonService();
			commonService.returnOrderCreateConsumerFeedback(key,message);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}


}
