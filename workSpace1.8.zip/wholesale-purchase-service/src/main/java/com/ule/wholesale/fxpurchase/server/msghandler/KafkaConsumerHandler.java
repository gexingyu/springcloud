package com.ule.wholesale.fxpurchase.server.msghandler;

import kafka.utils.VerifiableProperties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ule.tools.client.kafka.consumer.handler.AbstractConsumerHandler;

public class KafkaConsumerHandler extends AbstractConsumerHandler<String>{
	private final static Logger logger= LoggerFactory.getLogger(KafkaConsumerHandler.class);
	public KafkaConsumerHandler(VerifiableProperties props) {
		super(props);
	}

	@Override
	public void handle(String key, String message) {
		logger.error("KafkaConsumerHandler========================key="+key+"  message="+message);
		
	}


}
