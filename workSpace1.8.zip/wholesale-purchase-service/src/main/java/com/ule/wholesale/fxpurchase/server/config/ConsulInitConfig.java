package com.ule.wholesale.fxpurchase.server.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import com.ule.wholesale.common.consul.ConsulConfig;
/**
 * 自定义初始化Consul
 * @author zhengmingzhi
 *
 */
@Component
@Import(ConsulConfig.class)
public class ConsulInitConfig implements InitializingBean {

	private static Logger logger = LoggerFactory.getLogger(ConsulInitConfig.class);
//	@Autowired
//	ConsulDiscoveryProperties properties;
	@Autowired
	ConsulConfig consulConfig;
	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("initConsulConfig start...");
		// 一定要在 InitializingBean bean中调用，如果初始化时机比较晚，配置就不起作用了
		consulConfig.initConsulConfig();
	}
}
