package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ule.wholesale.fxpurchase.server.service.FXOperationLogService;
import com.ule.wholesale.fxpurchase.server.vo.FXOperationLog;

@RestController
@RequestMapping("/api/opLog")
@Api(value="操作日志服务接口",tags = "获取操作日志列表或者保存")
public class OperationLogController {

	private static Logger logger = LoggerFactory.getLogger(OperationLogController.class);
	@Autowired
	private FXOperationLogService logService;
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public boolean saveOpLog(@RequestBody FXOperationLog log){
		logService.saveOpLog(log);
		return true;
	}
	/**
	 * 根据日志业务代码和业务类型查询某个单据的操作日志列表
	 * @param bizCode
	 * @param type
	 * @return
	 */
	@RequestMapping(value="/list",method={RequestMethod.POST,RequestMethod.GET})
	public List<FXOperationLog> getOperationLogList(String bizCode,Integer type){
		logger.info("获取操作日志信息，getFXOperationLogList bizCode="+bizCode);
		return logService.getOperationLogList(bizCode, type);
	}
}
