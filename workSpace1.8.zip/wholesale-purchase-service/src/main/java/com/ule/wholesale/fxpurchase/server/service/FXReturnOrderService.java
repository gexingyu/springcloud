package com.ule.wholesale.fxpurchase.server.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.fxpurchase.server.mapper.FXReturnOrderGoodsMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXReturnOrderMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FxOrderMsgPublishMapper;
import com.ule.wholesale.fxpurchase.server.msghandler.KafkaProducerHandler;
import com.ule.wholesale.fxpurchase.server.vo.FXReturnOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXReturnOrderGoods;
import com.ule.wholesale.fxpurchase.server.vo.FxOrderMsgPublish;

@Service("ReturnOrderService")
public class FXReturnOrderService {
	private static Logger logger = LoggerFactory.getLogger(FXReturnOrderService.class);
	@Autowired
	private FXReturnOrderMapper returnOrderMapper;
	@Autowired
	private FXReturnOrderGoodsMapper orderGoodsMapper;
	@Autowired
	private FxOrderMsgPublishMapper orderMsgPublishMapper;
	@Autowired
	private FxCommonService commonService;
	
	public PageInfo<FXReturnOrder> findReturnOrderList(Map<String,Object> params,Integer pageNum,Integer pageSize){
		PageHelper.startPage(pageNum, pageSize,"CREATE_TIME DESC,UPDATE_TIME DESC");
		List<FXReturnOrder> fxReturnOrdersList=returnOrderMapper.selectOrderListBySelective(params);
		PageInfo<FXReturnOrder> pageInfo=new PageInfo<FXReturnOrder>(fxReturnOrdersList);
		return pageInfo;
	}
	
	
	@Transactional
	public FXReturnOrder saveOrder(FXReturnOrder order,List<FXReturnOrderGoods> itemList){
		logger.info("FXPurchaseOrderService>>>>>>>>save FXReturnOrder");
		if(order.getId() == null){
			returnOrderMapper.insert(order);
		}else{
			FXReturnOrder tmp = returnOrderMapper.selectLockByPrimaryKey(order.getId());
			if(tmp.getVersion() != order.getVersion()){
				order.setState(-1);
				return order;
			}
			//订单编辑时先删除已有商品，重新插入
			logger.info("订单编辑操作，删除已有商品信息");
			orderGoodsMapper.deleteByOrderId(order.getId());
			returnOrderMapper.updateByPrimaryKey(order);
		}
		logger.info("FXReturnOrderService>>>>>>>>batch save FXReturnOrderGoods");
		for(FXReturnOrderGoods record :itemList){
			record.setOrderId(order.getId());
			orderGoodsMapper.insert(record);
		}
		logger.info("FXPurchaseOrderService>>>>>>>>order info save success");
		
		return order;
	}
	@Transactional
	public boolean createOrderNo(FXReturnOrder order ){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String,Object> rst = new HashMap<String, Object>();
		rst.put("orderId", order.getId());
		rst.put("createTime", order.getCreateTime());
		rst.put("createDate", sdf.format(order.getCreateTime()));
		Long orderId = order.getId();
		logger.info("FXPurchaseOrderService>>>>>>>>createOrderNo orderId="+orderId);
		try {
			int orderSeq = returnOrderMapper.getOrderSeq(rst);
			String seqNo = String.format("%06d", orderSeq);
			String orderNo = rst.get("createDate").toString().replaceAll("-", "")+seqNo;
			logger.info("FXPurchaseOrderService>>>>>>>>create orderNo="+orderNo);
//			FXReturnOrder order = returnOrderMapper.selectByPrimaryKey(Long.valueOf(order.toString()));
			order.setOrderNo(orderNo);
			returnOrderMapper.updateByPrimaryKey(order);
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("orderNo", orderNo);
			params.put("orderId", orderId);
			orderGoodsMapper.updateOrderNo(params);
			logger.info("FXPurchaseOrderService>>>>>>>>orderNo update success");
			return true;
		} catch (Exception e) {
			returnOrderMapper.deleteByPrimaryKey(orderId);
			orderGoodsMapper.deleteByOrderId(orderId);
			logger.error("生成订单编号时发生异常，"+e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
	private void saveKafkaMsg(final FXReturnOrder order,final List<FXReturnOrderGoods> itemList){
		new Thread(){
			@Override
			public void run() {
				List<FXReturnOrderGoods> tmpItemList = null;
				logger.info("save return order info to schedule");
				FxOrderMsgPublish orderMsg = new FxOrderMsgPublish();
				orderMsg.setBizNo(order.getOrderNo());
				orderMsg.setCreateTime(new Date());
				orderMsg.setStatus(0);
				orderMsg.setType(2);
				//入库通知单需要的信息
				Map<String,Object> msgMap = new HashMap<String, Object>();
				msgMap.put("customerOrderNo", order.getOrderNo());
				msgMap.put("whId", order.getReceivingWarehouseId());
				msgMap.put("merchantOnlyId", order.getMerchantId());
				msgMap.put("sellerRemark", order.getRemark());
				if(itemList == null )
					tmpItemList = orderGoodsMapper.selectByOrderId(order.getId());
				else
					tmpItemList = itemList;
				List<Map<String,Object>> inDetailList = new ArrayList<Map<String,Object>>();
				for(FXReturnOrderGoods item : tmpItemList){
					Map<String,Object> tmp = new HashMap<String, Object>();
					tmp.put("skuCode", item.getItemId());
					tmp.put("skuName", item.getItemName());
					tmp.put("quantity", item.getPlanNum());
					tmp.put("measure", item.getUnit());
					tmp.put("boxQuantity", item.getPlanNum());
					tmp.put("boxMeasure", item.getUnit());
					tmp.put("boxCapacity", item.getBoxNum());
					tmp.put("salesWay", item.getUnit());
					inDetailList.add(tmp);
				}
				msgMap.put("detailList", inDetailList);
				orderMsg.setMessage(JSONObject.toJSONString(msgMap));
				try{
					logger.info("send return order info to kafka ");
					KafkaProducerHandler.sendReturnOrderTopic(order.getOrderNo(), JSONObject.toJSONString(msgMap));
					orderMsg.setStatus(1);
					orderMsgPublishMapper.insert(orderMsg);
				}catch(Exception e){
					logger.error("send return order info to kafka error:"+e.getMessage());
					orderMsg.setStatus(0);
					orderMsgPublishMapper.insert(orderMsg);
				}
				
			}
			
		}.start();
	}
	/**
	 * 根据订单ID获取订单详细信息
	 * @param orderId
	 * @return
	 */
	public FXReturnOrder fingdOrderByOrderId(Long orderId){
		logger.info("FXPurchaseOrderService>>>>>>>>fingdOrderByOrderId orderId="+orderId);
		try {
			FXReturnOrder order = returnOrderMapper.selectByPrimaryKey(orderId);
			return order;
		} catch (Exception e) {
			logger.error("fingdOrderByOrderId 获取订单详情时异常，"+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * 根据订单ID获取订单详细信息，包括订单商品列表
	 * @param orderId
	 * @return
	 */
	public Map<String,Object> fingdOrderDetailByOrderId(Long orderId){
		logger.info("FXPurchaseOrderService>>>>>>>>fingdOrderDetailByOrderId orderId="+orderId);
		try {
			FXReturnOrder order = returnOrderMapper.selectByPrimaryKey(orderId);
			List<FXReturnOrderGoods> itemList = orderGoodsMapper.selectByOrderId(orderId);
			Map<String,Object> orderDetail = new HashMap<String, Object>();
			orderDetail.put("order", order);
			orderDetail.put("itemList", itemList);
			return orderDetail;
		} catch (Exception e) {
			logger.error("fingdOrderDetailByOrderId 获取订单详情时异常，"+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	@Transactional
	public String updateOrderState(Long orderId,Integer state,String auditResult,Integer version,String user,Long userId){
		
		FXReturnOrder order = returnOrderMapper.selectLockByPrimaryKey(orderId);
		if(state == 1){
			//提交订单
			order.setUpdateTime(new Date());
			order.setUpdateUser(user);
			order.setUpdateUserId(userId);
		}else if(state == 2){
			//审核通过
			order.setAuditTime(new Date());
			order.setAuditUser(user);
			order.setAuditUserId(userId);
			saveKafkaMsg(order,null);
		}else if(state == 3){
			//审核拒绝
			order.setAuditTime(new Date());
			order.setAuditUser(user);
			order.setAuditUserId(userId);
			order.setAuditResult(auditResult);
		}else if(state == 9){
			if(order.getState() == FxPurchaseStateEnum.STATE_ORDER_2.getIndex()){
				if(StringUtils.isBlank(order.getWhOrderNo())){
					return "与仓库信息同步中，请稍后再试！";
				}
				String rst = commonService.cancelReturnOrder(order.getOrderNo());
				logger.info("commonService.cancelReturnOrder=====>>>>"+rst);
				if(!"".equals(rst)){
					JSONObject json = JSONObject.parseObject(rst);
					if("0000".equals(json.getString("code"))){
						//有包裹订单取消成功，取消本系统订单
					}else{
						return json.get("msg").toString();
					}
				}else{
					return "数据请求异常";
				}
			}
			order.setState(state);
			order.setCancelTime(new Date());
			order.setCancelUser(user);
			order.setCancelUserId(userId);
		}
		order.setUpdateTime(new Date());
		order.setUpdateUserId(userId);
		order.setUpdateUser(user);
		
		int rst = returnOrderMapper.updateByPrimaryKeySelective(order);
		if(rst > 0){
			return "orderNo:"+order.getOrderNo();
		}
		return null;
	}
	public String deleteOrder(Long orderId,String user,Long userId){
		FXReturnOrder order = returnOrderMapper.selectByPrimaryKey(orderId);
		//order.setId(orderId);
		order.setDeleteFlag(1);
		order.setCancelTime(new Date());
		order.setCancelUser(user);
		order.setCancelUserId(userId);
		
		order.setUpdateTime(new Date());
		order.setUpdateUserId(userId);
		order.setUpdateUser(user);
		int rst = returnOrderMapper.updateByPrimaryKeySelective(order);
		if(rst > 0){
			return order.getOrderNo();
		}
		return null;
	}
	
}
