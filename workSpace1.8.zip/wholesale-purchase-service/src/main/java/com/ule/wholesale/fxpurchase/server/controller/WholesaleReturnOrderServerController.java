package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.BeanUtils;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.service.FXOperationLogService;
import com.ule.wholesale.fxpurchase.server.service.FXWholesaleReturnOrderService;
import com.ule.wholesale.fxpurchase.server.vo.FXOperationLog;
import com.ule.wholesale.fxpurchase.server.vo.FXWholesaleReturnOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXWholesaleReturnOrderGoods;

@Api(value = "批发退货单接口服务类",tags = "批发退货单接口")  
@RestController
@RequestMapping("/api/wholesaleReturnOrder")
public class WholesaleReturnOrderServerController {
	
	private static Log logger = LogFactory.getLog(WholesaleReturnOrderServerController.class);
	
	@Autowired
	private FXWholesaleReturnOrderService fxWholesaleReturnOrderService;
	@Autowired
	FXOperationLogService operationLogService;

	@RequestMapping("/fingdOrder/{orderId}")
	public ResultDTO<FXWholesaleReturnOrder> fingdOrderByOrderId(@PathVariable("orderId") Long orderId){
		ResultDTO<FXWholesaleReturnOrder>  rstDto = new ResultDTO<FXWholesaleReturnOrder>();
		FXWholesaleReturnOrder order = fxWholesaleReturnOrderService.fingdOrderByOrderId(orderId);
		rstDto.setCode("0000");
		rstDto.setData(order);
		return rstDto;
	}
	
	@RequestMapping("/saveOrderInfo")
	public ResultDTO<Object> saveOrderInfo(@RequestBody Map<String,Object> params){
		ResultDTO<Object> rstDto = new ResultDTO<Object>();
		
		Object obj = params.get("order");
		List<Map<String,Object>> objList = (List<Map<String,Object>>)params.get("itemList");
		FXWholesaleReturnOrder order = new FXWholesaleReturnOrder();
		List<FXWholesaleReturnOrderGoods> itemList = new ArrayList<FXWholesaleReturnOrderGoods>();
		Long orderId = null;
		try {
			BeanUtils.copyProperties(order, obj);
			orderId = order.getId();
			for(Map<String,Object> map :objList){
				FXWholesaleReturnOrderGoods g = new FXWholesaleReturnOrderGoods();
				org.apache.commons.beanutils.BeanUtils.copyProperties(g, map);
				itemList.add(g);
			}
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
			rstDto.setCode("0003");
			rstDto.setMsg(e.getMessage());
			return rstDto;
		}
	
				try {
					order = fxWholesaleReturnOrderService.saveOrder(order, itemList);
				} catch (Exception e) {
					logger.error(e);
					e.printStackTrace();
					rstDto.setCode("0003");
					rstDto.setMsg("保存失败");
					return rstDto;
				}
				if(order.getState() != null && order.getState() == -1){
					rstDto.setCode("0003");
					rstDto.setMsg("数据已被操作，请更新后再操作");
					return rstDto;
				}
			
			//为订单生成订单流水号
			if((orderId != null&&order.getOrderNo()!=null) || fxWholesaleReturnOrderService.createOrderNo(order)){
				FXOperationLog log = new FXOperationLog();
				log.setBizCode(order.getOrderNo());
				//根据状态从枚举项获取名字
				if(order.getState() != null && order.getState() == 1)
					log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_1.getName());
				else{
					if(orderId != null){
						log.setEventType("编辑");
						log.setRemark("编辑保存");
					}else{
						log.setEventType(FxPurchaseStateEnum.STATE_ORDER_BTN_0.getName());
						log.setRemark("新建保存");
					}
				}
					
				
				log.setOpDate(new Date());
				log.setType(FxPurchaseStateEnum.OPLOG_TYPE_7.getIndex());
				log.setUserName(order.getUpdateUser() == null ? order.getCreateUser() : order.getUpdateUser());
				operationLogService.saveOpLog(log);
				rstDto.setCode("0000");
			}else{
				rstDto.setCode("0002");
				rstDto.setMsg("数据保存异常");
			}
		return rstDto;
	}
	
	
	@RequestMapping(value = "/getList",method=RequestMethod.POST)
	@ApiOperation("分页获取批发退货单列表")
	public ResultDTO<Map<String,Object>> getList(
			@ApiParam(name="params",value="批发退货单参数",required=true)@RequestBody Map<String, Object> params,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize,String orderBy){
		logger.info("WholesaleReturnOrderServerController >>> getList");
		ResultDTO<Map<String,Object>> rstDto = new ResultDTO<Map<String,Object>>();
		Map<String,Object> rstMap = new HashMap<String, Object>(); 
		PageInfo<FXWholesaleReturnOrder> pageInfo = fxWholesaleReturnOrderService.getList(params, pageNum, pageSize);
		rstMap.put("currentPage", pageInfo.getPageNum());
		rstMap.put("totalPage", pageInfo.getPages());
		rstMap.put("total", pageInfo.getTotal());
		rstMap.put("list", pageInfo.getList());
		rstDto.setData(rstMap);
		rstDto.setCode("0000");
		rstDto.setMsg("");
		return rstDto;
	}
	
	@RequestMapping(value="/fingdDetail/{orderId}",method={RequestMethod.POST,RequestMethod.GET})
	@ApiOperation("根据批发退货单ID获取详细信息，包括批发退货单商品列表") 
	public ResultDTO<Map<String,Object>> fingdOrderDetailByOrderId(@ApiParam(name = "orderId",value = "批发单ID",required = true)  @PathVariable("orderId")Long orderId){
		ResultDTO<Map<String,Object>> rstDto = new ResultDTO<Map<String,Object>>();
		Map<String,Object> orderDetail = fxWholesaleReturnOrderService.selectdOrderDetailByOrderId(orderId);
		rstDto.setCode("0000");
		rstDto.setData(orderDetail);
		return rstDto;
	}
	
	@RequestMapping("/submit")
	public ResultDTO<Object> updateOrderState(@RequestBody Map<String,Object> params){
		ResultDTO<Object> rstDto = new ResultDTO<Object>();
		rstDto.setCode("1");
		rstDto.setMsg("数据请求异常");
		try {
			Long orderId = Long.valueOf(params.get("orderId").toString());
			Integer state = Integer.valueOf(params.get("state").toString());
			String auditResult = params.get("auditResult").toString();
			Integer version = Integer.valueOf(params.get("version").toString());
			String userName = params.get("username").toString();
			Long userId = Long.valueOf(params.get("userId").toString());
			String orderNo  = fxWholesaleReturnOrderService.updateOrderState(orderId, state,auditResult,version,userName,userId);
			
			if(orderNo != null && orderNo.startsWith("orderNo:")){
				FXOperationLog log = new FXOperationLog();
				log.setBizCode(orderNo.replace("orderNo:", ""));
				//根据状态从枚举项获取名字
				if(state == 1)
					log.setEventType(FxPurchaseStateEnum.WHOLESALE_ORDER_BTN_0_1.getName());
				else if(state == 2)
					log.setEventType(FxPurchaseStateEnum.WHOLESALE_ORDER_BTN_2.getName());
				else if(state == 3){
					log.setEventType(FxPurchaseStateEnum.WHOLESALE_ORDER_BTN_3.getName());
					log.setRemark(auditResult);
				}else{
					//作废订单
					log.setEventType(FxPurchaseStateEnum.WHOLESALE_ORDER_BTN_9.getName());
				}
				log.setOpDate(new Date());
				log.setType(FxPurchaseStateEnum.OPLOG_TYPE_7.getIndex());
				try {
					log.setUserId(userId);
					log.setUserName(userName);
				} catch (Exception e) {
					logger.error("保存日志信息时获取用户信息异常"+e.getMessage());
				}
				operationLogService.saveOpLog(log);
				rstDto.setCode("0");
			}else{
				rstDto.setCode("1");
				rstDto.setMsg(orderNo);
			}
		} catch (Exception e) {
			rstDto.setMsg(e.getMessage());
			e.printStackTrace();
		}
		return rstDto;
	}
	
	@RequestMapping("/{orderId}/delete")
	public ResultDTO<Object> deleteOrder(@PathVariable("orderId") Long orderId,String username,Long userId){
		ResultDTO<Object> rstJson = new ResultDTO<Object>();
		rstJson.setCode("1");
		rstJson.setMsg("数据请求异常");
		try {
			String orderNo = fxWholesaleReturnOrderService.deleteOrder(orderId, username, userId);
			if(orderNo != null){
				FXOperationLog log = new FXOperationLog();
				log.setBizCode(orderNo);
				log.setEventType(FxPurchaseStateEnum.WHOLESALE_ORDER_BTN_0_2.getName());
				log.setOpDate(new Date());
				log.setType(FxPurchaseStateEnum.OPLOG_TYPE_7.getIndex());
				log.setUserId(userId);
				log.setUserName(username);
				operationLogService.saveOpLog(log);
				rstJson.setCode("0");
				rstJson.setMsg("");
			}
		} catch (Exception e) {
			rstJson.setMsg(e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
}
