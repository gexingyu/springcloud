package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ule.wholesale.fxpurchase.server.dto.TestParamDto;
@Api(tags="Spring feignClient")
@RestController
@RequestMapping("/api")
public class TestClientService {

	@RequestMapping("/hello/{name}")
	public Object test(HttpServletRequest req,@PathVariable("name")String name){
		req.getHeader("authorization");
		req.getHeaderNames();
		return "hello  "+ name+">>>"+req.getAttribute("__sessionId__");
	}
	
	@RequestMapping("/params")
	public Object testParam(String name,Integer age,Date birthday){
		System.out.println("hello  "+ name+">>>"+age+">>>>"+birthday);
		return "hello  "+ name+">>>"+age+">>>>"+birthday;
	}
	
	@RequestMapping(value = "/paramList")
	public String testParamList(String name,@RequestBody List<Integer> ages){
		System.out.println(name+">>>>>>"+StringUtils.join(ages, "-"));
		return name+">>>>>>"+StringUtils.join(ages, "-");
	}

	//@RequestBody需要接的参数是一个string化的json,读取的数据在请求体里,所以要发post请求
	@RequestMapping("/dto")
	public Object testDto(@RequestBody TestParamDto dto){
		System.out.println(dto.getName()+"==="+dto.getAge()+">>>"+dto.getBirthday());
		return dto;
	}
	//这样写第二个对象的数据无法传达到后台，@RequestBody 只能使用个
	@RequestMapping(value="/dto2",method = RequestMethod.POST)
	public Object testDto2(@RequestBody TestParamDto dto,TestParamDto dto2){
		System.out.println(dto.getName()+"==="+dto.getAge()+">>>"+dto.getBirthday());
		System.out.println(dto2.getName()+"==="+dto2.getAge()+">>>"+dto2.getBirthday());
		return dto2;
	}
	
	@RequestMapping("/list")
	public Object testList(@RequestBody List<TestParamDto> dtoList){
		for(TestParamDto dto : dtoList)
			System.out.println("List ====>>>"+dto.getName()+"==="+dto.getAge()+">>>"+dto.getBirthday());
		return dtoList;
	}
	
	@RequestMapping("/map")
	public Object testMap(@RequestBody Map<String,Object> params){
		System.out.println(params.get("name")+"==="+params.get("age")+">>>"+params.get("birthday"));
		return params;
	}
}
