package com.ule.wholesale.fxpurchase.server.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.fxpurchase.server.mapper.FXWholesaleReturnOrderGoodsMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXWholesaleReturnOrderMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FxOrderMsgPublishMapper;
import com.ule.wholesale.fxpurchase.server.msghandler.KafkaProducerHandler;
import com.ule.wholesale.fxpurchase.server.vo.FXWholesaleReturnOrder;
import com.ule.wholesale.fxpurchase.server.vo.FXWholesaleReturnOrderGoods;
import com.ule.wholesale.fxpurchase.server.vo.FxOrderMsgPublish;

@Service
public class FXWholesaleReturnOrderService {
	
	private static Logger logger = LoggerFactory.getLogger(FXWholesaleReturnOrderService.class);

	@Autowired
	private FXWholesaleReturnOrderMapper fxWholesaleReturnOrderMapper;
	@Autowired
	private FXWholesaleReturnOrderGoodsMapper fxWholesaleReturnOrderGoodsMapper;
	@Autowired
	private FxOrderMsgPublishMapper orderMsgPublishMapper;
	 
	public FXWholesaleReturnOrder fingdOrderByOrderId(Long id){
		return fxWholesaleReturnOrderMapper.selectByPrimaryKey(id);
	}
	
	
	@Transactional
	public FXWholesaleReturnOrder saveOrder(FXWholesaleReturnOrder order,List<FXWholesaleReturnOrderGoods> itemList) throws Exception{
		logger.info("FXWholesaleReturnOrderService>>>>>>>>save FXWholesaleReturnOrder");
		if(order.getId() == null){
			fxWholesaleReturnOrderMapper.insertSelective(order);
		}else{
			FXWholesaleReturnOrder tmp = fxWholesaleReturnOrderMapper.selectLockByPrimaryKey(order.getId());
			if(tmp.getVersion() != order.getVersion()){
				order.setState(-1);
				return order;
			}
			//订单编辑时先删除已有商品，重新插入
			logger.info("订单编辑操作，删除已有商品信息");
			fxWholesaleReturnOrderGoodsMapper.deleteByOrderId(order.getId());
			fxWholesaleReturnOrderMapper.updateByPrimaryKey(order);
		}
		logger.info("FXWholesaleReturnOrderService>>>>>>>>batch save FXWholesaleReturnOrderGoods");
		for(FXWholesaleReturnOrderGoods record :itemList){
			record.setOrderId(Integer.valueOf(order.getId().toString()));
			fxWholesaleReturnOrderGoodsMapper.insert(record);
		}
		logger.info("FXWholesaleReturnOrderService>>>>>>>>order info save success");
		
		return order;
	}
	@Transactional
	public boolean createOrderNo(FXWholesaleReturnOrder order ){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String,Object> rst = new HashMap<String, Object>();
		rst.put("orderId", order.getId());
		rst.put("createTime", order.getCreateTime());
		rst.put("createDate", sdf.format(order.getCreateTime()));
		Long orderId = order.getId();
		logger.info("FXWholesaleReturnOrderService>>>>>>>>createOrderNo orderId="+orderId);
		try {
			int orderSeq = fxWholesaleReturnOrderMapper.getOrderSeq(rst);
			String seqNo = String.format("%06d", orderSeq);
			String orderNo = rst.get("createDate").toString().replaceAll("-", "")+seqNo;
			logger.info("FXWholesaleReturnOrderService>>>>>>>>create orderNo="+orderNo);
//			FXReturnOrder order = returnOrderMapper.selectByPrimaryKey(Long.valueOf(order.toString()));
			order.setOrderNo(orderNo);
			fxWholesaleReturnOrderMapper.updateByPrimaryKey(order);
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("orderNo", orderNo);
			params.put("orderId", orderId);
			fxWholesaleReturnOrderGoodsMapper.updateOrderNo(params);
			logger.info("FXWholesaleReturnOrderService>>>>>>>>orderNo update success");
			return true;
		} catch (Exception e) {
			fxWholesaleReturnOrderMapper.deleteByPrimaryKey(orderId);
			fxWholesaleReturnOrderGoodsMapper.deleteByOrderId(orderId);
			logger.error("生成订单编号时发生异常，"+e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
	 public PageInfo<FXWholesaleReturnOrder> getList(Map<String, Object> params,Integer pageNum,Integer pageSize){
		 PageHelper.startPage(pageNum, pageSize,"CREATE_TIME DESC,UPDATE_TIME DESC");
		 List<FXWholesaleReturnOrder> lists = fxWholesaleReturnOrderMapper.selectFXWholesaleReturnOrderInfos(params);
		 PageInfo<FXWholesaleReturnOrder> pageInfo = new PageInfo<FXWholesaleReturnOrder>(lists);
		 return pageInfo;
	 }
	 
		/**
		 * 根据批发单ID获取批发退货单详细信息，包括批发退货单商品列表
		 * @param orderId
		 * @return
		 */
		public Map<String,Object> selectdOrderDetailByOrderId(Long orderId){
			logger.info("FXWholesaleReturnOrderService>>>>>>>>selectdOrderDetailByOrderId orderId="+orderId);
			try {
				FXWholesaleReturnOrder order = fxWholesaleReturnOrderMapper.selectByPrimaryKey(orderId);
				List<FXWholesaleReturnOrderGoods> itemList = fxWholesaleReturnOrderGoodsMapper.selectByOrderId(orderId);
				Map<String,Object> orderDetail = new HashMap<String, Object>();
				orderDetail.put("order", order);
				orderDetail.put("itemList", itemList);
				return orderDetail;
			} catch (Exception e) {
				logger.error("selectdOrderDetailByOrderId 获取批发单详情时异常，"+e.getMessage());
				e.printStackTrace();
			}
			return null;
		}
		
		
		@Transactional
		public String updateOrderState(Long orderId,Integer state,String auditResult,Integer version,String user,Long userId){
			logger.info("FXWholesaleReturnOrderService >>>>> updateOrderState state="+state);
			FXWholesaleReturnOrder order = fxWholesaleReturnOrderMapper.selectLockByPrimaryKey(orderId);
			if(version != order.getVersion()){
				return "数据已被操作，请更新后再操作";
			}
			String orderNo = "orderNo:";
				if(state == 1){
					//提交订单
					order.setUpdateTime(new Date());
					order.setUpdateUser(user);
					order.setUpdateUserId(userId);
				}else if(state == 2){
					//审核通过
					order.setAuditTime(new Date());
					order.setAuditUser(user);
					order.setAuditUserId(userId);
//					saveKafkaMsg(order,null);
				}else if(state == 3){
					//审核拒绝
					order.setAuditTime(new Date());
					order.setAuditUser(user);
					order.setAuditUserId(userId);
					order.setReason(auditResult);
				}else if(state == 9){
//					if(order.getState() == FxPurchaseStateEnum.WHOLESALE_ORDER_2.getIndex()){
//						if(StringUtils.isBlank(order.getWhOrderNo())){
//							return "与仓库信息同步中，请稍后再试！";
//						}
//						String rst = "";
//						logger.info("commonService.cancelPurcahseOrder=====>>>>"+rst);
//						if(!"".equals(rst)){
//							JSONObject json = JSONObject.parseObject(rst);
//							if("0000".equals(json.getString("code"))){
//								//有包裹订单取消成功，取消本系统订单
//							}else{
//								return json.get("msg").toString();
//							}
//						}else{
//							return "数据请求异常";
//						}
//					}
					
					order.setCancelTime(new Date());
					order.setCnacelUser(user);
				}
				order.setState(state);
				order.setUpdateTime(new Date());
				order.setUpdateUserId(userId);
				order.setUpdateUser(user);
				
				int rst = fxWholesaleReturnOrderMapper.updateByPrimaryKeySelective(order);
				if(rst > 0){
					return orderNo+order.getOrderNo();
				}
				return null;
			}
		
		public String deleteOrder(Long orderId,String user,Long userId){
			FXWholesaleReturnOrder order = fxWholesaleReturnOrderMapper.selectByPrimaryKey(orderId);
			//order.setId(orderId);
			order.setState(-1);
			order.setCancelTime(new Date());
			order.setCnacelUser(user);
			order.setUpdateTime(new Date());
			order.setUpdateUserId(userId);
			order.setUpdateUser(user);
			int rst = fxWholesaleReturnOrderMapper.updateByPrimaryKeySelective(order);
			if(rst > 0){
				return order.getOrderNo();
			}
			return null;
		}
		
		private void saveKafkaMsg(final FXWholesaleReturnOrder order,final List<FXWholesaleReturnOrderGoods> itemList){
			new Thread(){
				@Override
				public void run() {
					List<FXWholesaleReturnOrderGoods> tmpItemList = null;
					logger.info("save FXWholesaleReturnOrder info to schedule");
					FxOrderMsgPublish orderMsg = new FxOrderMsgPublish();
					orderMsg.setBizNo(order.getOrderNo());
					orderMsg.setCreateTime(new Date());
					orderMsg.setStatus(0);
					orderMsg.setType(4);
				
					Map<String,Object> msgMap = new HashMap<String, Object>();
//					msgMap.put("customerOrderNo", order.getOrderNo());
//					msgMap.put("whId", order.getWarehouseId());
//					msgMap.put("merchantOnlyId", order.getMerchantId());
//					msgMap.put("sellerRemark", order.getRemark());
					if(itemList == null )
						tmpItemList = fxWholesaleReturnOrderGoodsMapper.selectByOrderId(order.getId());
					else
						tmpItemList = itemList;
					List<Map<String,Object>> inDetailList = new ArrayList<Map<String,Object>>();
					for(FXWholesaleReturnOrderGoods item : tmpItemList){
						Map<String,Object> tmp = new HashMap<String, Object>();
						tmp.put("skuCode", item.getItemId());
						tmp.put("skuName", item.getItemName());
						tmp.put("quantity", item.getPlanNum());
						tmp.put("measure", item.getUnit());
						tmp.put("boxQuantity", item.getPlanNum());
						tmp.put("boxMeasure", item.getUnit());
						tmp.put("boxCapacity", item.getBoxNum());
						tmp.put("salesWay", item.getUnit());
						inDetailList.add(tmp);
					}
					msgMap.put("detailList", inDetailList);
					orderMsg.setMessage(JSONObject.toJSONString(msgMap));
					try{
						logger.info("send FXWholesaleReturnOrder info to kafka ");
						KafkaProducerHandler.sendReturnOrderTopic(order.getOrderNo(), JSONObject.toJSONString(msgMap));
						orderMsg.setStatus(1);
						orderMsgPublishMapper.insert(orderMsg);
					}catch(Exception e){
						logger.error("send FXWholesaleReturnOrder info to kafka error:"+e.getMessage());
						orderMsg.setStatus(0);
						orderMsgPublishMapper.insert(orderMsg);
					}
					
				}
				
			}.start();
		}
}
