package com.ule.wholesale.fxpurchase.server.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.fxpurchase.server.dto.FXContractChangeDto;
import com.ule.wholesale.fxpurchase.server.dto.FXContractInfoDto;
import com.ule.wholesale.fxpurchase.server.mapper.FXContractChangeMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXContractInfoMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXContractItemChangeMapper;
import com.ule.wholesale.fxpurchase.server.mapper.FXContractItemListMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXContractChange;
import com.ule.wholesale.fxpurchase.server.vo.FXContractInfo;
import com.ule.wholesale.fxpurchase.server.vo.FXContractItemChange;
import com.ule.wholesale.fxpurchase.server.vo.FXContractItemList;

@Service
public class FXContractChangeService {
	private static Logger logger = LoggerFactory.getLogger(FXContractChangeService.class);
	@Autowired
	private FXContractChangeMapper fxContractChangeMapper;
	@Autowired
	private FXContractItemChangeMapper fxContractItemChangeMapper;
	@Autowired
	private FXContractItemListMapper fxContractItemListMapper;
	@Autowired
	private FXContractInfoMapper fxContractInfoMapper;
	@Autowired
	private FXOperationLogService fxOperationLogService;
	
	@Transactional
	public Long saveItemPriceChange(FXContractChange contractChange, List<FXContractItemChange> contractItemList){
		fxContractChangeMapper.insert(contractChange);
		Long changePaperId = contractChange.getId();
		if(contractItemList!=null && contractItemList.size()>0){
			for(FXContractItemChange contractItem : contractItemList){
				contractItem.setChangePaperId(changePaperId);
				fxContractItemChangeMapper.insert(contractItem);
			}
		}
		return changePaperId;
	}
	
	@Transactional
	public void editItemPriceChange(FXContractChange contractChange, List<FXContractItemChange> contractItemList, Long userId, String userName){
		contractChange.setUpdateUserId(userId);
		contractChange.setUpdateUser(userName);
		contractChange.setUpdateTime(new Date());
		fxContractChangeMapper.updateByPrimaryKey(contractChange);
		Long changePaperId = contractChange.getId();
		if(contractItemList!=null && contractItemList.size()>0){
			fxContractItemChangeMapper.deleteByChangePaperId(changePaperId);
			for(FXContractItemChange contractItem : contractItemList){
				contractItem.setChangePaperId(changePaperId);
				contractItem.setCreateTime(new Date());
				contractItem.setCreateUser(userName);
				contractItem.setCreateUserId(userId);
				fxContractItemChangeMapper.insert(contractItem);
			}
		}
	}
	
	public PageInfo<FXContractChangeDto> getPageByParams(Map<String,Object> params,Integer pageNum,Integer pageSize, String orderBy){
		PageHelper.startPage(pageNum, pageSize, orderBy);
		List<FXContractChangeDto> infoList = fxContractChangeMapper.selectByParams(params);
		PageInfo<FXContractChangeDto> pageInfo = new PageInfo<FXContractChangeDto>(infoList);
		return pageInfo;
	}
	
	@Transactional
	public void delContractChange(FXContractChange info){
		fxContractChangeMapper.updateByPrimaryKey(info);
		fxContractItemChangeMapper.deleteByChangePaperId(info.getId());
	}
	
	/**
	 * 根据主键查询表信息
	 * @param changePaperId
	 * @return
	 */
	public FXContractChange selectByPrimaryKey(Long changePaperId){
		return fxContractChangeMapper.selectByPrimaryKey(changePaperId);
	}
	/**
	 * 根据主键查询扩展表信息
	 * @param changePaperId
	 * @return
	 */
	public FXContractChangeDto selectDtoByPrimaryKey(Long changePaperId){
		return fxContractChangeMapper.selectDtoByPrimaryKey(changePaperId);
	}
	
	public int updateContractChange(FXContractChange contractChange){
		return fxContractChangeMapper.updateByPrimaryKeySelective(contractChange);
	}
	
	@Transactional
	public void changeFXContractInfo(FXContractChange contractChange){
		int i = this.updateContractChange(contractChange);
		if(i > 0  && contractChange.getStatus() == FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_2.getIndex()){
			contractChange = this.selectByPrimaryKey(contractChange.getId());
			FXContractInfo fxContractInfo = fxContractInfoMapper.selectByPrimaryKey(contractChange.getContractId());
			String operate = "";
			if(contractChange.getChangeType() == FxPurchaseStateEnum.CONTRACT_CHANGE_TYPE_1.getIndex()){
				fxContractInfo.setContractAvailableBegin(contractChange.getAvailableBegin());
				fxContractInfo.setContractAvailableEnd(contractChange.getAvailableEnd());
				operate = "基本信息变更";
			}else if(contractChange.getChangeType() == FxPurchaseStateEnum.CONTRACT_CHANGE_TYPE_2.getIndex()){
				fxContractInfo.setBankParentCode(contractChange.getBankParentCode());
				fxContractInfo.setBankParentName(contractChange.getBankParentName());
				fxContractInfo.setBankCode(contractChange.getBankCode());
				fxContractInfo.setBankName(contractChange.getBankName());
				fxContractInfo.setBankBranchName(contractChange.getBankBranchName());
				fxContractInfo.setBankBranchCode(contractChange.getBankBranchCode());
				operate = "账户变更";
			}else if(contractChange.getChangeType() == FxPurchaseStateEnum.CONTRACT_CHANGE_TYPE_5.getIndex()){
				fxContractInfo.setSettleType(contractChange.getSettleType());
				fxContractInfo.setIsPrepay(contractChange.getIsPrepay());
				if(contractChange.getIsPrepay()!=null&&contractChange.getIsPrepay()  == 1){
				  fxContractInfo.setPrepayRate(contractChange.getPrepayRate());
				}
				fxContractInfo.setAccountPeriod(contractChange.getAccountPeriod());
				if(contractChange.getAccountPeriod() != null && contractChange.getAccountPeriod() == FxPurchaseStateEnum.STATE_PERPAYTYPE_0.getIndex()){
					fxContractInfo.setBillDate(contractChange.getBillDate());
				}else {
					fxContractInfo.setBillDate(null);
				}
				operate = "结算变更";
			}
			fxContractInfo.setUpdateUser(contractChange.getUpdateUser());
			fxContractInfo.setUpdateTime(contractChange.getUpdateTime());
			fxContractInfo.setUpdateUser(contractChange.getUpdateUser());
			fxContractInfoMapper.updateByPrimaryKeySelective(fxContractInfo);
			fxOperationLogService.recordLog(fxContractInfo.getId().toString(), FxPurchaseStateEnum.OPLOG_TYPE_2.getIndex(), operate, contractChange.getAuditUserId(), contractChange.getAuditUser(), null);
		}
	}
	
	@Transactional
	public void contractChangeCheck(FXContractChange contractChange,List<FXContractItemChange> itemChangeList,Long userId,String userName){
		fxContractChangeMapper.updateByPrimaryKey(contractChange);
		if(itemChangeList!=null && itemChangeList.size()>0){
			for(FXContractItemChange itemChange : itemChangeList){
				List<FXContractItemList> contractItemList = fxContractItemListMapper.selectByContractIdAndItemId(contractChange.getContractId(),itemChange.getItemId());
				Long begin = contractChange.getAvailableBegin().getTime();
				Long end = contractChange.getAvailableEnd().getTime();
				if(contractItemList!=null && contractItemList.size()>0){
					for(FXContractItemList item : contractItemList){
						//item的结束时间小于当前时间段的开始时间和item的结束时间大于end的无需处理
						//item的有效期的开始时间在当前时间段内
						if(item.getAvailableBegin().getTime() <= end && item.getAvailableBegin().getTime() >= begin){
							//item的有效期的开始时间在当前时间段内，并且结束时间也在当前时间段内，有效期为子集，删除该记录
							if(item.getAvailableEnd().getTime() >= begin && item.getAvailableEnd().getTime() <= end){
								// 子集  delete item
								item.setDeleteFlag(1);
							}else if(item.getAvailableEnd().getTime() > end){
								// 交集,设置item的开始时间为当前时间结束时间的后一天
								Calendar c = Calendar.getInstance();
								c.setTime(contractChange.getAvailableEnd());
								c.add(Calendar.DATE, +1);
								item.setAvailableBegin(c.getTime());
							}
							
						}else if(item.getAvailableBegin().getTime() < begin){
							if(item.getAvailableEnd().getTime() >= begin && item.getAvailableEnd().getTime() <= end){
								// 交集,设置item的结束时间为当前时间开始时间的前一天
								Calendar c = Calendar.getInstance();
								c.setTime(contractChange.getAvailableBegin());
								c.add(Calendar.DATE, -1);
								item.setAvailableEnd(c.getTime());
							}else if(item.getAvailableEnd().getTime() > end){
								// item 时间段拆分，此时item的时间段会被分割三部分，其中一部分和当前时间段重叠
								FXContractItemList itemNew = new FXContractItemList(); 
								try {
									BeanUtils.copyProperties(itemNew, item);
									Calendar c = Calendar.getInstance();
									c.setTime(contractChange.getAvailableBegin());
									c.add(Calendar.DATE, -1);
									item.setAvailableEnd(c.getTime());
									c.setTime(contractChange.getAvailableEnd());
									c.add(Calendar.DATE, 1);
									itemNew.setAvailableBegin(c.getTime());
									itemNew.setId(null);
									fxContractItemListMapper.insert(itemNew);
								} catch (Exception e) {
									logger.error("item 时间段拆分是，beanUtil copy时异常——"+e.getMessage());
									e.printStackTrace();
								} 
							}
							
						}else if(item.getAvailableEnd().getTime() >= begin && item.getAvailableEnd().getTime() <= end){//item的有效期的结束时间在当前时间段内
							if(item.getAvailableBegin().getTime() >= begin && item.getAvailableBegin().getTime() <= end){
								//子集 delete item
								item.setDeleteFlag(1);
							}else if(item.getAvailableBegin().getTime() < begin){
								// 交集,设置item的结束时间为当前时间开始时间的前一天
								Calendar c = Calendar.getInstance();
								c.setTime(contractChange.getAvailableBegin());
								c.add(Calendar.DATE, -1);
								item.setAvailableEnd(c.getTime());
							}
						}else if(item.getAvailableEnd().getTime() > end){
							if(item.getAvailableBegin().getTime() <= end && item.getAvailableBegin().getTime() >= begin){
								// 交集,设置item的开始时间为当前时间结束时间的后一天
								Calendar c = Calendar.getInstance();
								c.setTime(contractChange.getAvailableEnd());
								c.add(Calendar.DATE, +1);
								item.setAvailableBegin(c.getTime());
							}else if(item.getAvailableBegin().getTime() < begin){
								// item 时间段拆分
							}
						}
						//更新修改过的item信息
						fxContractItemListMapper.updateByPrimaryKey(item);
					}
				}
				FXContractItemList contractItem = new FXContractItemList();
				contractItem.setContractId(contractChange.getContractId());
				contractItem.setContractCode(contractChange.getContractCode());
				contractItem.setItemId(itemChange.getItemId());
				contractItem.setMerchantId(itemChange.getMerchantId());
				contractItem.setSku(itemChange.getSku());
				contractItem.setItemName(itemChange.getItemName());
				contractItem.setUnit(itemChange.getUnit());
				contractItem.setNum(itemChange.getNum());
				contractItem.setTaxRate(itemChange.getTaxRate());
				contractItem.setTaxPrice(itemChange.getTaxPrice());
				contractItem.setAvailableBegin(contractChange.getAvailableBegin());
				contractItem.setAvailableEnd(contractChange.getAvailableEnd());
				contractItem.setCreateTime(new Date());
				contractItem.setCreateUserId(userId);
				contractItem.setCreateUser(userName);
				fxContractItemListMapper.insertSelective(contractItem);
			}
		}
	}
	
	@Transactional
	public void contractItemStopCheck(FXContractChange contractChange,List<FXContractItemChange> itemChangeList,Long userId,String userName){
		fxContractChangeMapper.updateByPrimaryKey(contractChange);
		if(itemChangeList!=null && itemChangeList.size()>0){
			for(FXContractItemChange itemChange : itemChangeList){
				List<FXContractItemList> contractItemList = fxContractItemListMapper.selectByContractIdAndItemId(contractChange.getContractId(),itemChange.getItemId());
				Long stop = contractChange.getStopDate().getTime();
				for(FXContractItemList item : contractItemList){
					if(item.getAvailableBegin().getTime()>=stop){
						item.setDeleteFlag(1);
					}
					if(item.getAvailableBegin().getTime()<stop && item.getAvailableEnd().getTime()>=stop){
						item.setAvailableEnd(contractChange.getStopDate());
					}
					fxContractItemListMapper.updateByPrimaryKey(item);
				}
			}
		}
	}
	
	@Transactional
	public void createChangePaperCode(Long changePaperId){
		DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		FXContractChange info = fxContractChangeMapper.selectByPrimaryKey(changePaperId);
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("createTime", info.getCreateTime());
		params.put("createDate", format1.format(info.getCreateTime()));
		Integer index = fxContractChangeMapper.getOrderSeq(params);
		String temp = "";
		if(index.toString().length()<6){
			for(int i=0; i<6-index.toString().length(); i++){
				temp += "0";
			}
		}
		DateFormat format = new SimpleDateFormat("yyyyMMdd");
		String dayStr = format.format(new Date());
		String changePaperCode = dayStr + temp + index.toString();
		info.setChangePaperCode(changePaperCode);
		fxContractChangeMapper.updateByPrimaryKey(info);
		
		List<FXContractItemChange> paperList = fxContractItemChangeMapper.selectByChangePaperId(changePaperId);
		if(paperList!=null && paperList.size()>0){
			for(FXContractItemChange change : paperList){
				change.setChangePaperCode(changePaperCode);
				fxContractItemChangeMapper.updateByPrimaryKey(change);
			}
		}
	}
	
	public void delFXContractChange(Long id){
		fxContractChangeMapper.deleteByPrimaryKey(id);
	}
	
	public boolean compareContractAvailable(Long contractId,Long contractChangeId,Date availableBegin,Date availableEnd){
		Long supplierId = 0l;
		if(contractId !=null && contractId>0){
			FXContractInfo fxContractInfo = fxContractInfoMapper.selectByPrimaryKey(contractId);
			supplierId = fxContractInfo.getSupplierId();
		}
		if(contractChangeId !=null && contractChangeId>0){
			FXContractChange fxContractChange = fxContractChangeMapper.selectByPrimaryKey(contractChangeId);
			supplierId = fxContractChange.getSupplierId();
			contractId = fxContractChange.getContractId();
		}
		//查询出此供应商的其他审核通过且未被删除的合同
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("supplierId", supplierId);
		paramMap.put("statusAttr", new Integer[]{FxPurchaseStateEnum.STATE_CONTRACT_0.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_1.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_2.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_3.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_4.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_5.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_6.getIndex(),FxPurchaseStateEnum.STATE_CONTRACT_7.getIndex()});
		paramMap.put("deleteFlag", 0);
		List<FXContractInfoDto> list = fxContractInfoMapper.selectByParams(paramMap);
		//比较其他合同的有效期与此变更的有效期是否重合
		boolean flag = true;
		if(list!=null && list.size()>0){
			for(FXContractInfoDto info : list){
				if(!info.getId().toString().equals(contractId.toString())){
					if(availableEnd.before(info.getContractAvailableBegin()) 
							|| availableBegin.after(info.getContractAvailableEnd())){
						continue;
					}else {
						flag = false;
						break;
					}
				}
			}
		}
		return flag;
	}
}
