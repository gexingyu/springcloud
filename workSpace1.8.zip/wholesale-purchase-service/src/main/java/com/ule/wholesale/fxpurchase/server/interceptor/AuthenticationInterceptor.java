package com.ule.wholesale.fxpurchase.server.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class AuthenticationInterceptor extends HandlerInterceptorAdapter  {

	private static Logger logger = LoggerFactory.getLogger(AuthenticationInterceptor.class);
	@Override
	public boolean preHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler) throws Exception {
		// 如果不是映射到方法直接通过
        if (!(handler instanceof HandlerMethod)) {
            return true;
        }
//        HandlerMethod handlerMethod = (HandlerMethod) handler;
//        Method method = handlerMethod.getMethod();
//        LoginRequired methodAnnotation = method.getAnnotation(LoginRequired.class);
        // 执行认证
        logger.info("request.getRequestURL()="+request.getRequestURL());
        String appkey = request.getHeader("appkey");  // 从 http 请求头中取出 token
        String token = request.getHeader("token");  // 从 http 请求头中取出 token
        logger.info("appkey="+appkey+">>>>>>token="+token);
        String error = "";
        if (StringUtils.isBlank(appkey)) {
        	error += "appkey不能为空";
        }
        if (StringUtils.isBlank(token)) {
        	error +=  "token信息不完整";
        }
        //验证token是否正确
    	//验证数据是否被篡改
        if(!"".equals(error)){
//        	response.getWriter().print("error="+error);
        	throw new Exception(error);
//        	return false;
        }
        return true;
	}

}
