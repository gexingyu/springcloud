package com.ule.wholesale.fxpurchase.server.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.ule.wholesale.fxpurchase.server.mapper.FXOperationLogMapper;
import com.ule.wholesale.fxpurchase.server.vo.FXOperationLog;

@Service
public class FXOperationLogService {

	private static Log logger = LogFactory.getLog(FXOperationLogService.class);
	@Autowired
	private FXOperationLogMapper operationLogMapper;
	
	public void saveOpLog(FXOperationLog log){
		if(org.apache.commons.lang3.StringUtils.isBlank(log.getRemark())){
			log.setRemark(log.getEventType());
		}
		final FXOperationLog log1 = log;
		new Thread(){
			public void run() {
				logger.info("保存操作日志信息，"+JSONObject.toJSONString(log1));
				operationLogMapper.insert(log1);
			};
		}.start();
	}
	/**
	 * 根据日志业务代码和业务类型查询某个单据的操作日志列表
	 * @param bizCode
	 * @param type
	 * @return
	 */
	public List<FXOperationLog> getOperationLogList(String bizCode,Integer type){
		logger.info("获取操作日志信息，getFXOperationLogList bizCode="+bizCode);
		List<FXOperationLog>  logList = null;
		try {
			logList = operationLogMapper.selectByBizCodeAndType(bizCode, type);
		} catch (Exception e) {
			logger.error("获取单据操作日志列表异常："+e.getMessage());
			e.printStackTrace();
		}
		return logList;
	}
	
	/**
	 * 操作日志记录
	 * @param eventId 被执行操作表的主键
	 * @param type  业务类型
	 * @param eventType 事件类型
	 * @param userId
	 * @param userName
	 * */
	public void recordLog(String eventId,Integer type, String eventType,Long userId,String userName,String remark){
		FXOperationLog optLog = new FXOperationLog();
		optLog.setBizCode(eventId);
		optLog.setType(type);
		optLog.setEventType(eventType);
		optLog.setUserId(userId);
		optLog.setUserName(userName);
		if(org.apache.commons.lang3.StringUtils.isBlank(remark)){
			optLog.setRemark(eventType);
		}else
			optLog.setRemark(remark);
		optLog.setOpDate(new Date());
		this.saveOpLog(optLog);
	}
}
