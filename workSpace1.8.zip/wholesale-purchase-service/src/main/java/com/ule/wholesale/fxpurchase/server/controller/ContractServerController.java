package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.dto.FXContractInfoDto;
import com.ule.wholesale.fxpurchase.server.service.FXContractChangeService;
import com.ule.wholesale.fxpurchase.server.service.FXContractInfoService;
import com.ule.wholesale.fxpurchase.server.vo.FXContractInfo;

@RestController
@Api(value="合同接口服务", tags="合同接口服务")  
@RequestMapping("/api/contract")
public class ContractServerController {
	
	@Autowired
	private FXContractInfoService fxContractInfoService;
	@Autowired
	private FXContractChangeService fxContractChangeService;
	
	@RequestMapping(value="/getPageByParams", method=RequestMethod.POST)
	@ApiOperation("获取合同列表")
	public ResultDTO<Map<String,Object>> getPageByParams(
			@ApiParam(name="params",value="查询条件",required=true)@RequestBody Map<String, Object> params,
			@ApiParam(name="pageNum",value="页码",required=true)Integer pageNum,
			@ApiParam(name="pageSize",value="每页数量",required=true)Integer pageSize,
			@ApiParam(name="orderBy",value="排序")String orderBy){
		ResultDTO<Map<String,Object>> rstDTO = new ResultDTO<Map<String,Object>>();
		Map<String, Object> rstMap = new HashMap<String, Object>();
		
		PageInfo<FXContractInfoDto> pageInfo = fxContractInfoService.getPageByParams(params, pageNum, pageSize, orderBy);
		rstMap.put("list", pageInfo.getList());
		rstMap.put("pageNum", pageInfo.getPageNum());
		rstMap.put("pages", pageInfo.getPages());
		rstMap.put("total", pageInfo.getTotal());
		
		rstDTO.setData(rstMap);
		rstDTO.setCode("0");
		rstDTO.setMsg("");
		return rstDTO;
	}
	
	@RequestMapping(value="/compareContractAvailable")
	@ApiOperation("判断供应商合同有效期是否重叠")
	public boolean compareContractAvailable(
			@ApiParam(name="supplierId",value="供应商ID",required=true)Long supplierId,
			@ApiParam(name="contractId",value="合同ID")Long contractId,
			@ApiParam(name="availableBegin",value="有效期开始",required=true)Date availableBegin,
			@ApiParam(name="availableEnd",value="有效期结算",required=true)Date availableEnd){
		return fxContractInfoService.compareContractAvailable(supplierId, contractId, availableBegin, availableEnd);
	}
	
	@RequestMapping(value="/addContract")
	@ApiOperation("保存合同")
	public Long addContract(@ApiParam(name="fxContractInfo",value="合同信息",required=true)@RequestBody FXContractInfo fxContractInfo){
		return fxContractInfoService.addContract(fxContractInfo);
	}
	
	@RequestMapping(value="/createContractCode")
	@ApiOperation("生产合同编号")
	public void createContractCode(@ApiParam(name="contractId",value="合同ID",required=true)Long contractId){
		fxContractInfoService.createContractCode(contractId);
	}
	
	@RequestMapping(value="/selectDtoByPrimaryKey")
	@ApiOperation("根据主键ID查询合同信息")
	public FXContractInfoDto selectDtoByPrimaryKey(@ApiParam(name="contractId",value="合同ID",required=true)Long contractId){
		return fxContractInfoService.selectDtoByPrimaryKey(contractId);
	}
	
	@RequestMapping(value="/delContract")
	@ApiOperation("根据主键删除分类")
	public void delContract(@ApiParam(name="fxContractInfo",value="合同信息",required=true)@RequestBody FXContractInfo fxContractInfo){
		fxContractInfoService.delContract(fxContractInfo);
	}
	
	@RequestMapping(value="/editContract")
	@ApiOperation("编辑分类")
	public void editContract(@ApiParam(name="fxContractInfo",value="合同信息",required=true)@RequestBody FXContractInfo fxContractInfo){
		fxContractInfoService.delContract(fxContractInfo);
	}
	
	@RequestMapping(value="/submitContract")
	@ApiOperation("提交分类")
	public void submitContract(@ApiParam(name="fxContractInfo",value="合同信息",required=true)@RequestBody FXContractInfo fxContractInfo){
		fxContractInfoService.submitContract(fxContractInfo);
	}
}
