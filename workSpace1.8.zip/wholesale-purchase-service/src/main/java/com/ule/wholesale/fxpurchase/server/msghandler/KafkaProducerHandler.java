package com.ule.wholesale.fxpurchase.server.msghandler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ule.tools.client.kafka.core.config.KafkaClientsConfig;
import com.ule.tools.client.kafka.producer.Message;
import com.ule.tools.client.kafka.producer.Producer;

public class KafkaProducerHandler {
	private static Logger logger = LoggerFactory.getLogger(KafkaProducerHandler.class);
	private static KafkaClientsConfig config = KafkaClientsConfig.DEFAULT_INSTANCE;
	
	public static void sendOrderTopic(String key,String value) throws Exception{
			logger.info("sendOrderTopic start...");
			if(config == null)
				config = new KafkaClientsConfig("kafka-clients-cfg.xml");
			Producer<String> producer = (Producer<String>) config.getOrCreateProducer("kafka_wholesale_purchase_order");
			producer.send(key,value);
			logger.info("send order topic end");
	}
	
	public static void batchSendOrderTopic(List<Message<String>> msgList){
		try {
			logger.info("batchSendOrderTopic start...");
			if(config == null)
				config = new KafkaClientsConfig("kafka-clients-cfg.xml");
			Producer<String> producer = (Producer<String>) config.getOrCreateProducer("kafka_wholesale_purchase_order");
//			List<Message<String>> msgList = new ArrayList<Message<String>>();
//			Message<String> msg = new Message<String>(key, value);
//			msgList.add(msg);
			producer.batchSend(msgList);
			logger.info("batchSendOrderTopic end");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void sendReturnOrderTopic(String key,String value)throws Exception{
		logger.info("sendReturnOrderTopic start...");
			if(config == null)
				config = new KafkaClientsConfig("kafka-clients-cfg.xml");
			Producer<String> producer = (Producer<String>) config.getOrCreateProducer("kafka_wholesale_return_order");
			producer.send(key,value);
			logger.info("send return order topic end");
	}
	
	public static void batchSendReturnOrderTopic(List<Message<String>> msgList){
		try {
			logger.info("batchSendReturnOrderTopic start...");
			if(config == null)
				config = new KafkaClientsConfig("kafka-clients-cfg.xml");
			Producer<String> producer = (Producer<String>) config.getOrCreateProducer("kafka_wholesale_return_order");
//			List<Message<String>> msgList = new ArrayList<Message<String>>();
//			Message<String> msg = new Message<String>(key, value);
//			msgList.add(msg);
			producer.batchSend(msgList);
			logger.info("batchSendReturnOrderTopic end");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void sendTopic(String id,String key,String value){
		try {
			if(config == null)
				config = new KafkaClientsConfig("kafka-clients-cfg.xml");
			Producer<String> producer = (Producer<String>) config.getOrCreateProducer(id);
			producer.send(key,value);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
