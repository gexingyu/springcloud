package com.ule.wholesale.fxpurchase.server.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ule.wholesale.common.util.ResultDTO;
/**
 * 拦截所有RestController抛出的异常。包括拦截器抛出的
 * @author zhengmingzhi
 *
 */
@ControllerAdvice(annotations = RestController.class)
public class RestControllerAdvice {

  @InitBinder
  public void initBinder(ServletRequestDataBinder binder) {
    binder.registerCustomEditor(Date.class, new CustomDateEditor(
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"), true));
  }

  @Bean
  public Jackson2ObjectMapperBuilder getJackson2ObjectMapperBuilder() {
    return Jackson2ObjectMapperBuilder.json().dateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
  }

  @ExceptionHandler(Exception.class)
  @ResponseBody
  public ResultDTO<Object> handleException(HttpServletRequest req, Exception e) {
    e.printStackTrace();
    return ResultDTO.fail(e.getMessage());
  }
}
