package com.ule.wholesale.fxpurchase.server.controller;

import io.swagger.annotations.Api;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.server.service.BankInfoService;

@RestController
@RequestMapping("/api/bank")
@Api(value="获取银行列表信息",tags = "获取银行列表信息")
public class BankInfoServerController {

	private Log logger = LogFactory.getLog(BankInfoServerController.class);
	@Autowired
	private BankInfoService bankInfoService;
	
	@RequestMapping(value="/findBankInfoList",method={RequestMethod.POST,RequestMethod.GET})
	public ResultDTO<Map<Object, Object>> findBankInfoList(){
		ResultDTO<Map<Object, Object>> rstDTO = new ResultDTO<Map<Object, Object>>();
		try{
			Map<Object, Object> rMap = bankInfoService.findBankInfoList();
			rstDTO.setCode("0000");
			rstDTO.setData(rMap);
			return rstDTO;
		}catch(Exception e){
			logger.error("error", e);
			rstDTO.setCode("1111");
			rstDTO.setMsg(e.getMessage());
			return rstDTO;
		}
	}
}
