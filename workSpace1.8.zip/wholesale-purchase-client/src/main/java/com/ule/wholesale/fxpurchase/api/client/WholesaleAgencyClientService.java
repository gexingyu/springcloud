package com.ule.wholesale.fxpurchase.api.client;

import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXOPcDmsOrgRelationDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface WholesaleAgencyClientService {

	@RequestMapping(value = "/api/agency/{id}/edit")
	public ResultDTO<FXOPcDmsOrgRelationDto> selectFxoPcDmsOrgRelationById(@PathVariable("id")Long id);
	
	@RequestMapping(value = "/api/agency/addAgency",method=RequestMethod.POST)
	public ResultDTO<Integer> saveWholesaleAgency(@RequestBody FXOPcDmsOrgRelationDto fxoPcDmsOrgRelationDto);
	
	@RequestMapping(value = "/api/agency/list",method=RequestMethod.POST,consumes = "application/json")
	public ResultDTO<Map<String, Object>> getAgencyListByPage(
			@RequestBody FXOPcDmsOrgRelationDto fxoPcDmsOrgRelationDto,@RequestParam("pageNum")Integer pageNum,
			@RequestParam("pageSize")Integer pageSize,@RequestParam("orderBy")String orderBy);
	
	@RequestMapping(value = "/api/agency/edit",method=RequestMethod.POST)
	public ResultDTO<Integer> updateFxoPcDmsOrgRelation(@RequestBody FXOPcDmsOrgRelationDto fxoPcDmsOrgRelationDto);
}
