package com.ule.wholesale.fxpurchase.api.client;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXRequireGoodsListDto;


@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface RequireGoodsClientService {

	@RequestMapping(value="/api/require/getPageByParams", method=RequestMethod.POST, consumes = "application/json")
	public ResultDTO<Map<String,Object>> getPageByParams(@RequestBody Map<String, Object> params, @RequestParam("pageNum")Integer pageNum, @RequestParam("pageSize")Integer pageSize, @RequestParam("orderBy")String orderBy);
	
	@RequestMapping(value="/api/require/saveRequireGoods",method=RequestMethod.POST)
	public List<String> saveRequireGoods(@RequestBody FXRequireGoodsListDto rqGoods);
	
	@RequestMapping(value="/api/require/saveRequireGoodsOfBatch",method=RequestMethod.POST)
	public List<String> saveRequireGoodsOfBatch(@RequestBody List<FXRequireGoodsListDto> rqGoodsDtoList);
	
	@RequestMapping(value="/api/require/selectByPrimaryKey")
	public FXRequireGoodsListDto selectByPrimaryKey(@RequestParam("requireId")Long requireId);
	
	@RequestMapping(value="/api/require/{orderNo}/dto")
	public FXRequireGoodsListDto getFXRequireGoodsListDtoByOrderNo(@RequestParam("orderNo")String orderNo,@RequestParam("orderType")String orderType);
	
	@RequestMapping(value="/api/require/updateRequireGoods",method=RequestMethod.POST)
	public void updateRequireGoods(@RequestBody FXRequireGoodsListDto rqGoods);
	
	@RequestMapping(value="/api/require/updateBatchRequireGoods",method=RequestMethod.POST)
	public void updateBatchRequireGoods(@RequestBody List<FXRequireGoodsListDto> rqGoodsList);
	
}
