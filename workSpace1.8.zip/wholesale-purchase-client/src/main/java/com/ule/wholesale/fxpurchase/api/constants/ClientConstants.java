package com.ule.wholesale.fxpurchase.api.constants;

import java.util.HashMap;
import java.util.Map;
public class ClientConstants {
	//接口服务中的server.context-path的值
	public final static String SERVER_PATH = "purchaseService";
	//对应接口服务中的Consul的serviceName,一般就是spring.application.name
	public final static String SERVICE_NAME= "wholesale-purchase-provider";
	//用来设置一下固定的head信息传递到接口服务中，使用代码参照ClientsHeadersSettingInterceptor
	public static Map<String, Object> headMap = new HashMap<String, Object>();
}
