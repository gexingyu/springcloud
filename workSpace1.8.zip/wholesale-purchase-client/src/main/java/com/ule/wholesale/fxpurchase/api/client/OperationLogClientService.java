package com.ule.wholesale.fxpurchase.api.client;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXOperationLogDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface OperationLogClientService {

	@RequestMapping(value="/api/opLog/save",method=RequestMethod.POST)
	public boolean saveOpLog(@RequestBody FXOperationLogDto log);
	/**
	 * 根据日志业务代码和业务类型查询某个单据的操作日志列表
	 * @param bizCode
	 * @param type
	 * @return
	 */
	@RequestMapping("/api/opLog/list")
	public List<FXOperationLogDto> getOperationLogList(@RequestParam("bizCode") String bizCode,@RequestParam("type") Integer type);
}
