package com.ule.wholesale.fxpurchase.api.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;

import feign.RequestInterceptor;
import feign.RequestTemplate;

@Configuration
public class ClientsHeadersSettingInterceptor {
	//指定哪些head中的信息需要传递到接口服务中，如果是固定值（appke，token）可以直接在常量ClientConstants.headMap设置
	//如果request head中已经存在可以指定key从request中进行获取，此时的值key为任意值
	private static List<String> headerKeyList = new ArrayList<String>();
	private static Map<String,String> headerValueMap = new HashMap<String,String>();
	static{
		headerKeyList.add("appkey");
		headerKeyList.add("token");
		headerKeyList.add("sign");
		headerValueMap.put("appkey","test1");
		headerValueMap.put("token","sdfasdfadsfasd111");
		headerValueMap.put("sign","");
	}
	@Autowired
	HttpServletRequest request;
	@Bean
	public RequestInterceptor headerInterceptor() {
		return new RequestInterceptor() {
			@Override
			public void apply(RequestTemplate requestTemplate) {	
//				Enumeration<String> headerNames = request.getHeaderNames();
//				if (headerNames != null) {
//                    //此处可以对当前request中信息进行修改
//					int i = 0;//记录headerHandlerList的key处理的个数，如果已经处理完则跳出循环
//					while (headerNames.hasMoreElements() && i < headerHandlerList.size()) {
//						String name = headerNames.nextElement();
//						if(headerHandlerList.contains(name)){
//							i++;
//							Enumeration<String> values = request.getHeaders(name);
//							while (values.hasMoreElements()) {
//								requestTemplate.header(name, values.nextElement());
//							}
//						}
//						
//					}
//				}
				for(String key : headerKeyList){
					String value = request.getHeader(key);
					requestTemplate.header(key, headerValueMap.get(key));
					if(StringUtils.isNotBlank(value))
						requestTemplate.header(key, value);
				}
                for(String key : ClientConstants.headMap.keySet()){
                    if(ClientConstants.headMap.get(key) != null && StringUtils.isNotBlank(ClientConstants.headMap.get(key).toString()))
                        requestTemplate.header(key, ClientConstants.headMap.get(key).toString());
                }
			}
		};
	}
}
