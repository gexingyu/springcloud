package com.ule.wholesale.fxpurchase.api.dto;

public class FXWholesaleOrderParam {
	
	private String planReciptBeginTime;
	private String planReciptEndTime;
	private String deliveryBeginTime;
	private String deliveryEndTime;
	private String whReceiptBeginTime;
	private String whReceiptEndTime;
	
	private String	applyBeginTime;
	private String	applyEndTime;
	private String	whReturnBeginTime;
	private String	whReturnEndTime;
	public String getPlanReciptBeginTime() {
		return planReciptBeginTime;
	}
	public void setPlanReciptBeginTime(String planReciptBeginTime) {
		this.planReciptBeginTime = planReciptBeginTime;
	}
	public String getPlanReciptEndTime() {
		return planReciptEndTime;
	}
	public void setPlanReciptEndTime(String planReciptEndTime) {
		this.planReciptEndTime = planReciptEndTime;
	}
	public String getDeliveryBeginTime() {
		return deliveryBeginTime;
	}
	public void setDeliveryBeginTime(String deliveryBeginTime) {
		this.deliveryBeginTime = deliveryBeginTime;
	}
	public String getDeliveryEndTime() {
		return deliveryEndTime;
	}
	public void setDeliveryEndTime(String deliveryEndTime) {
		this.deliveryEndTime = deliveryEndTime;
	}
	public String getWhReceiptBeginTime() {
		return whReceiptBeginTime;
	}
	public void setWhReceiptBeginTime(String whReceiptBeginTime) {
		this.whReceiptBeginTime = whReceiptBeginTime;
	}
	public String getWhReceiptEndTime() {
		return whReceiptEndTime;
	}
	public void setWhReceiptEndTime(String whReceiptEndTime) {
		this.whReceiptEndTime = whReceiptEndTime;
	}
	public String getApplyBeginTime() {
		return applyBeginTime;
	}
	public void setApplyBeginTime(String applyBeginTime) {
		this.applyBeginTime = applyBeginTime;
	}
	public String getApplyEndTime() {
		return applyEndTime;
	}
	public void setApplyEndTime(String applyEndTime) {
		this.applyEndTime = applyEndTime;
	}
	public String getWhReturnBeginTime() {
		return whReturnBeginTime;
	}
	public void setWhReturnBeginTime(String whReturnBeginTime) {
		this.whReturnBeginTime = whReturnBeginTime;
	}
	public String getWhReturnEndTime() {
		return whReturnEndTime;
	}
	public void setWhReturnEndTime(String whReturnEndTime) {
		this.whReturnEndTime = whReturnEndTime;
	}
	
	
}
