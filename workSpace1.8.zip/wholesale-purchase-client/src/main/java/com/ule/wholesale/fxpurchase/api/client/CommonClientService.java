package com.ule.wholesale.fxpurchase.api.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
@Scope("singleton")
public interface CommonClientService {

	@RequestMapping("/api/common/sendMsg")
	public ResultDTO<Object> sendMsg();
	@RequestMapping("/api/common/handlerMsg")
	public ResultDTO<Object> handlerOrderStateFeedback();
	
}
