package com.ule.wholesale.fxpurchase.api.dto;

public class FXOPcDmsOrgRelationParam {

	private String provinceOrgName;
	private String provinceOrg;
	private String cityOrgName;
	private String cityOrg;
	private String countyOrgName;
	private String countyOrg;
	private String DMSOrg;
	private String DMSOrgName;
	public String getProvinceOrgName() {
		return provinceOrgName;
	}
	public void setProvinceOrgName(String provinceOrgName) {
		this.provinceOrgName = provinceOrgName;
	}
	public String getProvinceOrg() {
		return provinceOrg;
	}
	public void setProvinceOrg(String provinceOrg) {
		this.provinceOrg = provinceOrg;
	}
	public String getCityOrgName() {
		return cityOrgName;
	}
	public void setCityOrgName(String cityOrgName) {
		this.cityOrgName = cityOrgName;
	}
	public String getCityOrg() {
		return cityOrg;
	}
	public void setCityOrg(String cityOrg) {
		this.cityOrg = cityOrg;
	}
	public String getCountyOrgName() {
		return countyOrgName;
	}
	public void setCountyOrgName(String countyOrgName) {
		this.countyOrgName = countyOrgName;
	}
	public String getCountyOrg() {
		return countyOrg;
	}
	public void setCountyOrg(String countyOrg) {
		this.countyOrg = countyOrg;
	}
	public String getDMSOrg() {
		return DMSOrg;
	}
	public void setDMSOrg(String dMSOrg) {
		DMSOrg = dMSOrg;
	}
	public String getDMSOrgName() {
		return DMSOrgName;
	}
	public void setDMSOrgName(String dMSOrgName) {
		DMSOrgName = dMSOrgName;
	}
	
}
