package com.ule.wholesale.fxpurchase.api.client;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemListDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface ContractItemClientService {

	@RequestMapping(value="/api/contractItem/getPageByParams", method=RequestMethod.POST, consumes = "application/json")
	public ResultDTO<PageInfo<FXContractItemListDto>> getPageByParams(@RequestBody Map<String, Object> params, @RequestParam("pageNum")Integer pageNum, @RequestParam("pageSize")Integer pageSize, @RequestParam("orderBy")String orderBy);
	
	@RequestMapping(value="/api/contractItem/selectEffectiveItemListByContractId", method=RequestMethod.POST, consumes = "application/json")
	public ResultDTO<PageInfo<FXContractItemListDto>> selectEffectiveItemListByContractId(@RequestBody Map<String, Object> params, @RequestParam("pageNum")Integer pageNum, @RequestParam("pageSize")Integer pageSize, @RequestParam("orderBy")String orderBy);
	
	@RequestMapping(value="/findEffectiveItemList", method=RequestMethod.POST)
	public ResultDTO<PageInfo<FXContractItemListDto>> findEffectiveItemList(@RequestBody Map<String, Object> params,@RequestParam("pageNum")Integer pageNum, @RequestParam("pageSize")Integer pageSize);
	
	@RequestMapping(value="/api/contractItem/selectBySupplierIdAndItemId")
	public Map<String, Object> selectBySupplierIdAndItemId(@RequestParam("supplierId") Long supplierId, @RequestParam("itemId") Long itemId);
	
	@RequestMapping(value="/api/contractItem/getMerchantIdsByItemIds", method=RequestMethod.POST)
	public List<Long> getMerchantIdsByItemIds(@RequestBody List<Long> itemIdList);
	
	@RequestMapping(value="/api/contractItem/selectByItemId")
	public List<FXContractItemListDto> selectByItemId(@RequestParam("itemId") Long itemId);
	
	@RequestMapping(value="/api/contractItem/selectByPrimaryKey")
	public FXContractItemListDto selectByPrimaryKey(@RequestParam("contractItemId") Long contractItemId);
}
