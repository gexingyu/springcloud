package com.ule.wholesale.fxpurchase.api.client;

import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemListDto;
import com.ule.wholesale.fxpurchase.api.dto.FXPurchaseOrderDto;
import com.ule.wholesale.fxpurchase.api.dto.FXPurchaseOrderGoodsDto;
/**
 * @author zhengmingzhi
 *
 */
@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface OrderClientService {
	
	@RequestMapping("/api/order/fingdDetail/{orderId}")
	public ResultDTO<Map<String,Object>> fingdOrderDetailByOrderId(@PathVariable("orderId")Long orderId);
	@RequestMapping(value="/api/order/findOrderList",method=RequestMethod.POST)
	public ResultDTO<Map<String,Object>> findOrderList(@RequestBody Map<String,Object> params);
	
	@RequestMapping(value="/api/order/findEffectiveItemList", method=RequestMethod.POST)
	public ResultDTO<PageInfo<FXContractItemListDto>> findEffectiveItemList(@RequestBody Map<String,Object> params);
	@RequestMapping("/api/order/fingdOrder/{orderId}")
	public ResultDTO<FXPurchaseOrderDto> fingdOrderByOrderId(@PathVariable("orderId") Long orderId);
	@RequestMapping(value="/api/order/saveOrderInfo",method=RequestMethod.POST)
	public ResultDTO<FXPurchaseOrderDto> saveOrderInfo(@RequestBody Map<String,Object> params);
	@RequestMapping(value="/api/order/submit",method=RequestMethod.POST)
	public ResultDTO<Object> updateOrderState(@RequestBody Map<String,Object> params);
	@RequestMapping(value="/api/order/receiveOrder",method=RequestMethod.POST)
	public ResultDTO<Object> receiveOrder(@RequestBody Map<String,Object> params);
	@RequestMapping("/api/order/pay/{orderId}")
	public ResultDTO<Object> payOrder(@PathVariable("orderId") Long orderId,@RequestParam("version")Integer version,@RequestParam("username")String username,@RequestParam("userId")Long userId);
	@RequestMapping("/api/order/{orderId}/delete")
	public ResultDTO<Object> deleteOrder(@PathVariable("orderId") Long orderId,@RequestParam("username")String username,@RequestParam("userId")Long userId);
	
	@RequestMapping(value="/api/order/findPurchaseItemList",method=RequestMethod.POST)
	public ResultDTO<PageInfo<FXPurchaseOrderGoodsDto>> findPurchaseItemList(@RequestBody Map<String,Object> params,@RequestParam("pageNum")Integer pageNum,@RequestParam("pageSize")Integer pageSize);
}
