package com.ule.wholesale.fxpurchase.api.client;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.TestParamDto;
@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
//@FeignClient(value=ClientConstants.EURKA_CLIENT_APPID,configuration=FeignClientsConfiguration.class/*,fallback=FeignClientFallback.class*/)
public interface TestClientService {

	@RequestMapping(value = "/api/hello/{name}",method = RequestMethod.GET/*,headers = "Authorization = Basic ${service.auth}:11111"*/)
    public  String hello(@PathVariable("name") String name);
	
	/**
	 * 传递多个参数,需要添加@RequestParam注解，GET POST 均可
	 * @param name
	 * @param age
	 * @param birthday
	 * @return
	 */
	@RequestMapping(value = "/api/params",method = RequestMethod.POST)
	public String testParam(@RequestParam("name")String name,@RequestParam("age")Integer age,@RequestParam("birthday")Date birthday);
	
	@RequestMapping(value = "/api/paramList",method = RequestMethod.POST,consumes = "application/json")
	public String testParamList(@RequestParam("name")String name,@RequestBody List<Integer> ages);
	
	/**
	 * 传递对象参数，参数前要指定 @RequestBody ,实现部分也要指定
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/api/dto",method = RequestMethod.POST,consumes = "application/json")
	public Object testDto(@RequestBody TestParamDto dto);
	
	@RequestMapping(value="/api/dto2",method = RequestMethod.POST,consumes = "application/json")
	public Object testDto2(@RequestBody TestParamDto dto,@RequestParam("dto2") TestParamDto dto2);
	
	@RequestMapping(value = "/api/list",method = RequestMethod.POST,consumes = "application/json")
	public Object testList(@RequestBody List<TestParamDto> dtoList);
	
	@RequestMapping(value="/api/map",method = RequestMethod.POST, consumes = "application/json")
	public Object testMap(@RequestBody Map<String,Object> params);
}
