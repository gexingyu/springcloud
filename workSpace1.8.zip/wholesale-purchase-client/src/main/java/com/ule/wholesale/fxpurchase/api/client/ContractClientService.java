package com.ule.wholesale.fxpurchase.api.client;

import java.util.Date;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXContractInfoDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface ContractClientService {
	
	@RequestMapping(value="/api/contract/getPageByParams", method=RequestMethod.POST, consumes = "application/json")
	public ResultDTO<Map<String,Object>> getPageByParams(@RequestBody Map<String, Object> params, @RequestParam("pageNum")Integer pageNum, @RequestParam("pageSize")Integer pageSize, @RequestParam("orderBy")String orderBy);
	
	@RequestMapping(value="/api/contract/compareContractAvailable")
	public boolean compareContractAvailable(@RequestParam("supplierId") Long supplierId, @RequestParam("contractId") Long contractId, @RequestParam("availableBegin") Date availableBegin, @RequestParam("availableEnd") Date availableEnd);
	
	@RequestMapping(value="/api/contract/addContract", method=RequestMethod.POST)
	public Long addContract(@RequestBody FXContractInfoDto fxContractInfo);
	
	@RequestMapping(value="/api/contract/createContractCode")
	public void createContractCode(@RequestParam("contractId") Long contractId);
	
	@RequestMapping(value="/api/contract/selectDtoByPrimaryKey")
	public FXContractInfoDto selectDtoByPrimaryKey(@RequestParam("contractId") Long contractId);
	
	@RequestMapping(value="/api/contract/delContract", method=RequestMethod.POST)
	public void delContract(@RequestBody FXContractInfoDto fxContractInfo);
	
	@RequestMapping(value="/api/contract/editContract", method=RequestMethod.POST)
	public void editContract(@RequestBody FXContractInfoDto fxContractInfo);
	
	@RequestMapping(value="/api/contract/submitContract", method=RequestMethod.POST)
	public void submitContract(@RequestBody FXContractInfoDto fxContractInfo);
	
}
