package com.ule.wholesale.fxpurchase.api.client;

import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXReturnOrderDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface ReturnOrderClientService {
		@RequestMapping(value="/api/returnOrder/findReturnOrderList",method=RequestMethod.POST)
		public ResultDTO<PageInfo<FXReturnOrderDto>> findReturnOrderList(@RequestBody Map<String,Object> params,@RequestParam("pageNum") Integer pageNum,@RequestParam("pageSize") Integer pageSize);
		@RequestMapping("/api/returnOrder/{orderId}/detail")
		public ResultDTO<Map<String,Object>> orderDetail(@PathVariable("orderId")Long orderId);
		@RequestMapping(value="/api/returnOrder/{orderId}/orderinfo")
		public ResultDTO<FXReturnOrderDto> fingdOrderByOrderId(@PathVariable("orderId")Long orderId);
		@RequestMapping(value = "/api/returnOrder/save",method={RequestMethod.POST})
		public ResultDTO<Object> saveOrder(@RequestBody Map<String,Object> params);
		@RequestMapping(value="/api/returnOrder/updateOrderState",method=RequestMethod.POST)
		public ResultDTO<Object> updateOrderState(@RequestBody Map<String,Object> params);
		@RequestMapping(value = "/api/returnOrder/{orderId}/delete")
		public ResultDTO<Object> deleteOrder(@PathVariable("orderId") Long orderId,@RequestParam("userName")String userName,@RequestParam("userId")Long userId);
		
}
