package com.ule.wholesale.fxpurchase.api.client;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXSupplierInfoDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface SupplierInfoClientService {
	
	@RequestMapping(value = "/api/supplier/getSupplierListByPage",method=RequestMethod.POST,consumes = "application/json")
	public ResultDTO<Map<String,Object>> getSupplierListByPage(@RequestBody FXSupplierInfoDto fxSupplierInfo,@RequestParam("pageNum")Integer pageNum,@RequestParam("pageSize")Integer pageSize,@RequestParam("orderBy")String orderBy);
	
	@RequestMapping(value = "/api/supplier/getSupplierList",method=RequestMethod.POST,consumes = "application/json")
	public ResultDTO<List<FXSupplierInfoDto>> getSupplierList(@RequestBody FXSupplierInfoDto fxSupplierInfo);
	
	@RequestMapping(value = "/api/supplier/{id}/detail")
	 public ResultDTO<FXSupplierInfoDto> getSupplierDetail(@PathVariable("id")Long id);
	
	@RequestMapping(value = "/api/supplier/create",method=RequestMethod.POST,consumes = "application/json")
	 public ResultDTO<Integer> saveFXSupplierInfo(@RequestBody Map<String,Object> supplierInfo);
	
	@RequestMapping(value = "/api/supplier/update",method=RequestMethod.POST,consumes = "application/json")
	 public ResultDTO<Integer> updateFXSupplierInfo(@RequestBody Map<String,Object> supplierInfos);

	@RequestMapping(value = "/api/supplier/{id}/delete")
	 public ResultDTO<Integer> deleteupdateFXSupplierInfo(@PathVariable("id")Long id);
	
	@RequestMapping(value = "/api/supplier/getSupplierInfoByItemId",method=RequestMethod.POST)
	public List<FXSupplierInfoDto> getSupplierInfoByItemId(@RequestBody List<Long> itemIdList);
	
}
