package com.ule.wholesale.fxpurchase.api.client;

import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleReturnOrderDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface WholesaleReturnOrderClientController {
	
	@RequestMapping("/api/wholesaleReturnOrder/fingdOrder/{orderId}")
	public ResultDTO<FXWholesaleReturnOrderDto> fingdOrderByOrderId(@PathVariable("orderId") Long orderId);
	
	@RequestMapping(value="/api/wholesaleReturnOrder/saveOrderInfo",method=RequestMethod.POST)
	public ResultDTO<Object> saveOrderInfo(@RequestBody Map<String,Object> params);
	
	@RequestMapping(value = "/api/wholesaleReturnOrder/getList",method=RequestMethod.POST,consumes = "application/json")
	public ResultDTO<Map<String,Object>> getList(@RequestBody Map<String, Object> params,@RequestParam("pageNum")Integer pageNum,@RequestParam("pageSize")Integer pageSize,@RequestParam("orderBy")String orderBy);

	@RequestMapping("/api/wholesaleReturnOrder/fingdDetail/{orderId}")
	public ResultDTO<Map<String,Object>> fingdReturnOrderDetailByOrderId(@PathVariable("orderId")Long orderId);
	
	@RequestMapping(value="/api/wholesaleReturnOrder/submit",method=RequestMethod.POST)
	public ResultDTO<Object> updateOrderState(@RequestBody Map<String,Object> params);
	
	@RequestMapping("/api/wholesaleReturnOrder/{orderId}/delete")
	public ResultDTO<Object> deleteOrder(@PathVariable("orderId") Long orderId,@RequestParam("username")String username,@RequestParam("userId")Long userId);
	
}
