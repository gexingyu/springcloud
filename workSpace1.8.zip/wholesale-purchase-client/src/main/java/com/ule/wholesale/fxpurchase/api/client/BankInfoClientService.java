package com.ule.wholesale.fxpurchase.api.client;

import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface BankInfoClientService {

	@RequestMapping("/api/bank/findBankInfoList")
	public ResultDTO<Map<Object, Object>> findBankInfoList();
}
