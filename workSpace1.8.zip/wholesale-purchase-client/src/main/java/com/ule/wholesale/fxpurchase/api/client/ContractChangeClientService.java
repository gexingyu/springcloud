package com.ule.wholesale.fxpurchase.api.client;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXContractChangeDto;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemChangeDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface ContractChangeClientService {
	
	@RequestMapping(value="/api/contractChange/getPageByParams", method=RequestMethod.POST, consumes = "application/json")
	public ResultDTO<Map<String,Object>> getPageByParams(@RequestBody Map<String, Object> params, @RequestParam("pageNum")Integer pageNum, @RequestParam("pageSize")Integer pageSize, @RequestParam("orderBy")String orderBy);
	
	@RequestMapping(value="/api/contractChange/selectByPrimaryKey")
	public FXContractChangeDto selectByPrimaryKey(@RequestParam("changePaperId")Long changePaperId);
	
	@RequestMapping(value="/api/contractChange/selectByChangePaperId")
	public List<FXContractItemChangeDto> selectByChangePaperId(@RequestParam("changePaperId")Long changePaperId);
	
	@RequestMapping(value="/api/contractChange/selectDtoByPrimaryKey")
	public FXContractChangeDto selectDtoByPrimaryKey(@RequestParam("changePaperId")Long changePaperId);
	
	@RequestMapping(value="/api/contractChange/delFXContractChange")
	public boolean delFXContractChange(@RequestParam("changePaperId")Long changePaperId);
	
	@RequestMapping(value="/api/contractChange/delContractChange", method=RequestMethod.POST)
	public boolean delContractChange(@RequestBody FXContractChangeDto fxContractChangeInfo);
	
	@RequestMapping(value="/api/contractChange/updateContractChange", method=RequestMethod.POST)
	public boolean updateContractChange(@RequestBody FXContractChangeDto fxContractChangeInfo);
	
	@RequestMapping(value="/api/contractChange/compareContractAvailable")
	public boolean compareContractAvailable(@RequestParam("contractId") Long contractId,@RequestParam("contractChangeId") Long contractChangeId,@RequestParam("availableBegin") Date availableBegin,@RequestParam("availableEnd") Date availableEnd);
	
	@RequestMapping(value="/api/contractChange/changeFXContractInfo", method=RequestMethod.POST)
	public boolean changeFXContractInfo(@RequestBody FXContractChangeDto fxContractChangeInfo);
	
	@RequestMapping(value="/api/contractChange/createChangePaperCode")
	public boolean createChangePaperCode(@RequestParam("changePaperId")Long changePaperId);
	
	@RequestMapping(value="/api/contractChange/saveItemPriceChange", method=RequestMethod.POST)
	public Long saveItemPriceChange(@RequestBody Map<String,Object> paramsMap);
	
	@RequestMapping(value="/api/contractChange/editItemPriceChange", method=RequestMethod.POST)
	public boolean editItemPriceChange(@RequestBody Map<String,Object> paramsMap, @RequestParam("userId")Long userId, @RequestParam("userName")String userName);
	
	@RequestMapping(value="/api/contractChange/contractChangeCheck", method=RequestMethod.POST)
	public boolean contractChangeCheck(@RequestBody Map<String,Object> paramsMap, @RequestParam("userId")Long userId, @RequestParam("userName")String userName);
	
	@RequestMapping(value="/api/contractChange/contractItemStopCheck", method=RequestMethod.POST)
	public boolean contractItemStopCheck(@RequestBody Map<String,Object> paramsMap, @RequestParam("userId")Long userId, @RequestParam("userName")String userName);
	
}
