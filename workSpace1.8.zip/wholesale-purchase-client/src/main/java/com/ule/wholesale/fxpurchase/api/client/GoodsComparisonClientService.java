package com.ule.wholesale.fxpurchase.api.client;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.FXGoodsCompareListDto;

@FeignClient(value=ClientConstants.SERVICE_NAME,path=ClientConstants.SERVER_PATH)
public interface GoodsComparisonClientService {
	
	@RequestMapping(value = "/api/goods/{id}/detail")
	public ResultDTO<FXGoodsCompareListDto> selectfxGoodsComparisonById(@RequestParam("id")Long id);
	
	@RequestMapping(value = "/api/goods/{id}/delete")
	public ResultDTO<Integer> deleteFXGoodsComparison(@RequestParam("id")Long id);
	
	@RequestMapping(value = "/api/goods/save", method=RequestMethod.POST)
	public ResultDTO<Integer> saveFXGoodsCompareList(@RequestBody FXGoodsCompareListDto fxGoodsCompareListDto);
	
	@RequestMapping(value = "/api/goods/edit", method=RequestMethod.POST)
	public ResultDTO<Integer> updateFXGoodsComparison(@RequestBody FXGoodsCompareListDto fxGoodsCompareListDto);
	
	@RequestMapping(value = "/api/goods/list", method=RequestMethod.POST)
	public ResultDTO<Map<String, Object>> getGoodsCompareListByPage(@RequestBody FXGoodsCompareListDto fxGoodsCompareListDto,
			@RequestParam("pageNum")Integer pageNum,@RequestParam("pageSize")Integer pageSize);
	
	@RequestMapping(value = "/api/goods/getAgency")
	public ResultDTO<Map<String, Object>> getAgency(@RequestParam("signCode")Long signCode,@RequestParam("level")Long level);
	
	@RequestMapping(value="/api/goods/findItemList",method=RequestMethod.POST)
	public ResultDTO<PageInfo<FXGoodsCompareListDto>> findItemList(@RequestBody FXGoodsCompareListDto fxGoodsCompareListDto,@RequestParam("pageNum")Integer pageNum,@RequestParam("pageSize")Integer pageSize);
	
	@RequestMapping(value ="/api/goods/getFXGoodsCompareListByParam", method=RequestMethod.POST)
	public ResultDTO<List<FXGoodsCompareListDto>> getFXGoodsCompareListByParam(@RequestBody FXGoodsCompareListDto fxGoodsCompareListDto);
}
