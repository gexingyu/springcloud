var zQuery = function (){
	var msg = '';
	var vcity={ 11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古", 
		    21:"辽宁",22:"吉林",23:"黑龙江",31:"上海",32:"江苏", 
		    33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南", 
		    42:"湖北",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆", 
		    51:"四川",52:"贵州",53:"云南",54:"西藏",61:"陕西",62:"甘肃", 
		    63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外"
		   };
	//验证是否包含中文字符
	this.isContainChinese = function(txt){
		if(/[\u4E00-\u9FA5]/g.test($("#hospitalId").val())){
    	    return true;
		}
		return false;
	};
	//验证是否我邮箱地址
	this.isEmail = function(email){
		if(/^\w+([-+\.]?\w+)*@([\w]{2,})+([-\.]\w+)*\.[\w]{2,}([-\.]\w+)*$/.test(email)){
			return true;
		}
		return false;
	};
	//验证是否为网址
	this.isInternetURL = function(url){
		// /^(http(s)?:\/\/)?(www\.)?[\w-]+\.\w{2,4}(\/)?$/
		if(/^(http(s)?:\/\/)?(www\.)?([\w-]+(([\w]+)+\.)*)+[\w]+([\:][\d]{2,4})?(\/)?((\/)?[\w-\.]?[\w]+(\/)?)*(\.[\w]{2,5})?([?]([\w%][=][\w%][&]?)*)?$/.test(url)){
			return true;
		}
		return false;
	};
	//验证是否为手机号码
	this.isPhoneNo = function(phoneNo){
		if(/^((1(3|4|5|7|8)[0-9]))\d{8}$/.test(phoneNo)){
			return true;
		}else{
			return false;
		}
	};
	//验证电话号码
	this.isTelNo = function(tel){
		if(/^(\(\d{3,4}\)|\d{3,4}-)?\d{7,8}$/.test(tel)){
			return true;
		}
		return false;
	};
	//验证是否是数字
	this.isNumber = function(num){
		if(/^[\-]?([0-9]|[1-9][0-9]*)(\.[\d]+)$/.test(num)){
			return true;
		}
		return false;
	};
	//验证是否是年龄1-159
	this.isAge = function(num){
		if(/^[1-9][0-5][\d]$/.test(num)){
			return true;
		}
		this.msg = '年龄必须在[1-159]之间';
		return false;
	};
	//格式化小数位
	this.formatFloat = function(data,count){
		if(/^[1-9]+([\d]+)?(\.)?([\d]+)?$/.test(data)){
			return Number(data).toFixed(count);
		}
		return data;
	};
	//格式化日期
	this.formatDate = function(date,fmt){
		date = this.getDate(date);
		var o = {
		        "M+": date.getMonth() + 1, //月份 
		        "d+": date.getDate(), //日 
		        "h+": date.getHours(), //小时 
		        "m+": date.getMinutes(), //分 
		        "s+": date.getSeconds(), //秒 
		        "q+": Math.floor((date.getMonth() + 3) / 3), //季度 
		        "S": date.getMilliseconds() //毫秒 
		    };
		    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
		    for (var k in o)
		    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		    return fmt;
	};
	//日期字符串转成日期
	this.getDate = function(d){
		if(typeof (d) != 'object'){
			d=d.replace('-','/');
			d=d.replace('-','/');
			d=d.replace('年','/');
			d=d.replace('月','/');
			d=d.replace('日','/');
			if(d.indexOf("/") == -1){
				d = d.substring(0,4)+"/"+d.substring(4,6)+"/"+d.substring(6,8);
			}
		}
		var theDate = new Date(d);
		var year = theDate.getYear()+1900;
		var month = theDate.getMonth() + 1;
		var dday = theDate.getDate();
		theDate = new Date(year+"/"+month+"/"+dday);
		return  theDate; 
	};
	//日期字符串转成日期
	this.getDateTime = function(dateTimeStr){
		if(typeof d != 'object'){
			d=d.replace('-','/');
			d=d.replace('-','/');
			d=d.replace('年','/');
			d=d.replace('月','/');
			d=d.replace('日','/');
			if(d.indexOf("/") == -1){
				d = d.substring(0,4)+"/"+d.substring(4,6)+"/"+d.substring(6,8);
			}
		}
		var theDate = new Date(d);
		var year = theDate.getYear()+1900;
		var month = theDate.getMonth() + 1;
		var dday = theDate.getDate();
		theDate = new Date(year+"/"+month+"/"+dday+" "+theDate.getHours()+":"+theDate.getMinutes()+":"+theDate.getSeconds());
		return  theDate; 
	};
	//获取日期是一周的第几天
	this.getDayOfWeek = function(d){
		d = this.getDate(d);;
		return d.getDay()>0?d.getDay():7;   
	};
	//获取日期是一周的周几名称
	this.getDayOfWeekName = function(d){
		d = this.getDate(d);;
		var data = ["周日","周一","周二","周三","周四","周五","周六"];
		return data[d.getDay()];   
	};
	//获取日期所在年份的第几天
	//获取日期是所在的周次
	this.getDayOfYear = function(date){
		var d = this.getDate(date);
	    var dayofyear = 0;
	    for (var i = 0; i < d.getMonth(); i++) {
	        switch (i) {
	            case 0:
	            case 2:
	            case 4:
	            case 6:
	            case 7:
	            case 9:
	            case 11:
	                dayofyear += 31;
	                break;
	            case 1:
	                if (this.isLeapYear(d)) {
	                    dayofyear += 29; 
	                }
	                else {
	                    dayofyear += 28; 
	                }
	                break;
	            case 3:
	            case 5:
	            case 8:
	            case 10:
	                dayofyear += 30;
	                break;
	        }
	    }
	    dayofyear += d.getDate();
	    return dayofyear;
	};
	//获取日期是所在的周次
	this.getWeekOfYear = function(date){
		var d = this.getDate(date);
	    var year = d.getFullYear(); 
	    var firstDate = new Date(year + "-01-01");
	    var dayofyear = this.getDayOfYear(date);
	    var week = firstDate.getDay();
	    var dayNum = dayofyear - (8 - week); 
	    var weekNum = 1;
	    weekNum = weekNum + (dayNum / 7);
	    if (dayNum % 7 != 0)
	        weekNum = weekNum + 1;
	    return parseInt(weekNum);
	};
	//判断日期所在年份是否为闰年，默认我当前时间
	this.isLeapYear = function(date){
		if(typeof(date)=='undefined' || date == ''){
			date = new Date();
		}
		date = this.getDate(date);
		return (0 == date.getFullYear() % 4 && ((date.getFullYear() % 100 != 0) || (date.getFullYear() % 400 == 0)));
	};
	//获取日期是所在周的开始和结束时间
	this.getDateWeekStarAndEnd = function(date){
		var d = this.getDate(date);
		var currentDay=d.getDay();
		if(currentDay==0){currentDay=7;}
		var mondayTime=d.getTime()-(currentDay-1)*24*60*60*1000;
		var sundayTime=d.getTime()+(7-currentDay)*24*60*60*1000;
		var mondayDate = new Date(mondayTime).toLocaleDateString();
		var sundayDate = new Date(sundayTime).toLocaleDateString();
		var arr = new Array();
		arr[0] = mondayDate;
		arr[1] = sundayDate;
	    return arr;
	};
	//获取指定周次的开始和结束时间
	this.getWeekStarAndEndDate = function(weekNum){
		var d = new Date();
		//1.获取当前时间所在周次
		var weekth = this.getWeekOfYear(d);
		//2、获取当前时间在本周的周几
		var day = this.getDayOfWeek(d)-1;
		//3.计算出相差的天数
		var intervals = (weekth - weekNum)*7*24*60*60*1000;
		//4.获取指定周次的当天的时间-去当天所在周几的偏差时间=指定周次的周一的日期
		var ltime = d.getTime();
		var d2 = new Date(ltime - intervals - day*24*60*60*1000);
		var arr = new Array();
		debugger;
		arr[0] = d2.toLocaleDateString();
		arr[1] = new Date(d2.getTime() + 6*24*60*60*1000).toLocaleDateString();
	    return arr;
	};
	//只允许输入数字和英文
	this.limit4En = function(obj){
		obj.val(obj.val().replace(/[^\w'\.,;]/g,''));
	};
	//只允许输入中文
	this.limit4Cn = function(obj){
		obj.val(obj.val().replace(/[^\u4E00-\u9FA5]/g,''));
	};
	//只允许输入数字
	this.limit4Num = function(obj){
		//先把非数字的都替换掉，除了数字和.
		obj.val(obj.val().replace(/[^\d]/g,''));
		//必须保证第一个为数字而不是.和0
		obj.val(obj.val().replace(/^\.|^0/g,''));
		//保证只有出现一个.而没有多个.
		//obj.val(obj.val().replace(/\.{2,}/g,''));
		//保证.只出现一次，而不能出现两次以上
		//obj.val(obj.val().replace(".", "$#$").replace(/\./g, "").replace("$#$", "."));
		//保证.只后面只能出现两位有效数字 $1 表示 /([0-9]+\.[0-9]{2})[0-9]*/ 匹配到的内容
		obj.val(obj.val().replace(/([0-9]{1,5})[0-9]*/, "$1"));
	};
	//只允许输入金额类型数字
	this.limit4Amt = function(obj){
		//先把非数字的都替换掉，除了数字和.
		obj.val(obj.val().replace(/[^\d.]/g,''));
		//必须保证第一个为数字而不是.和0
		obj.val(obj.val().replace(/^\.|^0/g,''));
		//保证只有出现一个.而没有多个.
		//obj.val(obj.val().replace(/\.{2,}/g,''));
		//保证.只出现一次，而不能出现两次以上
		obj.val(obj.val().replace(".", "$#$").replace(/\./g, "").replace("$#$", "."));
		//保证.只后面只能出现两位有效数字 $1 表示 /([0-9]+\.[0-9]{2})[0-9]*/ 匹配到的内容
		obj.val(obj.val().replace(/([0-9]+\.[0-9]{2})[0-9]*/, "$1"));
	};
	//专门验证百分比，规则是不能超过100%且有小数时精确到小数点后两位，例子99.99
	this.limit4Rate = function(obj){
		//先把非数字的都替换掉，除了数字和.
		obj.val(obj.val().replace(/[^\d.]/g,''));
		//必须保证第一个为数字而不是.和0
		obj.val(obj.val().replace(/^\.|^0/g,''));
		//保证只有出现一个.而没有多个.
		//obj.val(obj.val().replace(/\.{2,}/g,''));
		//保证.只出现一次，而不能出现两次以上
		obj.val(obj.val().replace(".", "$#$").replace(/\./g, "").replace("$#$", "."));
		//保证整数部分只有两位
		obj.val(obj.val().replace(/([0-9]{1,2})[0-9]*/,"$1"));
		//保证.只后面只能出现两位有效数字 $1 表示 /([0-9]+\.[0-9]{2})[0-9]*/ 匹配到的内容
		obj.val(obj.val().replace(/([0-9]{1,2}\.[0-9]{1,2})[0-9]*/, "$1"));
	};
	//验证身份证号码
	this.isIdCardNo = function(cardNo){
		var len = cardNo.length; 
		//检查省份是否正确
		if(this.checkProvince(cardNo)){
			//身份证15位时，次序为省（3位）市（3位）年（2位）月（2位）日（2位）校验位（3位），皆为数字 
			if(len == '15'){ 
			   var re_fifteen = /^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/; 
			   var arr_data = obj.match(re_fifteen); 
			   var year = arr_data[2]; 
			   var month = arr_data[3]; 
			   var day = arr_data[4]; 
			   var birthday = new Date('19'+year+'/'+month+'/'+day); 
			   return verifyBirthday('19'+year,month,day,birthday); 
			} 
			//身份证18位时，次序为省（3位）市（3位）年（4位）月（2位）日（2位）校验位（4位），校验位末尾可能为X 
			if(len == '18'){ 
			   var re_eighteen = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/; 
			   var arr_data = cardNo.match(re_eighteen); 
			   var year = arr_data[2]; 
			   var month = arr_data[3]; 
			   var day = arr_data[4]; 
			   var birthday = new Date(year+'/'+month+'/'+day); 
			   return this.verifyBirthday(year,month,day,birthday); 
			} 
		}
		return false; 
	};
	//校验日期,年龄小于130岁
	this.verifyBirthday = function(year,month,day,birthday) 
	 { 
		  var now = new Date(); 
		  var now_year = now.getFullYear(); 
		  //年月日是否合理 
		  if(birthday.getFullYear() == year && (birthday.getMonth() + 1) == month && birthday.getDate() == day) 
		  { 
		   //判断年份的范围（3岁到100岁之间) 
		   var time = now_year - year; 
		   if(time >= 1 && time <= 130) 
		   { 
		    return true; 
		   }
		   this.msg = '年龄必须在[1-130]之间';
		   return false; 
		  } 
		  this.msg = '年月日不正确 ';
		  return false; 
	}; 
	//取身份证前两位,校验省份 
	 this.checkProvince = function(obj) 
	 { 
	  var province = obj.substr(0,2); 
	  if(vcity[province] == undefined){ 
		  this.msg = '身份证前两位[省份]校验不通过';
		  return false;
	  } 
	  return true; 
	 };
	//验证是否含有特殊字符
	this.isContainSpecialChar = function(txt){
		if( /<|>|'|;|frame|iframe|=|select|from|@|!|:|%|http|&|,|，|and|or|#|"|'|alert/g.test(txt)){
        	return true;
		}else{
			return false;
		}
	};
	//去除空和换行符
	this.replaceBlank = function(txt){
		txt = txt.replace(/(^\s*)|(\s*$)/g, "");
		return txt;
	};
	this.isBlank = function(txt){
		txt = txt.replace(/(^\s*)|(\s*$)/g, "");
		if(txt == ''){
			return true;
		}
		return false;
	};
	//替换掉特殊符号
	this.replaceSpecChar = function(txt){
		txt = txt.replace(/<|>|'|;|frame|iframe|=|select|from|@|!|:|%|http|&|,|，|and|or|#|"|'|alert/g, "");
		return txt;
	};
	//验证字符长度是否在指定返回直接
	this.checkLen = function(str,len){
		if(str.length <= len){
			return true;
		}
		return false;
	};
};


function zLoading(basePath,loadId){
	this.basePath = basePath;
	this.loadDiv = loadId;
	this.bodyHtml = '<div id="overLoad" style="display: none;margin: 0px; padding: 0px; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; z-index: 99999;background-color: #f5f5f5;opacity:0;" class="over"></div><div id="layoutLoad" style="display: none;position: absolute;top: 40%;left: 40%;width: 20%;height: 20%;z-index: 999991;text-align:center;" class="layout"><img src="'+basePath+'/images/loading.gif" /></div>';
	this.showLoading = function(){
		if(this.loadDiv == '')
			this.loadDiv = 'loadingDiv';
		if(typeof($("#"+this.loadDiv)) == 'undefined')
			$("body").append('<div id="'+this.loadDiv+'"></div>');
		$("#"+this.loadDiv).html("");
		$("#"+this.loadDiv).html(this.bodyHtml);
			
		$("#overLoad").css("display","block");
		$("#layoutLoad").css("display","block");
		this.autoClose();
	};
	this.showLoadingOffset = function(width,height,left,top){
		
		if(this.loadDiv == '')
			this.loadDiv = 'loadingDiv';
		if(typeof($("#"+this.loadDiv)) == 'undefined')
			$("body").append('<div id="'+this.loadDiv+'"></div>');
		$("#"+this.loadDiv).html("");
		$("#"+this.loadDiv).html(this.bodyHtml);
		if(typeof(width) == 'undefined' || width == -1 || width > $("#"+this.loadDiv).width())
			width = $("#"+this.loadDiv).width();
		if(typeof(height) == 'undefined' || height == -1 || height > $("#"+this.loadDiv).height())
			if($("#"+this.loadDiv).height() > 0)
				height = $("#"+this.loadDiv).height();
			else
				height = 120;
		if(typeof(left) == 'undefined'){
			 left =  ($("#"+this.loadDiv).width() - width)/2;
		}
		if(typeof(top) == 'undefined'){
			top = $("#"+this.loadDiv).height();
		}
		$("#overLoad").css({"width":width,"height":height,"left":left,"top":top});
		$("#layoutLoad").css({"width":width,"height":height,"left":left,"top":top});
		$("#layoutLoad img").css({"width":height/2,"margin-top":((height-height/2)/2)});
		$("#overLoad").css("display","block");
		$("#layoutLoad").css("display","block");
		this.autoClose();
	};
	this.cancelLoading = function(){
      	$("#overLoad").css("display","none");
		$("#layoutLoad").css("display","none");
	};
	//如果15秒后没有关闭，则自动关闭
	this.autoClose = function(){
		setTimeout(function(){
			load.cancelLoading();
		},10000);
	};
	// 获得浏览器类型
    this.getBrowserType = function() {  
       if(navigator.userAgent.indexOf("MSIE")>0) {  
            return "MSIE";  
       }  
       if(navigator.userAgent.indexOf("Firefox")>0){  
            return "Firefox";  
       }  
       if(navigator.userAgent.indexOf("Chrome")>0) {  
            return "Chrome";  
       }   
       if(navigator.userAgent.indexOf("Camino")>0){  
            return "Camino";  
       }  
       if(navigator.userAgent.indexOf("Gecko/")>0){  
            return "Gecko";  
       }  
    }
}

function zDialog(basePath){
	this.basePath = basePath;
	this.top=50;
	this.width=360;
	this.height=200;
	this.backHtml = '<div class="zoverlay"></div>';
	this.diagHtml = '<div class="zdialog">'+
	'<div class="zdialog-panel">'+
	'<a class="zicon-close" href="javascript:void(0);"></a>'+
	'<div class="ztitle"></div>'+
	'<div class="zcontent"></div>'+
	'<div class="zfooter"></div>'+
	//<iframe id="areaPage" width="100%" scrolling="no" height="100%" frameborder="0" src="addYjArea.action"></iframe>
	'</div></div>';
	this.tipOnMouse = function(msg,obj,left_offset,top_offset){
		var tipDiv = '<div class="speech-bubble speech-bubble-top" style="top: 194px; left: -244px; display: none;"></div>';
		obj.mouseover(function(e){
    		var top = $(this).position().top + 30;
    		var pointX = e.pageX;
    		$(".speech-bubble-top").text(msg);
    		$(".speech-bubble-top").css("top",top_offset);
    		$(".speech-bubble-top").css("left",left_offset);
    		$(".speech-bubble-top").css("display","block");
    	});
		obj.mouseout(function(){
    		$(".speech-bubble-top").css("display","none");
    	});
		
	},
	this.alert = function(msg,btn){
		$("#overlay-alert").remove();
		$("body").append('<div id="overlay-alert"></div>');
		$("#overlay-alert").html(this.backHtml+this.diagHtml);
		$("#overlay-alert .zcontent").html(msg);
		if(typeof btn == 'undefined' || btn == '')
			btn = '确定';
		$("#overlay-alert .zfooter").html('<button type="submit" class="btn btn-primary zdialog-sure">'+btn+'</button>');
		var fullwidth = $("#overlay-alert .zoverlay").width();
		var width = this.width;
		var height = 100;
		var divH = (window.screen.height - 100 - $("#overlay-alert .zdialog").height())/2;
		
		if(fullwidth < width)
			width = fullwidth-24;
		if(window.screen.height < (height + 50)){
			heigth = window.screen.height*0.8;
		}
		$("#overlay-alert .zdialog-panel").css({"width":width,"min-height":height,"height":"auto"});
		$("#overlay-alert .zdialog").css({"left":(fullwidth - width)/2,"margin-left":0,"top":divH,"margin-top":0});
		$("#overlay-alert .zicon-close").click(function(){
			$("#overlay-alert").remove();
		});
		$("#overlay-alert .zdialog-sure").click(function(){
			$("#overlay-alert").remove();
		});
		
	};
	this.confirm = function(msg,success,sureBtn,cancelBtn){
		$("#overlay-confirm").remove();
		$("body").append('<div id="overlay-confirm"></div>');
		$("#overlay-confirm").html(this.backHtml+this.diagHtml);
		$("#overlay-confirm .zcontent").html(msg);
		if(typeof(sureBtn) == 'undefined' || sureBtn == '')
			sureBtn = '确定';
		if(typeof(cancelBtn) == 'undefined' || cancelBtn == '')
			cancelBtn = '取消';
		$("#overlay-confirm .zfooter").html('<button type="submit" class="btn btn-primary zbtn-sure">'+sureBtn+'</button><button type="submit" class="btn zcancelBtn">'+cancelBtn+'</button>');
		var fullwidth = $("#overlay-confirm .zoverlay").width();
		var width = this.width;
		var height = 100;
		var divH = (window.screen.height - 100 - $("#overlay-confirm .zdialog").height())/2;
		if(fullwidth < width)
			width = fullwidth-24;
		if(window.screen.height < (height + 50)){
			heigth = window.screen.height*0.8;
		}
		$("#overlay-confirm .zdialog-panel").css({"width":width,"min-height":height,"height":"auto"});
		$("#overlay-confirm .zdialog").css({"left":(fullwidth - width)/2,"margin-left":0,"top":divH,"margin-top":0});
		$(".zicon-close").click(function(){
			$("#overlay-confirm").remove();
		});
		$("#overlay-confirm .zfooter .btn-primary").click(function(){
			debugger;
			$("#overlay-confirm").remove();
			if(typeof(success) == 'undefined' || sureBtn == ''){
				zDialog.alert("请编写确认的函数，并作为参数传递");
			}else{
				setTimeout(success,1);
			}
		});
		$(".zfooter .zcancelBtn").click(function(){
			$("#overlay-confirm").remove();
		});
	};
	this.alertClose = function(){
		$(".zicon-close").click(function(){
			$("#overlay-alert").remove();
		});
	},
	this.confirmClose = function(){
		$(".zicon-close").click(function(){
			$("#overlay-confirm").remove();
		});
	},
	this.dialogClose = function(){
		$(".zicon-close").click(function(){
			$("#overlay-dialog").remove();
		});
	},
	this.dialog = function(setting,success,sureBtn,cancelBtn,width,height){
		$("#overlay-dialog").remove();
		$("body").append('<div id="overlay-dialog"></div>');
		$("#overlay-dialog").html(this.backHtml+this.diagHtml);
		$("#overlay-dialog .zcontent").addClass("zcontent-dialog").removeClass("zcontent");
		$("#overlay-dialog .zcontent-dialog").html(setting);
		if(typeof(sureBtn) == 'undefined' || sureBtn == '')
			sureBtn = '确定';
		if(typeof(cancelBtn) == 'undefined' || cancelBtn == '')
			cancelBtn = '取消';
		var fullwidth = $("#overlay-dialog .zoverlay").width();
		if(typeof(height) == 'undeifined' || height == '' || height <= 0){
			height = 500;
		}
		if(typeof(width) == 'undeifined' || width == '' || width <= 0){
			width = 500;
		}
		if(fullwidth < width)
			width = fullwidth-24;
		if(window.screen.height < (height + 50)){
			heigth = window.screen.height*0.8;
		}
		var pannelHeight = height;
		var diaglogW = width;
		if(height > 580){
			pannelHeight = 580;
			diaglogW = width -17;
		}
		$("#overlay-dialog .zdialog-panel").css({"width":width,"height":pannelHeight,});
		if(height > 580){
			$("#overlay-dialog .zdialog-panel .zcontent-dialog").css({"width":diaglogW,"height":pannelHeight-75,"overflow":"auto","margin-bottom":0});
		}else{
			$("#overlay-dialog .zdialog-panel .zcontent-dialog").css({"width":diaglogW,"height":pannelHeight-85,"overflow":"auto"});
		}
		var divH = 10;
		$("#overlay-dialog .zdialog").css({"left":(fullwidth - width)/2,"margin-left":0,"top":divH,"margin-top":0});
		$("#overlay-dialog .zfooter").html('<button type="submit" class="btn btn-primary zbtn-sure">'+sureBtn+'</button><button type="submit" class="btn zcancelBtn">'+cancelBtn+'</button>');
		$(".zicon-close").click(function(){
			$("#overlay-dialog").remove();
		});
		$("#overlay-confirm .zfooter .btn-primary").click(function(){
			if(typeof(success) == 'undefined' || sureBtn == ''){
				zDialog.alert("请编写确认的函数，并作为参数传递");
			}else
				setTimeout(success,1);
		});
		$(".zfooter .zcancelBtn").click(function(){
			$("#overlay-dialog").remove();
		});
	};
}

var zUploadImg = function(){
	this.showFileUpload = function(src,img){
		var MAXWIDTH  = 150; 
	    var MAXHEIGHT = 150;
	    if(window.FileReader) {
		    var file = src.files[0];
			    if(!/\.(gif|jpg|jpeg|png|GIF|JPG|PNG)$/.test(file.name)){
			    	//showMsg("图片类型必须是.gif,jpeg,jpg,png中的一种");
			    	zDialog.alert("图片类型必须是.gif,jpeg,jpg,png中的一种");
			    	return false;
			    }
			    if(!/image\/\w+/.test(file.type)){
			    	zDialog.alert("请选择一张图片文件");
			    	return false;
			    }
			    $('#'+img).hide();
			    $("#hospitalImage").val(file.name);
			    var reader = new FileReader();
			    reader.readAsDataURL(file);
			    reader.onloadstart = function(e){
			    	//NProgress.start();
			    };
			    reader.onprogress = function(e){
			    	//NProgress.start();
			    };
			    reader.onloadend = function(e){
			    	//NProgress.done();
			    };
			    reader.onabort = function(e){
			    	zDialog.alert("上传被意外中断，请重试");
			    	NProgress.done();
			    	return false;
			    };
			    reader.onerror = function(e){
			    	zDialog.alert("上传出现错误，请重试");
			    	NProgress.done();
			    	return false;
			    };
			    reader.onload = function(e){
			    	$('#'+img).attr('src',e.target.result);
			    	$('#'+img).fadeIn(200);
			    	//NProgress.done();
			    };
	    } else {
	    	var div = document.getElementById('preview');
	        if (src.files && src.files[0])
	        {
	      	  if(!/\.(gif|jpg|jpeg|png|GIF|JPG|PNG)$/.test(file.files[0].name)){
	      		zDialog.alert("图片类型必须是.gif,jpeg,jpg,png中的一种");
	  		    	return false;
	  		    }
	      	  $("#hospitalImage").val(src.files[0].name);
	            div.innerHTML ='<img id=imghead>';
	            var img = document.getElementById('imghead');
	            img.onload = function(){
	              var rect = clacImgZoomParam(MAXWIDTH, MAXHEIGHT, img.offsetWidth, img.offsetHeight);
	              img.width  =  rect.width;
	              img.height =  rect.height;
//	               img.style.marginLeft = rect.left+'px';
	              img.style.marginTop = rect.top+'px';
	            }
	            var reader = new FileReader();
	            reader.onload = function(evt){img.src = evt.target.result;}
	            reader.readAsDataURL(src.files[0]);
	        } else{ //兼容IE
	          var sFilter='filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src="';
	          src.select();
	          var src = document.selection.createRange().text;
	  	    if(!/\.(gif|jpg|jpeg|png|GIF|JPG|PNG)$/.test(src)){
	  	    	zDialog.alert("图片类型必须是.gif,jpeg,jpg,png中的一种");
	  	    	return false;
	  	    }
	  	    $("#hospitalImage").val(src);
	          div.innerHTML = '<img id=imghead>';
	          var img = document.getElementById('imghead');
	          img.filters.item('DXImageTransform.Microsoft.AlphaImageLoader').src = src;
	          div.innerHTML = "<div id=divhead style='width:"+MAXWIDTH+"px;height:"+MAXHEIGHT+"px;"+sFilter+src+"\"'></div>";
	        }
	    }
	}
}
var zUploadFile = function(){
	this.showFileUpload = function(src,title){
		debugger;
	    if(window.FileReader) {
		    var file = src.files[0];
			    $('#'+title).val(file.name);
			    var reader = new FileReader();
			    reader.readAsDataURL(file);
			    reader.onloadstart = function(e){
			    	//NProgress.start();
			    };
			    reader.onprogress = function(e){
			    	//NProgress.start();
			    };
			    reader.onloadend = function(e){
			    	//NProgress.done();
			    };
			    reader.onabort = function(e){
			    	zDialog.alert("上传被意外中断，请重试");
			    	NProgress.done();
			    	return false;
			    };
			    reader.onerror = function(e){
			    	zDialog.alert("上传出现错误，请重试");
			    	NProgress.done();
			    	return false;
			    };
			    reader.onload = function(e){
			    	//NProgress.done();
			    };
	    } else {
	        if (src.files && src.files[0])
	        {
	        	$('#'+title).val(src.files[0].name);
	            var reader = new FileReader();
	            reader.onload = function(evt){img.src = evt.target.result;}
	            reader.readAsDataURL(src.files[0]);
	        } else{ //兼容IE
	          var sFilter='filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src="';
	          src.select();
	          var src = document.selection.createRange().text;
	          if(typeof(src) != 'undefined' && src != ''){
	        	  var i = src.lastIndexOf("\\");
	        	  var n = 2;
	        	  if(i < 0){
	        		  i = src.lastIndexOf("/");
	        		  n = 1;
	        	  }
	        	  src = src.substring(i+n);
	        	  $('#'+title).val(src);
	          }
	        }
	    }
	}
}
function success(){alert(1);};

window.onload=function(){//zload.showLoadingOffset(-1,-1,0,80);
	//zload.showLoading();
	//zDialog.tipOnMouse('欢迎使用我的弹出框');
	//zDialog.alert('欢迎使用我的弹出框');
	//zDialog.confirm('欢迎使用我的弹出框',success);
	//zDialog.dialog('sdfssdf','','',800,1000);
}
var zQuery = new zQuery();
var zload = new zLoading(".",'');
var zDialog = new zDialog(".");
var zUploadImg = new zUploadImg();
var zUploadFile = new zUploadFile();