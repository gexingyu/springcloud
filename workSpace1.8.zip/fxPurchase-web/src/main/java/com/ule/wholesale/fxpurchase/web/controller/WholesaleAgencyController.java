package com.ule.wholesale.fxpurchase.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.WholesaleAgencyClientService;
import com.ule.wholesale.fxpurchase.api.dto.FXOPcDmsOrgRelationDto;
import com.ule.wholesale.fxpurchase.api.dto.FXOPcDmsOrgRelationParam;
import com.ule.wholesale.fxpurchase.web.service.CommonService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

/**
 * 批发机构
 * */
@Controller
@RequestMapping(value = "/agency")
public class WholesaleAgencyController {
	
	private static Log logger = LogFactory.getLog(WholesaleAgencyController.class);  
	
	@Autowired
	private WholesaleAgencyClientService wholesaleAgencyClientService;
	@Autowired
	private CommonService commonService;
	
	
@RequestMapping(value = "/add")	
public String toAddAgency(HttpServletRequest request){
	try {
		commonService.showAgencyButton(request);
	} catch (Exception e) {
		e.printStackTrace();
	}
	return "/agency/addAgency";
}

@RequestMapping(value = "/{id}/edit")	
public String toEditAgency(HttpServletRequest request,@PathVariable("id") Long id){
	FXOPcDmsOrgRelationDto fxoPcDmsOrgRelationDto = null;
	if(id != null){
		fxoPcDmsOrgRelationDto = wholesaleAgencyClientService.selectFxoPcDmsOrgRelationById(id).getData();
	}
	try {
		commonService.showAgencyButton(request);
	} catch (Exception e) {
		e.printStackTrace();
	}
	request.setAttribute("fxoPcDmsOrgRelation", fxoPcDmsOrgRelationDto);
	return "/agency/editAgency";
}

@RequestMapping(value = "/list")
public String toAgencyList(HttpServletRequest request){
	try {
		commonService.showAgencyButton(request);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return "/agency/agencyList";
}
}

@RestController
@RequestMapping(value = "/agencyRest")
class WholesaleAgencyRestController{
	
	private static Log logger = LogFactory.getLog(WholesaleAgencyController.class);  
	
	@Autowired
	private WholesaleAgencyClientService wholesaleAgencyClientService;
	
	@RequestMapping(value = "/addAgency")
	public Map<String, Object> addAgency(HttpServletRequest request,
			FXOPcDmsOrgRelationParam fxoPcDmsOrgRelationParam,Integer cooperationMode){
		Map<String, Object> result = new HashMap<String, Object>();
			if(fxoPcDmsOrgRelationParam == null || fxoPcDmsOrgRelationParam.getProvinceOrg().isEmpty()){
				result.put("result", "fail");
				return result;
			}
			
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			String orgName = OpcSDKTools.getOrgunitName(request);
			FXOPcDmsOrgRelationDto fxoPcDmsOrgRelationDto = new FXOPcDmsOrgRelationDto();
			fxoPcDmsOrgRelationDto.setCreateUser(userName);
			fxoPcDmsOrgRelationDto.setCreateTime(new Date());
			fxoPcDmsOrgRelationDto.setState(FxPurchaseStateEnum.STATE_AGENCY_0.getIndex());
			if(fxoPcDmsOrgRelationParam !=null){
				fxoPcDmsOrgRelationDto.setSignProvinceCode(fxoPcDmsOrgRelationParam.getProvinceOrg());
				fxoPcDmsOrgRelationDto.setSignProvinceName(fxoPcDmsOrgRelationParam.getProvinceOrgName());
				fxoPcDmsOrgRelationDto.setSignCityCode(fxoPcDmsOrgRelationParam.getCityOrg());
				fxoPcDmsOrgRelationDto.setSignCityName(fxoPcDmsOrgRelationParam.getCityOrgName());
				fxoPcDmsOrgRelationDto.setSignRegionCode(fxoPcDmsOrgRelationParam.getCountyOrg());
				fxoPcDmsOrgRelationDto.setSignRegionName(fxoPcDmsOrgRelationParam.getCountyOrgName());
				fxoPcDmsOrgRelationDto.setCooperationMode(cooperationMode);
				fxoPcDmsOrgRelationDto.setDmsOrgCode(fxoPcDmsOrgRelationParam.getDMSOrg());
			}
			ChinaPostOrgunit chinapostOrgunit =	OpcSDKTools.getChinapostOrgunit(request);
			fxoPcDmsOrgRelationDto.setOrgName(orgName);
			fxoPcDmsOrgRelationDto.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxoPcDmsOrgRelationDto.setProvinceOrgCode(chinapostOrgunit.getCode());
			}
			if(userLevel.intValue()==2){
				fxoPcDmsOrgRelationDto.setCityOrgCode(chinapostOrgunit.getCode());
				fxoPcDmsOrgRelationDto.setProvinceOrgCode(chinapostOrgunit.getProvinceCode());
			}
			if(userLevel.intValue()==3){
				fxoPcDmsOrgRelationDto.setRegionOrgCode(chinapostOrgunit.getCode());
				fxoPcDmsOrgRelationDto.setCityOrgCode(chinapostOrgunit.getParentCode());
				fxoPcDmsOrgRelationDto.setProvinceOrgCode(chinapostOrgunit.getProvinceCode());
			}
			//检验机构是否存在
			FXOPcDmsOrgRelationDto fxoPcDmsOrgRelation = new FXOPcDmsOrgRelationDto();
			fxoPcDmsOrgRelation.setOrgName(orgName);
			fxoPcDmsOrgRelation.setOrgLevel(userLevel.toString());
			String orgCode = OpcSDKTools.getOrgunitCode(request);
			if(userLevel.intValue()==1){
				fxoPcDmsOrgRelation.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxoPcDmsOrgRelation.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxoPcDmsOrgRelation.setRegionOrgCode(orgCode);
			}
			fxoPcDmsOrgRelation.setSignProvinceCode(fxoPcDmsOrgRelationDto.getSignProvinceCode());
			ResultDTO<Map<String, Object>> resultDTO = wholesaleAgencyClientService.getAgencyListByPage(fxoPcDmsOrgRelation, 1, 5,null);
			List<FXOPcDmsOrgRelationDto> list = (List<FXOPcDmsOrgRelationDto>) resultDTO.getData().get("list");
			if(list!= null && list.size()>0){
				result.put("result", "0002");
				result.put("msg", "机构已存在");
				return result;
			}
			ResultDTO<Integer> rst = wholesaleAgencyClientService.saveWholesaleAgency(fxoPcDmsOrgRelationDto);
			if(rst.getCode().equals("0"))
			result.put("result", "success");
		} catch (Exception e) {
			result.put("result", "fail");
			logger.error("addAgency error "+e.getMessage(),e);
		}
		return result;
	}
	/**
	 * 根据条件分页查询机构
	 * @param pageNo
	 * @param pageSize
	 * @return pageInfo
	 */
	@RequestMapping(value = "/getList",method = RequestMethod.POST)
	public ResultDTO<Map<String, Object>> getAgencyListByPage(HttpServletRequest request,
			FXOPcDmsOrgRelationDto fxoPcDmsOrgRelation,Integer pageNum){
		String orgCode;
		try {
			orgCode = OpcSDKTools.getOrgunitCode(request);
			String orgName = OpcSDKTools.getOrgunitName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxoPcDmsOrgRelation.setOrgName(orgName);
			fxoPcDmsOrgRelation.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxoPcDmsOrgRelation.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxoPcDmsOrgRelation.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxoPcDmsOrgRelation.setRegionOrgCode(orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(pageNum==null){
			pageNum = 1;
		}
		Integer pageSize = 10;
		ResultDTO<Map<String, Object>> rst= wholesaleAgencyClientService.getAgencyListByPage(fxoPcDmsOrgRelation, pageNum, pageSize,null);
		return rst;
	}
	
	@RequestMapping( value = "/editAgency")
	public Map<String, Object> editAgency(HttpServletRequest request,FXOPcDmsOrgRelationDto fxoPcDmsOrgRelatio){
		Map<String, Object> result = new HashMap<String, Object>();
		FXOPcDmsOrgRelationDto fxoPcDmsOrgRelation1 = wholesaleAgencyClientService.selectFxoPcDmsOrgRelationById(fxoPcDmsOrgRelatio.getId()).getData();
		if(fxoPcDmsOrgRelation1 == null ){
			result.put("result", "fail");
			result.put("msg", "机构不存在");
			return result;
		}
		//检验机构是否存在
		FXOPcDmsOrgRelationDto fxoPcDmsOrgRelation = new FXOPcDmsOrgRelationDto();
		String orgName ;
		Integer userLevel;
		String orgCode;
		try {
			orgName = OpcSDKTools.getOrgunitName(request);
			userLevel = OpcSDKTools.getUserLevel(request);
			orgCode = OpcSDKTools.getOrgunitCode(request);
			fxoPcDmsOrgRelation.setOrgName(orgName);
			fxoPcDmsOrgRelation.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxoPcDmsOrgRelation.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxoPcDmsOrgRelation.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxoPcDmsOrgRelation.setRegionOrgCode(orgCode);
			}
		} catch (Exception e1) {
			result.put("result", "fail");
			result.put("msg", "修改失败");
			logger.error("editAgency error : "+e1.getMessage(),e1);
			e1.printStackTrace();
		}
		fxoPcDmsOrgRelation.setSignProvinceCode(fxoPcDmsOrgRelatio.getSignProvinceCode());
		ResultDTO<Map<String, Object>> resultDTO = wholesaleAgencyClientService.getAgencyListByPage(fxoPcDmsOrgRelation, 1, 5,null);
		List<FXOPcDmsOrgRelationDto> list = (List<FXOPcDmsOrgRelationDto>) resultDTO.getData().get("list");
		if(list!= null && list.size()>0){
			result.put("result", "0002");
			result.put("msg", "机构已存在");
			return result;
		}
		try {
			wholesaleAgencyClientService.updateFxoPcDmsOrgRelation(fxoPcDmsOrgRelatio);
			result.put("result", "success");
			result.put("msg", "修改成功");
		} catch (Exception e) {
			result.put("result", "fail");
			result.put("msg", "修改失败");
			logger.error("editAgency error : "+e.getMessage(),e);
		}
		return result;
	}
	
	
} 
