package com.ule.wholesale.fxpurchase.web.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ule.rural.opc.sdk.filter.UserLoginFilter;

public class LoginFilter extends  UserLoginFilter {

	private static Logger logger = LoggerFactory.getLogger(LoginFilter.class);
	//(.)*(\.(css|js|gif|png|jpg|ico|html))$ | (.)*\/(\w){1,}$ | (.)*\/(health)\/(.)* 
	List<Pattern> patterns = new ArrayList<Pattern>();
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		String exclusions = filterConfig.getInitParameter("exclusions");
		String []exclusionsList = null;
		if(StringUtils.isNotBlank(exclusions)){
			exclusionsList = exclusions.split(",");
		}
		//设置正则表达式
		String subfix = "";//后缀匹配
		String parentPath = "";//匹配指定路径下的所有子路径
		String fixPath = "";//匹配指定某个路径
		
		if(exclusionsList != null && exclusionsList.length > 0){
			for(String s:exclusionsList){
				//指定后缀
				int index = s.indexOf("*.");
				if(index >= 0){
					subfix += "|"+s.substring(index+2);
				}else{
					//指定路径下的所有
					index = s.indexOf("/*");
					if(index >0){
						if(s.startsWith("/")){
							parentPath += "|"+s.substring(1,index);
						}else{
							parentPath += "|"+s.substring(0,index);
						}
						
					}else{
						//指定某个路径
						index =s.lastIndexOf("/");
						if(index != -1){
							fixPath += "|"+s.substring(1);
						}else{
							fixPath += "|"+s;
						}
					}
				}
			}
			if(!"".equals(subfix)){
				subfix = subfix.substring(1);
				//(.)*(\.(css|js|gif|png|jpg|ico|html))$ 
				subfix = "(.)*(\\.("+subfix+"))$";
				Pattern p = Pattern.compile(subfix);
				patterns.add(p);
			}
			if (!"".equals(parentPath)) {
				parentPath= parentPath.substring(1);
				//(.)*\/(health)\/(.)
				parentPath = "(.)*\\/("+parentPath+")\\/(.)";
				Pattern p = Pattern.compile(parentPath);
				patterns.add(p);
			}
			if (!"".equals(fixPath)) {
				fixPath = fixPath.substring(1);
				//(.)*\/(\w){1,}$
				fixPath = "(.)*\\/("+fixPath+")$";
				Pattern p = Pattern.compile(fixPath);
				patterns.add(p);
			}
		}
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		String requestUrl = req.getServletPath();
		logger.info("排除指定的不需要过滤的请求requestUrl="+requestUrl);
		boolean flag = false;
		if(patterns != null){
			for(Pattern p : patterns){
				if(p.matcher(requestUrl).find()){
					flag = true;
					break;
				}
			}
		}
		if(flag){
			logger.info("该请求无需过滤");
			chain.doFilter(request, response);
		}else{
			logger.info("该请求不在排除范围内，调用原来的filter进行处理");
			super.doFilter(request, response, chain);
		}
	}

	@Override
	public void destroy() {
		super.destroy();
	}

}
