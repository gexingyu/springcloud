package com.ule.wholesale.fxpurchase.web.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import feign.Request;
import feign.Retryer;

@Component
public class InitBean {
	
	@Value("${feignConnectTimeout:10000}")
	private Integer connectTimeoutMillis;
	@Value("${feignReadTimeout:60000}")
	private Integer readTimeoutMillis;
	
	// feign client默认的connectTimeout为10s，readTimeout为60.单纯设置timeout，可能没法立马见效，因为默认的retry为5次    
	@Bean
    Request.Options feignOptions() {
        return new Request.Options(/**connectTimeoutMillis**/connectTimeoutMillis, /** readTimeoutMillis **/readTimeoutMillis);
    }
	//禁用重发请求，对于修改操作可以防止数据被多次提交
	@Bean
    Retryer feignRetryer() {
        return Retryer.NEVER_RETRY;
    }
	
}
