package com.ule.wholesale.fxpurchase.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ule.sdk.address.UleAddressClient;
import com.ule.sdk.address.dto.AddressInfo;
import com.ule.wholesale.fxpurchase.web.config.PropertiesConfiguration;

/**
 * 获取 省,市,县 级联
 * @author {lishaozhe} E-mail:lishaozhe@tomstaff.com
 * @version 创建时间：2015年10月8日 下午5:59:53
 */
@Controller
public class MerApplyAjaxAddressController {

	Logger logger = Logger.getLogger(MerApplyAjaxAddressController.class);
	@RequestMapping("merApply/ajaxAddress4area")
	@ResponseBody
	public String join4area(HttpServletRequest request, HttpServletResponse response){
		String clientName = PropertiesConfiguration.clientName;
		String clientKey = PropertiesConfiguration.clientKey;
		String addressType = request.getParameter("addressType");
		String parm = request.getParameter("parm");
		try{
			UleAddressClient client = com.ule.sdk.address.UleAddressClient.getInstance(clientName,clientKey);
			if(client == null){
				return null;
			}
			if("province".equals(addressType)){
				List<AddressInfo> list = client.queryUleAddress(null,0).getResult();
				String resultString = "{\"provinceInfo\":[{\"provinceId\":\"0\",\"provinceName\":\"----省份----\"},";
				for (int i = 0; i < list.size()-1; i++) {
					if(list.get(i).getRank() ==2){
						resultString+="{\"provinceName\":\""+list.get(i).getName()+"\",\"provinceId\":\""+list.get(i).getCode()+"\"},";
					}
				}
				if(list.get(list.size()-1).getRank() ==2){
					resultString+="{\"provinceName\":\""+list.get(list.size()-1).getName()+"\",\"provinceId\":\""+list.get(list.size()-1).getCode()+"\"}";
				}else{
					resultString+="{\"provinceName\":\""+""+"\",\"provinceId\":\""+""+"\"}";
				}
				resultString+="]}";
				return resultString;
			}else if("city".equals(addressType)){
				List<AddressInfo> list = client.queryUleAddress(parm,1).getResult();
				String resultString = "{\"cityInfo\":[";
				for (int i = 0; i < list.size()-1; i++) {
					if(list.get(i).getRank() ==3){
						resultString+="{\"cityName\":\""+list.get(i).getName()+"\",\"cityId\":\""+list.get(i).getCode()+"\"},";
					}
				}
				if(list.get(list.size()-1).getRank() ==3){
					resultString+="{\"cityName\":\""+list.get(list.size()-1).getName()+"\",\"cityId\":\""+list.get(list.size()-1).getCode()+"\"}";
				}else{
					resultString+="{\"cityName\":\""+""+"\",\"cityId\":\""+""+"\"}";
				}
				resultString+="]}";
				return resultString;
			}else if("area".equals(addressType)){
				List<AddressInfo> list = client.queryUleAddress(parm,1).getResult();
				String resultString = "{\"areaInfo\":[";
				for (int i = 0; i < list.size()-1; i++) {
					if(list.get(i).getRank() ==4){
						resultString+="{\"areaName\":\""+list.get(i).getName()+"\",\"areaId\":\""+list.get(i).getCode()+"\"},";
					}
				}
				if(list.get(list.size()-1).getRank() ==4){
					resultString+="{\"areaName\":\""+list.get(list.size()-1).getName()+"\",\"areaId\":\""+list.get(list.size()-1).getCode()+"\"}";
				}else{
					resultString+="{\"areaName\":\""+""+"\",\"areaId\":\""+""+"\"}";
				}
				resultString+="]}";
				return resultString;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
}
