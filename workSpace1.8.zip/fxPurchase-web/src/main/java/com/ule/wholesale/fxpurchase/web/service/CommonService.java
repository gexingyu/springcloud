package com.ule.wholesale.fxpurchase.web.service;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.HttpClientUtil;
import com.ule.wholesale.common.util.MD5Tools;
import com.ule.wholesale.fxpurchase.api.dto.FXRequireGoodsListDto;
import com.ule.wholesale.fxpurchase.web.config.PropertiesConfiguration;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Service
public class CommonService {

	private Logger logger = LoggerFactory.getLogger(CommonService.class);
	
	public List<Map<String,Object>> getUleMerchantList(String orgId){
		 List<Map<String,Object>> merchantList = new ArrayList<Map<String,Object>>();
		 logger.info("当前登录账户的机构ID="+orgId);
		 String rst = getUleSelfSupportMerchantList(orgId);
		 if(rst != null && !"".equals(rst)){
			 JSONObject json = JSONObject.parseObject(rst);
			 if(json != null && json.get("returnCode") != null && "0000".equals(json.getString("returnCode"))){
				 JSONArray jsonArr = JSONArray.parseArray(json.getString("returnData"));
				 for(Object obj : jsonArr){
					 JSONObject d = (JSONObject) obj;
					 String mId = d.getString("usrOnlyid");
					 String mName = d.getString("usrTrueName");
					 Map<String,Object> map = new HashMap<String, Object>();
					 map.put("merchantId", mId);
					 map.put("merchantName", mName);
					 merchantList.add(map);
				 }
			 }
		 }
		 if(StringUtils.isNotBlank(PropertiesConfiguration.betaTestMerchant)){
			 Map<String,Object> map = new HashMap<String, Object>();
			 map.put("merchantId",PropertiesConfiguration.betaTestMerchant.split("-")[0]);
			 map.put("merchantName",PropertiesConfiguration.betaTestMerchant.split("-")[1]);
			 merchantList.add(map);
		 }
		 return merchantList;
	 }
	
	/**
	 * 获取邮乐自营商家列表
	 * @param orgunitLev1
	 * @return
	 */
	public String getUleSelfSupportMerchantList(String orgunitLev1){
		logger.info("getUleSelfSupportMerchantList  orgunitLev1="+orgunitLev1);
		
		Map<String,String> headMap = new HashMap<String, String>();
		String requestTime = System.currentTimeMillis()+"";
//		try {
//			requestTime = (new SimpleDateFormat("yyyy-MM-dd HH:MM:ss").parse(WebDateUtils.getWebsiteDatetime(null)).getTime())+"";
//		} catch (ParseException e1) {
//			requestTime = System.currentTimeMillis()+"";
//		}//System.currentTimeMillis()+"";
		headMap.put("appKey", requestTime + "|" + MD5Tools.md5(requestTime.substring(2, 12)));
		
		Map<String,Object> paramMap = new HashMap<String, Object>();
		if(orgunitLev1 != null)
			paramMap.put("orgunitLev1",orgunitLev1);
		String result = "";
		try {
			result = HttpClientUtil.sendPost(PropertiesConfiguration.uleSelfSupport,headMap,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public String getMerchantItemStorage(Long merchantId,Long whId,List<Long> itemIds){
		logger.info("getMerchantWarehouseList  merchantId="+merchantId);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("merchantOnlyId",merchantId);
		paramMap.put("whId",whId);
		if(itemIds != null && itemIds.size() > 0)
			paramMap.put("itemIds",StringUtils.join(itemIds, ","));
		//?merchantOnlyId=1&whId=1&itemIds
		String result = "";
		try {
			result = HttpClientUtil.sendPost(PropertiesConfiguration.itemsStorage,null,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 作废入库通知单
	 * @param orderNo
	 * @param warehouseId
	 * @return
	 */
	public String cancelPurcahseOrder(String orderNo,Long warehouseId){
		logger.info("cancelPurcahseOrder  orderNo="+orderNo);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("customerOrderNo",orderNo);
		paramMap.put("warehouseId",warehouseId);
		String result = "";
		try {
			result = HttpClientUtil.sendPost(PropertiesConfiguration.cancelPurchaseOrder,null,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public void showButton(HttpServletRequest request) throws Exception{
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if(str.equals(FxPurchaseStateEnum.ORDER_ADD.getName())){
					request.setAttribute("order_add", "show");
				}else if(str.equals(FxPurchaseStateEnum.ORDER_EDIT.getName())){
					request.setAttribute("order_edit", "show");
				}else if(str.equals(FxPurchaseStateEnum.ORDER_SUBMIT.getName())){
					request.setAttribute("order_submit", "show");
				}else if(str.equals(FxPurchaseStateEnum.ORDER_DEL.getName())){
					request.setAttribute("order_del", "show");
				}else if(str.equals(FxPurchaseStateEnum.ORDER_AUDIT.getName())){
					request.setAttribute("order_audit", "show");
				}else if(str.equals(FxPurchaseStateEnum.ORDER_CANCEL.getName())){
					request.setAttribute("order_cancel", "show");
				}else if(str.equals(FxPurchaseStateEnum.ORDER_PRINT.getName())){
					request.setAttribute("order_print", "show");
				}else if(str.equals(FxPurchaseStateEnum.ORDER_PAY.getName())){
					request.setAttribute("order_pay", "show");
				}else if(str.equals(FxPurchaseStateEnum.ORDER_RECEPT.getName())){
					request.setAttribute("order_recept", "show");
				}
			}
		}
	}
	/**
	 * return order button
	 * @throws Exception 
	 */
	public void showROButton(HttpServletRequest request) throws Exception{
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if(str.equals(FxPurchaseStateEnum.RETURN_ORDER_ADD.getName())){
					request.setAttribute("return_order_add", "show");
				}else if(str.equals(FxPurchaseStateEnum.RETURN_ORDER_EDIT.getName())){
					request.setAttribute("return_order_edit", "show");
				}else if(str.equals(FxPurchaseStateEnum.RETURN_ORDER_SUBMIT.getName())){
					request.setAttribute("return_order_submit", "show");
				}else if(str.equals(FxPurchaseStateEnum.RETURN_ORDER_DEL.getName())){
					request.setAttribute("return_order_del", "show");
				}else if(str.equals(FxPurchaseStateEnum.RETURN_ORDER_AUDIT.getName())){
					request.setAttribute("return_order_audit", "show");
				}else if(str.equals(FxPurchaseStateEnum.RETURN_ORDER_CANCEL.getName())){
					request.setAttribute("return_order_cancel", "show");
				}else if(str.equals(FxPurchaseStateEnum.RETURN_ORDER_PRINT.getName())){
					request.setAttribute("return_order_print", "show");
				}
			}
		}
	}
	
	public void showAgencyButton(HttpServletRequest request) throws Exception{
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if(str.equals(FxPurchaseStateEnum.AGENCY_ADD.getName())){
					request.setAttribute("agency_add", "show");
				}else if(str.equals(FxPurchaseStateEnum.AGENCY_EDIT.getName())){
					request.setAttribute("agency_edit", "show");
				}else if(str.equals(FxPurchaseStateEnum.AGENCY_OPER.getName())){
					request.setAttribute("agency_oper", "show");
				}
			}
		}
	}
	
	public void showGoodsButton(HttpServletRequest request) throws Exception{
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if(str.equals(FxPurchaseStateEnum.GOODS_COMPARE_ADD.getName())){
					request.setAttribute("goods_compare_add", "show");
				}else if(str.equals(FxPurchaseStateEnum.GOODS_COMPARE_EDIT.getName())){
					request.setAttribute("goods_compare_edit", "show");
				}else if(str.equals(FxPurchaseStateEnum.GOODS_COMPARE_DEL.getName())){
					request.setAttribute("goods_compare_del", "show");
				}
			}
		}
	}
	public void showWhOrderButton(HttpServletRequest request) throws Exception{
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if(str.equals(FxPurchaseStateEnum.WHORDER_ADD.getName())){
					request.setAttribute("whorder_add", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHORDER_AUDIT.getName())){
					request.setAttribute("whorder_audit", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHORDER_DEL.getName())){
					request.setAttribute("whorder_del", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHORDER_CANCEL.getName())){
					request.setAttribute("whorder_cancel", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHORDER_EDIT.getName())){
					request.setAttribute("whorder_edit", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHORDER_SUBMIT.getName())){
					request.setAttribute("whorder_submit", "show");
				}
			}
		}
	}
	public void showWhReturnOrderButton(HttpServletRequest request) throws Exception{
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if(str.equals(FxPurchaseStateEnum.WHRETURN_ORDER_ADD.getName())){
					request.setAttribute("whreturn_order_add", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHRETURN_ORDER_AUDIT.getName())){
					request.setAttribute("whreturn_order_audit", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHRETURN_ORDER_CANCEL.getName())){
					request.setAttribute("whreturn_order_cancel", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHRETURN_ORDER_DEL.getName())){
					request.setAttribute("whreturn_order_del", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHRETURN_ORDER_EDIT.getName())){
					request.setAttribute("whreturn_order_edit", "show");
				}else if(str.equals(FxPurchaseStateEnum.WHRETURN_ORDER_SUBMIT.getName())){
					request.setAttribute("whreturn_order_submit", "show");
				}
			}
		}
	}
	
	public List<FXRequireGoodsListDto> readExcel(InputStream is, HttpServletRequest request) throws Exception{
		//错误集合
		List<String> errorList = new ArrayList<String>();
		//返回的对象集合
		List<FXRequireGoodsListDto> rqGoodsList = new ArrayList<FXRequireGoodsListDto>();
		try{
			//获取excel对象
			Workbook wb = new HSSFWorkbook(is);
			if("要货清单".equals(wb.getSheetName(0))){
				Sheet sheet = wb.getSheetAt(0);
				Row row = sheet.getRow(1);
				if("总订单号".equals(row.getCell(0).getStringCellValue())&&"订货机构编号".equals(row.getCell(1).getStringCellValue())&&"订货机构名称".equals(row.getCell(2).getStringCellValue())
						&&"收货地址".equals(row.getCell(3).getStringCellValue())&&"订货日期".equals(row.getCell(4).getStringCellValue())&&"期望送达日期".equals(row.getCell(5).getStringCellValue())
						&&"编号".equals(row.getCell(6).getStringCellValue())&&"材料名称".equals(row.getCell(7).getStringCellValue())&&"规格".equals(row.getCell(8).getStringCellValue())
						&&"单位".equals(row.getCell(9).getStringCellValue())&&"单价（元）".equals(row.getCell(10).getStringCellValue())&&"数量".equals(row.getCell(11).getStringCellValue())
						&&"金额（元）".equals(row.getCell(12).getStringCellValue())&&"备注".equals(row.getCell(13).getStringCellValue())){
					//获取opc
					Integer userLevel = OpcSDKTools.getUserLevel(request);
					ChinaPostOrgunit chinaPostOrgunit = OpcSDKTools.getChinapostOrgunit(request);
					
					for(int j=2;j<sheet.getLastRowNum()+1;j++){
						FXRequireGoodsListDto rqGoods = new FXRequireGoodsListDto();
						Cell cell0 =  sheet.getRow(j).getCell(0);//总订单号,必填
						try{
							rqGoods.setSourceOrderNo(checkStringOfNotNull(cell0));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+1+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell1 = sheet.getRow(j).getCell(1);//订货机构编号,必填
						try{
							rqGoods.setOrderOrgCode(checkStringOfNotNull(cell1));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+2+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell2 = sheet.getRow(j).getCell(2);//订货机构名称
						try{
							rqGoods.setOrderOrgName(checkStringOfNull(cell2));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+3+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell3 = sheet.getRow(j).getCell(3);//收货地址,必填
						try{
							rqGoods.setReceiveAddress(checkStringOfNotNull(cell3));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+4+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell4 = sheet.getRow(j).getCell(4);//订货日期,必填
						try{
							rqGoods.setRequireTime(checkDateOfNotNull(cell4));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+5+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell5 = sheet.getRow(j).getCell(5);//期望送达日期
						try{
							rqGoods.setExpectDeliveryTime(checkDateOfNull(cell5));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+6+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell6 = sheet.getRow(j).getCell(6);//编号,必填
						try{
							rqGoods.setDmsItemCode(checkStringOfNotNull(cell6));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+7+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell7 = sheet.getRow(j).getCell(7);//材料名称
						try{
							rqGoods.setDmsItemName(checkStringOfNull(cell7));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+8+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell8 = sheet.getRow(j).getCell(8);//规格
						try{
							rqGoods.setDmsItemSpec(checkStringOfNull(cell8));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+9+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell9 = sheet.getRow(j).getCell(9);//单位
						try{
							rqGoods.setDmsItemUnit(checkStringOfNull(cell9));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+10+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell10 = sheet.getRow(j).getCell(10);//单价（元）,必填
						try{
							rqGoods.setDmsItemPrice(checkBigDecimalOfNotNull(cell10));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+11+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell11 = sheet.getRow(j).getCell(11);//数量,必填
						try{
							rqGoods.setNumber(checkIntegerOfNotNull(cell11));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+12+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell12 = sheet.getRow(j).getCell(12);//金额（元）,必填
						try{
							rqGoods.setAmount(checkBigDecimalOfNotNull(cell12));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+13+"列："+e.getMessage()+"</span><br/>");
						}
						Cell cell13 = sheet.getRow(j).getCell(13);//备注
						try{
							rqGoods.setRemark(checkStringOfNull(cell13));
						}catch(Exception e){
							errorList.add("<span>第"+(j+1)+"行，第"+14+"列："+e.getMessage()+"</span><br/>");
						}
						rqGoods.setState(FxPurchaseStateEnum.REQUIRE_STATUS_0.getIndex());//状态置为0未分配
						rqGoods.setCreateTime(new Date());//创建时间
						rqGoods.setOrgLevel(userLevel.toString());
						rqGoods.setOrgName(chinaPostOrgunit.getName());
						
						if(userLevel.intValue()==1){
							rqGoods.setProvinceOrgCode(chinaPostOrgunit.getCode());
						}
						if(userLevel.intValue()==2){
							rqGoods.setProvinceOrgCode(chinaPostOrgunit.getProvinceCode());
							rqGoods.setCityOrgCode(chinaPostOrgunit.getCode());
						}
						if(userLevel.intValue()==3){
							rqGoods.setProvinceOrgCode(chinaPostOrgunit.getProvinceCode());
							rqGoods.setCityOrgCode(chinaPostOrgunit.getParentCode());
							rqGoods.setRegionOrgCode(chinaPostOrgunit.getCode());
						}
						rqGoodsList.add(rqGoods);
					}
				}else{
					errorList.add("<span>模版错误！请重新下载模版</span><br/>");
				}
			}else{
				errorList.add("<span>模版错误！请重新下载模版</span><br/>");
			}
		}catch(Exception e){
			errorList.add("<span>读取excel程序报错！</span><br/>");
			logger.error("error", e);
		}
		if(errorList.size()>0){
			throw new Exception(JSONArray.toJSONString(errorList));
		}
		return rqGoodsList;
	}
	
	//验证必填的字符串
	private String checkStringOfNotNull(Cell cell) throws Exception{
		if(cell!=null && cell.getCellType()==cell.CELL_TYPE_STRING){//字符串
			return cell.getStringCellValue().replaceAll(" ", "");
		}else if(cell!=null && cell.getCellType()==cell.CELL_TYPE_NUMERIC){//数字
			Double value = cell.getNumericCellValue();
			return String.valueOf(value.intValue());
		}else{
			if(cell==null || cell.getCellType()==cell.CELL_TYPE_BLANK){//判断空
				throw new Exception("不能为空");
			}else{//类型不正确
				throw new Exception("格式不正确");
			}
		}
	}
	
	//验证非必填的字符串
	private String checkStringOfNull(Cell cell) throws Exception{
		if(cell!=null && cell.getCellType()==cell.CELL_TYPE_STRING){
			return cell.getStringCellValue().replaceAll(" ", "");
		}else if(cell!=null && cell.getCellType()==cell.CELL_TYPE_NUMERIC){
			Double value = cell.getNumericCellValue();
			return String.valueOf(value.intValue());
		}else{
			if(cell==null || cell.getCellType()==cell.CELL_TYPE_BLANK){//判断空
				return null;
			}else{//类型不正确
				throw new Exception("格式不正确");
			}
		}
	}
	
	//验证必填的日期
	private Date checkDateOfNotNull(Cell cell) throws Exception{
		if(cell!=null && cell.getCellType()==cell.CELL_TYPE_NUMERIC){
			return cell.getDateCellValue();
		}else{
			if(cell==null || cell.getCellType()==cell.CELL_TYPE_BLANK){//判断空
				throw new Exception("不能为空");
			}else{//类型不正确
				throw new Exception("格式不正确");
			}
		}
	}
	
	//验证非必填的日期
	private Date checkDateOfNull(Cell cell) throws Exception{
		if(cell!=null && cell.getCellType()==cell.CELL_TYPE_NUMERIC){
			return cell.getDateCellValue();
		}else{
			if(cell==null || cell.getCellType()==cell.CELL_TYPE_BLANK){//判断空
				return null;
			}else{//类型不正确
				throw new Exception("格式不正确");
			}
		}
	}
	
	//验证必填的BigDecimal
	private BigDecimal checkBigDecimalOfNotNull(Cell cell) throws Exception{
		if(cell!=null && cell.getCellType()==cell.CELL_TYPE_NUMERIC){
			return new BigDecimal(cell.getNumericCellValue());
		}else{
			if(cell==null || cell.getCellType()==cell.CELL_TYPE_BLANK){//判断空
				throw new Exception("不能为空");
			}else{//类型不正确
				throw new Exception("格式不正确");
			}
		}
	}
	
	//验证必填的Integer
	private Integer checkIntegerOfNotNull(Cell cell) throws Exception{
		if(cell!=null && cell.getCellType()==cell.CELL_TYPE_NUMERIC){
			return (int) cell.getNumericCellValue();
		}else{
			if(cell==null || cell.getCellType()==cell.CELL_TYPE_BLANK){//判断空
				throw new Exception("不能为空");
			}else{//类型不正确
				throw new Exception("格式不正确");
			}
		}
	}

}
