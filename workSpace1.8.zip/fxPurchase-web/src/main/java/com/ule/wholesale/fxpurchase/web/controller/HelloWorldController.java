package com.ule.wholesale.fxpurchase.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecwid.consul.v1.Response;
import com.ecwid.consul.v1.kv.KeyValueClient;
import com.ecwid.consul.v1.kv.model.GetValue;
import com.ule.wholesale.fxpurchase.api.client.CommonClientService;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
import com.ule.wholesale.fxpurchase.api.dto.TestParamDto;
import com.ule.wholesale.fxpurchase.web.redis.RedisService;

@RestController
public class HelloWorldController {

	Logger logger = LoggerFactory.getLogger(HelloWorldController.class);
	@Autowired
    com.ule.wholesale.fxpurchase.api.client.TestClientService client;
	@Autowired
	KeyValueClient  keyValueClient ;
	
	@Autowired
	RedisService reids;
	@RequestMapping("/redis/set")
	public void setRedisValue(String key,String value) {
		reids.set(key, value);
	}
	
	@Autowired
	private LoadBalancerClient loadBalancer;
	
	@Autowired
	CommonClientService commonClientService;
	@RequestMapping("/send")
	public void setMsg() {
		commonClientService.sendMsg();
	}
	@RequestMapping("/discover")
	public Object discover() {
		return loadBalancer.choose(ClientConstants.SERVICE_NAME).getUri().toString();
	}
	
	@RequestMapping("/hello")
    public String helloWorld(HttpServletRequest req) {
		req.setAttribute("__sessionId__", UUID.randomUUID());
		logger.info(" UUID.randomUUID()="+ UUID.randomUUID());
		return client.hello("mingzhi");
    }
	@Value("${spring.application.instance_id:${random.value}}")
	String serverId;
	
	@Autowired
	private DiscoveryClient discoveryClient;
	/**
	 * 获取所有服务 
	 */
	@RequestMapping("/services")
	public Object services() {
		return discoveryClient.getInstances(ClientConstants.SERVICE_NAME).get(0).getPort();
//		return discoveryClient.getInstances(ClientConstants.SERVICE_NAME)+">>>>>>>"+serverId;
	}
	@RequestMapping("/kv")
	public String testKv(String key,String value){
		keyValueClient.setKVValue(key, value);
		Response<GetValue> kv = keyValueClient.getKVValue(key);
		String v = kv.getValue().getDecodedValue();
		return v;
	}
	@RequestMapping("/params")
	public Object params() {
		return client.testParam("mingzhi", 28, new Date());
	}
	
	@RequestMapping("/paramList")
	public Object paramList() {
		List<Integer> ages = new ArrayList<Integer>();
		ages.add(20);
		ages.add(25);
		return client.testParamList("mingzhi", ages);
	}
	
	@RequestMapping("/dto")
    public Object testDto() {
		TestParamDto dto = new TestParamDto();
		dto.setAge(20);
		dto.setName("mingzhi");
		dto.setBirthday(new Date());
        return client.testDto(dto);
    }
	
	@RequestMapping("/dto2")
    public Object testDto2() {
		TestParamDto dto = new TestParamDto();
		dto.setAge(20);
		dto.setName("mingzhi");
		dto.setBirthday(new Date());
		TestParamDto dto2 = new TestParamDto();
		dto2.setAge(22);
		dto2.setName("mingzhi2");
		dto2.setBirthday(new Date());
        return client.testDto2(dto,dto2);
    }
	
	@RequestMapping("/list")
    public Object testList() {
		List<TestParamDto> dtoList = new ArrayList<TestParamDto>();
		TestParamDto dto = new TestParamDto();
		dto.setAge(20);
		dto.setName("mingzhi");
		dto.setBirthday(new Date());
		TestParamDto dto2 = new TestParamDto();
		dto2.setAge(22);
		dto2.setName("mingzhi2");
		dto2.setBirthday(new Date());
		dtoList.add(dto);
		dtoList.add(dto2);
        return client.testList(dtoList);
    }
	
	@RequestMapping("/map")
    public Object testDtoMap() {
		Map<String,Object> dto = new HashMap<String,Object>();
		dto.put("age",20);
		dto.put("name","mingzhi");
		dto.put("birthday",new Date());
        return client.testMap(dto);
    }
}
