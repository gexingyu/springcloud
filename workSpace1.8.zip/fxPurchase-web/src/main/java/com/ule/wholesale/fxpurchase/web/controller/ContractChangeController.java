package com.ule.wholesale.fxpurchase.web.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.ule.fenxiao.search.ItemSearchESTools;
import com.ule.fenxiao.search.dto.MerchantItemDTO;
import com.ule.fenxiao.search.dto.PaginationList;
import com.ule.wholesale.common.constants.CommonConstants;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.BankInfoClientService;
import com.ule.wholesale.fxpurchase.api.client.ContractChangeClientService;
import com.ule.wholesale.fxpurchase.api.client.ContractClientService;
import com.ule.wholesale.fxpurchase.api.client.ContractItemClientService;
import com.ule.wholesale.fxpurchase.api.client.OperationLogClientService;
import com.ule.wholesale.fxpurchase.api.client.SupplierInfoClientService;
import com.ule.wholesale.fxpurchase.api.dto.FXContractChangeDto;
import com.ule.wholesale.fxpurchase.api.dto.FXContractInfoDto;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemChangeDto;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemListDto;
import com.ule.wholesale.fxpurchase.api.dto.FXOperationLogDto;
import com.ule.wholesale.fxpurchase.api.dto.FXSupplierInfoDto;
import com.ule.wholesale.fxpurchase.web.config.PropertiesConfiguration;
import com.ule.wholesale.fxpurchase.web.service.CommonService;
import com.ule.wholesale.fxpurchase.web.service.ContractChangeService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Controller
public class ContractChangeController {
	
	public static final Integer PAGESIZE = 10;
	
	private Log log = LogFactory.getLog(ContractChangeController.class);
	@Autowired
	private ContractChangeService contractChangeService;
	@Autowired
	private ContractChangeClientService contractChangeClientService;
	@Autowired
	private ContractClientService contractClientService;
	@Autowired
	private SupplierInfoClientService supplierInfoClientService;
	@Autowired
	private OperationLogClientService operationLogClientService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ContractItemClientService contractItemClientService;
	@Autowired
	private BankInfoClientService bankInfoClientService;
	
	@RequestMapping(value="change/list")
	public String toContractChangeList(HttpServletRequest request){
		return "contract/contract_change_list";
	}
	
	@RequestMapping(value="contractChange/{currentPage}/{flag}/doQuery")
	public String doQuery(HttpServletRequest request,@PathVariable("currentPage") Integer currentPage,@PathVariable("flag") String flag){
		try{
			String orgunitCode = OpcSDKTools.getOrgunitCode(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			
			Map<String,Object> params = new HashMap<String,Object>();
			if(flag!=null && flag.equals("general")){
				String changePaperCode = request.getParameter("changePaperCode");
				String status = request.getParameter("status");
				String changeType = request.getParameter("changeType");
				String contractCode = request.getParameter("contractCode");
				String supplierId = request.getParameter("supplierId");
				String supplierName = request.getParameter("supplierName");
				if(contractCode!=null && !"".equals(contractCode)) params.put("contractCode", contractCode);
				if(supplierId!=null && !"".equals(supplierId)) params.put("supplierId", supplierId);
				if(supplierName!=null && !"".equals(supplierName)) params.put("supplierName", supplierName);
				if(status!=null && !"".equals(status)) params.put("status", status);
				if(changeType!=null && !"".equals(changeType)) params.put("changeType", changeType);
				if(changePaperCode!=null && !"".equals(changePaperCode)) params.put("changePaperCode", changePaperCode);
			}else if(flag!=null && flag.equals("fast")){
				String statusStr = request.getParameter("statusStr");
				String[] statusAttr = null;
				if(statusStr!=null && !"".equals(statusStr)){
					if(statusStr.indexOf(",")==-1){
						statusAttr = new String[]{statusStr};
					}else{
						statusAttr = statusStr.split(",");
					}
				}
				if(statusAttr!=null && statusAttr.length>0){
					params.put("statusAttr", statusAttr);
				}
			}
			params.put("orgLevel", userLevel);
			if(userLevel.intValue()==1){params.put("provinceOrgCode", orgunitCode);}
			if(userLevel.intValue()==2){params.put("cityOrgCode", orgunitCode);}
			if(userLevel.intValue()==3){params.put("regionOrgCode", orgunitCode);}
			
			ResultDTO<Map<String,Object>> rstDTO = contractChangeClientService.getPageByParams(params,currentPage,PAGESIZE,"create_time desc");
			request.setAttribute("retList", rstDTO.getData().get("list"));
			request.setAttribute("totalPage", rstDTO.getData().get("pages"));
			request.setAttribute("currentPage", rstDTO.getData().get("pageNum"));
			
			//设置权限
			contractChangeService.showButton(request);
		}catch(Exception e){
			log.error("error", e);
		}
		return "contract/contract_change_list_record";
	}
	
	@RequestMapping(value="contractChange/{changePaperId}/{changeType}/toDetail")
	public String toDetail(HttpServletRequest request,@PathVariable("changePaperId") Long changePaperId,@PathVariable("changeType") Integer changeType){
		String retStr = null;
		try{
			if(changeType.intValue()==3){//商品价格变更
				retStr = "contract/contract_change_detail";
			}
			if(changeType.intValue()==4){//商品终止
				retStr = "contract/contract_item_stop_detail";
			}
			if(changeType.intValue()==1){//基本信息变更
				retStr = "contract/basic_info_detail";
			}
			if(changeType.intValue()==2){//账户信息变更
				retStr = "contract/account_info_detail";
			}
			if(changeType.intValue()==5){//结算信息变更
				retStr = "contract/balance_info_detail";
			}
			FXContractChangeDto fxContractChange = contractChangeClientService.selectByPrimaryKey(changePaperId);
			ResultDTO<FXSupplierInfoDto> rstDTO = supplierInfoClientService.getSupplierDetail(fxContractChange.getSupplierId());
			FXContractInfoDto contractInfo = contractClientService.selectDtoByPrimaryKey(fxContractChange.getContractId());
			FXContractChangeDto dto = new FXContractChangeDto();
			BeanUtils.copyProperties(fxContractChange,dto);
			dto.setSupplierName(rstDTO.getData()==null ? "" : rstDTO.getData().getSupplierName());
			dto.setOrgName(contractInfo==null ? "" : contractInfo.getOrgName());
			request.setAttribute("fxContractChange", dto);
			request.setAttribute("signOrg", dto.getOrgName());
			List<FXContractItemChangeDto> itemChangeList = contractChangeClientService.selectByChangePaperId(changePaperId);
			request.setAttribute("itemChangeList", itemChangeList);
			List<FXOperationLogDto> optLogList = operationLogClientService.getOperationLogList(changePaperId.toString(), FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());
			request.setAttribute("optLogList", optLogList);
	
			//设置权限
			contractChangeService.showButton(request);
			
		}catch(Exception e){
			log.error("error", e);
		}
		return retStr;
	}
	
	@RequestMapping(value="contractChange/{changePaperId}/{changeType}/toEdit")
	public String toEdit(HttpServletRequest request,@PathVariable("changePaperId") Long changePaperId,@PathVariable("changeType") Integer changeType){
		String retStr = null;
		try{
			if(changeType.intValue()==3){//商品价格变更
				List<FXContractItemChangeDto> contractItemList = contractChangeClientService.selectByChangePaperId(changePaperId);
				request.setAttribute("contractItemList", contractItemList);
				retStr = "contract/contract_change_edit";
			}
			if(changeType.intValue()==4){//商品终止
				List<FXContractItemChangeDto> contractItemList = contractChangeClientService.selectByChangePaperId(changePaperId);
				request.setAttribute("contractItemList", contractItemList);
				retStr = "contract/contract_item_stop_edit";
			}
			if(changeType.intValue()==1){//基本信息变更
				retStr = "contract/basic_info_change";
			}
			if(changeType.intValue()==2){//账户信息变更
				retStr = "contract/account_info_change";
			}
			if(changeType.intValue()==5){//结算信息变更
				retStr = "contract/balance_info_change";
			}
			
			FXContractChangeDto contractChangeDto = contractChangeClientService.selectDtoByPrimaryKey(changePaperId);
			request.setAttribute("contractChangeDto", contractChangeDto);
			request.setAttribute("signOrg", contractChangeDto.getOrgName());
	
		}catch(Exception e){
			log.error("error", e);
		}
		return retStr;
	}
	
	@RequestMapping(value="contractChange/{currentPage}/addGoods")
	public String addGoods(HttpServletRequest request,@PathVariable("currentPage") Integer currentPage,Model model,String flag,String index){
		try {
			List<String> merchantIdList = new ArrayList<String>();
			List<Map<String, Object>> merchantList = commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request).toString());
			if(merchantList!=null && merchantList.size()>0){
				for(Map<String, Object> map : merchantList){
					merchantIdList.add(map.get("merchantId").toString());
				}
			}
			log.info("merchantIdList===="+merchantIdList);
			
			String itemId = request.getParameter("itemId");
			request.setAttribute("itemId", itemId);
			String itemName = request.getParameter("itemName");
			request.setAttribute("itemName", itemName);
			
			MerchantItemDTO dto = new MerchantItemDTO();
			dto.setIpPort(CommonConstants.searchDistrIpPort);
			dto.setAppKey(PropertiesConfiguration.itemAppkey);
			if(merchantIdList!=null && merchantIdList.size()>0){
				dto.setMerchantIds(merchantIdList);
			}else{
				dto.setMerchantId(-System.currentTimeMillis());
			}
			dto.setStartIndex((currentPage-1)*PAGESIZE);
			dto.setPageSize(PAGESIZE);
			
			if(itemId!=null && !"".equals(itemId)) dto.setItemId(Long.valueOf(itemId));
			if(itemName!=null && !"".equals(itemName)) dto.setItemName(itemName);
			
			PaginationList<MerchantItemDTO> itemList = ItemSearchESTools.searchItem(dto);
			int total = itemList.getTotalRecords();
			int totalPage = total%PAGESIZE==0 ? total/PAGESIZE : total/PAGESIZE + 1;
			model.addAttribute("flag", flag);
			model.addAttribute("index", index);
			model.addAttribute("itemList",itemList);
			model.addAttribute("totalPage",totalPage);
			model.addAttribute("currentPage", currentPage);
		} catch (Exception e) {
			log.error("error", e);
		}
		return "contract/addGoods";
	}
	
	@RequestMapping(value="contractChange/{contractId}/{currentPage}/addGoods1")
	public String addGoods1(HttpServletRequest request,@PathVariable("contractId") Long contractId,@PathVariable("currentPage") Integer currentPage,Model model,String flag,String index){
		try {
			String itemId = request.getParameter("itemId");
			request.setAttribute("itemId", itemId);
			String itemName = request.getParameter("itemName");
			request.setAttribute("itemName", itemName);
			
			Map<String,Object> params = new HashMap<String,Object>();
			params.put("contractId", contractId);
			if(itemId!=null && !"".equals(itemId)) params.put("itemId", itemId);
			if(itemName!=null && !"".equals(itemName)) params.put("itemName", itemName);
			
			ResultDTO<PageInfo<FXContractItemListDto>> rstDTO = contractItemClientService.selectEffectiveItemListByContractId(params,currentPage,PAGESIZE,null);
			
			model.addAttribute("flag", flag);
			model.addAttribute("index", index);
			model.addAttribute("itemList",rstDTO.getData().getList());
			model.addAttribute("totalPage",rstDTO.getData().getPages());
			model.addAttribute("currentPage", rstDTO.getData().getPageNum());
			model.addAttribute("contractId", contractId);
		} catch (Exception e) {
			log.error("error", e);
		}
		return "contract/addGoods1";
	}
	
	/**
	 * 基本信息变更新建
	 * 
	 * */
	@RequestMapping( value = "contractChange/{id}/toBasicInfoAdd")
	public String toBasicInfoAdd(HttpServletRequest request,@PathVariable Long id,Model model){
		FXContractInfoDto fxContractInfo = contractClientService.selectDtoByPrimaryKey(id);
		if(fxContractInfo!=null){
			ResultDTO<FXSupplierInfoDto> rstDTO = supplierInfoClientService.getSupplierDetail(fxContractInfo.getSupplierId());
			model.addAttribute("fxSupplierInfo", rstDTO.getData());
		}
		model.addAttribute("fxContractInfo", fxContractInfo);
		return "contract/basic_info_add";
	}
	/**
	 * 账户信息变更新建
	 * 
	 * */
	@RequestMapping( value = "contractChange/{id}/toAccountInfoAdd")
	public String toAccountInfoAdd(HttpServletRequest request,@PathVariable Long id,Model model){
		try {
			FXContractInfoDto fxContractInfo = contractClientService.selectDtoByPrimaryKey(id);
			if(fxContractInfo!=null){
				ResultDTO<FXSupplierInfoDto> rstDTO = supplierInfoClientService.getSupplierDetail(fxContractInfo.getSupplierId());
				model.addAttribute("fxSupplierInfo", rstDTO.getData());
			}
			model.addAttribute("fxContractInfo", fxContractInfo);
			ResultDTO<Map<Object, Object>> rstDTO = bankInfoClientService.findBankInfoList();
			Map allBankMessage = rstDTO.getData();
			request.setAttribute("allBankMessage", allBankMessage);
			request.setAttribute("flag", "add");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "contract/account_info_add";
	}
	/**
	 * 结算信息变更新建
	 * 
	 * */
	@RequestMapping( value = "contractChange/{id}/toBalanceInfoAdd")
	public String toBalanceInfoAdd(HttpServletRequest request,@PathVariable Long id,Model model){
		FXContractInfoDto fxContractInfo = contractClientService.selectDtoByPrimaryKey(id);
		if(fxContractInfo!=null){
			ResultDTO<FXSupplierInfoDto> rstDTO = supplierInfoClientService.getSupplierDetail(fxContractInfo.getSupplierId());
			model.addAttribute("fxSupplierInfo", rstDTO.getData());
		}
		//设置最小最大时间
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH)+1;
		request.setAttribute("minDay", year+"-"+month+"-1");
		request.setAttribute("maxDay", year+"-"+month+"-28");
		model.addAttribute("fxContractInfo", fxContractInfo);
		return "contract/balance_info_add";
	}
	
	/**
	 * 基本信息变更编辑
	 * 
	 * */
	@RequestMapping( value = "contractChange/{id}/{tag}/toBasicInfoEdit")
	public String toBasicInfoEdit(HttpServletRequest request,@PathVariable Long id,@PathVariable String tag,Model model){
		FXContractChangeDto fxContractChange = null;
		if(id!=null){
			 fxContractChange = contractChangeClientService.selectByPrimaryKey(id);
		}
		if(fxContractChange!=null){
			Map<String, Object> params = new HashMap<String, Object>();
			ResultDTO<Map<String,Object>> rstDTO = contractClientService.getPageByParams(params,null,null,null);
			FXContractInfoDto fxContractInfo = (FXContractInfoDto) rstDTO.getData().get("list");
			if(fxContractInfo!=null){
				model.addAttribute("signOrg", fxContractInfo.getOrgName());
			}
		}
		//设置最小最大时间
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH)+1;
		request.setAttribute("minDay", year+"-"+month+"-1");
		request.setAttribute("maxDay", year+"-"+month+"-28");
		model.addAttribute("fxContractChange", fxContractChange);
		if(tag.equals("1")){
			return "contract/basic_info_change";
		}else if(tag.equals("3")){
			return "contract/account_info_change";
		}else if(tag.equals("5")){
			return "contract/balance_info_change";
		}
		return null;
	}
	
	/**
	 * 删除基本信息变更
	 * */
	@RequestMapping(value = "contractChange/delBasicInfo")
	public String delBasicInfo(Long id){
		if(id != null){
			log.info("----	 delBasicInfo id = "+id);
			contractChangeClientService.delFXContractChange(id);
		}
		return "redirect:toContractChangeList";
	}	
}

@RestController
class ContractChangeRestController {
	
	private Log log = LogFactory.getLog(ContractChangeRestController.class);
	@Autowired
	private ContractChangeService contractChangeService;
	@Autowired
	private ContractChangeClientService contractChangeClientService;
	@Autowired
	private ContractClientService contractClientService;
	@Autowired
	private SupplierInfoClientService supplierInfoClientService;
	@Autowired
	private OperationLogClientService operationLogClientService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ContractItemClientService contractItemClientService;
	@Autowired
	private BankInfoClientService bankInfoClientService;
	 
	@RequestMapping(value="restContractChange/{changPaperId}/delContractChange")
	public JSONObject delContractChange(HttpServletRequest request,@PathVariable("changPaperId") Long changPaperId){
		JSONObject retJson = new JSONObject();
		try{
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			FXContractChangeDto info = contractChangeClientService.selectDtoByPrimaryKey(changPaperId);
			info.setDeleteFlag(1);
			info.setUpdateTime(new Date());
			info.setUpdateUser(userName);
			info.setUpdateUserId(userId);
			contractChangeClientService.delContractChange(info);
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(changPaperId.toString());//存放被执行操作表的主键
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0_2.getName());//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败："+ex.getMessage());
			}
			retJson.put("success", 1);
			retJson.put("retMsg", "删除成功！");
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "删除失败！");
		}
		return retJson;
	}
	
	@RequestMapping(value="restContractChange/{changePaperId}/submitContract")
	public JSONObject submitContract(HttpServletRequest request,@PathVariable("changePaperId") Long changePaperId){
		JSONObject retJson = new JSONObject();
		try{
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			FXContractChangeDto contractChange = contractChangeClientService.selectByPrimaryKey(changePaperId);
			contractChange.setStatus(1);
			contractChange.setUpdateTime(new Date());
			contractChange.setUpdateUser(userName);
			contractChange.setUpdateUserId(userId);
			contractChangeClientService.updateContractChange(contractChange);
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(changePaperId.toString());//存放被执行操作表的主键
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0_1.getName());//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败："+ex.getMessage());
			}
			
			retJson.put("success", 1);
			retJson.put("retMsg", "提交成功！");
			return retJson;
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "提交失败！");
			return retJson;
		}
	}
	
	@RequestMapping(value="restContractChange/{changePaperId}/{changeType}/contractChangeCheck")
	public JSONObject contractChangeCheck(HttpServletRequest request,@PathVariable("changePaperId") Long changePaperId,@PathVariable("changeType") Integer changeType){
		JSONObject retJson = new JSONObject();
		try{
			
			String status = request.getParameter("status");
			String reason = request.getParameter("reason");
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			String eventType = null;
			
			FXContractChangeDto contractChange = contractChangeClientService.selectByPrimaryKey(changePaperId);
			if(contractChange.getStatus().intValue()==2||contractChange.getStatus().intValue()==3){
				retJson.put("success", 9);
				return retJson;
			}
			
			if(status!=null && "2".equals(status)){
				contractChange.setStatus(Integer.valueOf(status));
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_2.getName();
			}else if(status!=null && "3".equals(status)){
				contractChange.setStatus(Integer.valueOf(status));
				contractChange.setReason(reason);
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_3.getName();
			}
			contractChange.setUpdateTime(new Date());
			contractChange.setUpdateUser(userName);
			contractChange.setUpdateUserId(userId);
			
			List<FXContractItemChangeDto> contractItemList = contractChangeClientService.selectByChangePaperId(changePaperId);
			Map<String,Object> paramsMap = new HashMap<String,Object>();
			paramsMap.put("contractChange", contractChange);
			paramsMap.put("contractItemList", contractItemList);
			if(changeType.intValue()==3){//商品变价
				contractChangeClientService.contractChangeCheck(paramsMap, userId, userName);
			}
			if(changeType.intValue()==4){
				contractChangeClientService.contractItemStopCheck(paramsMap, userId, userName);
			}
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(changePaperId.toString());//存放被执行操作表的主键
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType(eventType);//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				if(status!=null && "3".equals(status)){
					optLog.setRemark(reason);
				}
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败："+ex.getMessage());
			}
			
			retJson.put("success", 1);
			retJson.put("retMsg", "提交成功！");
			return retJson;
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "提交失败！");
			return retJson;
		}
	}
	
	@RequestMapping(value="restContractChange/{status}/saveItemPriceChange")
	public JSONObject saveItemPriceChange(HttpServletRequest request,@PathVariable("status") Integer status){
		JSONObject retJson = new JSONObject();
		try{
			String supplierId = request.getParameter("supplierId");
			String contractId = request.getParameter("contractId");
			String contractCode = request.getParameter("contractCode");
			String availableBegin = request.getParameter("availableBegin");
			String availableEnd = request.getParameter("availableEnd");
			String remark = request.getParameter("remark");
			String attr = request.getParameter("jsonAttr");
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			List<FXContractItemChangeDto> contractItemList = new ArrayList<FXContractItemChangeDto>();
			JSONArray jsonAttr = JSONArray.parseArray(attr);
			if(jsonAttr!=null && jsonAttr.size()>0){
				for(Object obj : jsonAttr){
					JSONObject json = (JSONObject) obj;
					FXContractItemChangeDto contractItem = new FXContractItemChangeDto();
					contractItem.setItemId(json.getLong("itemId"));
					contractItem.setItemName(json.getString("itemName"));
					contractItem.setMerchantId(json.getLong("merchantId"));
					contractItem.setUnit(json.getString("unit"));
					contractItem.setNum(json.getInteger("num"));
					contractItem.setTaxPrice(json.getBigDecimal("taxPrice"));
					contractItem.setTaxRate(json.getFloat("taxRate")==null ? null : json.getFloat("taxRate")/100);
					contractItem.setPreTaxRate(json.getFloat("preTaxRate")==null ? null : json.getFloat("preTaxRate")/100);
					contractItem.setPreTaxPrice(json.getBigDecimal("preTaxPrice"));
					contractItem.setSku(json.getString("sku"));
					
					contractItem.setCreateUserId(userId);
					contractItem.setCreateUser(userName);
					contractItem.setCreateTime(new Date());
					contractItemList.add(contractItem);
				}
			}
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
			FXContractChangeDto contractChange = new FXContractChangeDto();
			contractChange.setContractId(Long.valueOf(contractId));
			contractChange.setContractCode(contractCode);
			contractChange.setSupplierId(Long.valueOf(supplierId));
			contractChange.setRemark(remark);
			contractChange.setAvailableBegin(format.parse(availableBegin));
			contractChange.setAvailableEnd(format.parse(availableEnd));
			contractChange.setChangeType(Integer.valueOf("3"));//合同商品价格变更
			
			contractChange.setStatus(status);
			contractChange.setCreateUserId(userId);
			contractChange.setCreateUser(userName);
			contractChange.setCreateTime(new Date());
			
			Map<String,Object> paramsMap = new HashMap<String,Object>();
			paramsMap.put("contractChange", contractChange);
			paramsMap.put("contractItemList", contractItemList);
			//保存数据
			Long changePaperId = contractChangeClientService.saveItemPriceChange(paramsMap);
			if(changePaperId!=null){
				//更新变更单号
				contractChangeClientService.createChangePaperCode(changePaperId);
			}
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(changePaperId.toString());
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getName());//事件类型
				if(status.intValue()==1){
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_1.getName());//事件类型
				}
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败:"+ex.getMessage());
			}
			retJson.put("success", 1);
			retJson.put("retMsg", "操作成功！");
			return retJson;
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "操作失败！");
			return retJson;
		}
	}
	
	@RequestMapping(value="restContractChange/{status}/editItemPriceChange")
	public JSONObject editItemPriceChange(HttpServletRequest request,@PathVariable("status") Integer status){
		JSONObject retJson = new JSONObject();
		try{
			String changeId = request.getParameter("changeId");
			String availableBegin = request.getParameter("availableBegin");
			String availableEnd = request.getParameter("availableEnd");
			String remark = request.getParameter("remark");
			String attr = request.getParameter("jsonAttr");
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			List<FXContractItemChangeDto> contractItemList = new ArrayList<FXContractItemChangeDto>();
			JSONArray jsonAttr = JSONArray.parseArray(attr);
			if(jsonAttr!=null && jsonAttr.size()>0){
				for(Object obj : jsonAttr){
					JSONObject json = (JSONObject) obj;
					FXContractItemChangeDto contractItem = new FXContractItemChangeDto();
					contractItem.setItemId(json.getLong("itemId"));
					contractItem.setItemName(json.getString("itemName"));
					contractItem.setMerchantId(json.getLong("merchantId"));
					contractItem.setUnit(json.getString("unit"));
					contractItem.setNum(json.getInteger("num"));
					contractItem.setTaxPrice(json.getBigDecimal("taxPrice"));
					contractItem.setTaxRate(json.getFloat("taxRate")==null ? null : json.getFloat("taxRate")/100);
					contractItem.setPreTaxRate(json.getFloat("preTaxRate")==null ? null : json.getFloat("preTaxRate")/100);
					contractItem.setPreTaxPrice(json.getBigDecimal("preTaxPrice"));
					contractItem.setSku(json.getString("sku"));
					
					contractItemList.add(contractItem);
				}
			}
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
			FXContractChangeDto contractChange = contractChangeClientService.selectByPrimaryKey(Long.valueOf(changeId));
			contractChange.setRemark(remark);
			contractChange.setAvailableBegin(format.parse(availableBegin));
			contractChange.setAvailableEnd(format.parse(availableEnd));
			contractChange.setStatus(status);
			contractChange.setUpdateTime(new Date());
			contractChange.setUpdateUser(userName);
			contractChange.setUpdateUserId(userId);
			
			Map<String,Object> paramsMap = new HashMap<String,Object>();
			paramsMap.put("contractChange", contractChange);
			paramsMap.put("contractItemList", contractItemList);
			contractChangeClientService.editItemPriceChange(paramsMap, userId, userName);
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(changeId);
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getName());//事件类型
				if(status.intValue()==1){
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_1.getName());//事件类型
				}
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败:"+ex.getMessage());
			}
			retJson.put("success", 1);
			retJson.put("retMsg", "操作成功！");
			return retJson;
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "操作失败！");
			return retJson;
		}
	}
	
	@RequestMapping(value="restContractChange/{status}/saveContractItemStop")
	public JSONObject saveContractItemStop(HttpServletRequest request,@PathVariable("status") Integer status){
		JSONObject retJson = new JSONObject();
		try{
			String supplierId = request.getParameter("supplierId");
			String contractId = request.getParameter("contractId");
			String contractCode = request.getParameter("contractCode");
			String stopDate = request.getParameter("stopDate");
			String remark = request.getParameter("remark");
			String attr = request.getParameter("jsonAttr");
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			List<FXContractItemChangeDto> contractItemList = new ArrayList<FXContractItemChangeDto>();
			JSONArray jsonAttr = JSONArray.parseArray(attr);
			if(jsonAttr!=null && jsonAttr.size()>0){
				for(Object obj : jsonAttr){
					JSONObject json = (JSONObject) obj;
					FXContractItemChangeDto contractItem = new FXContractItemChangeDto();
					contractItem.setItemId(json.getLong("itemId"));
					contractItem.setItemName(json.getString("itemName"));
					contractItem.setMerchantId(json.getLong("merchantId"));
					contractItem.setUnit(json.getString("unit"));
					contractItem.setNum(json.getInteger("num"));
					contractItem.setTaxPrice(json.getBigDecimal("taxPrice"));
					contractItem.setTaxRate(json.getFloat("taxRate")==null ? null : json.getFloat("taxRate")/100);
					contractItem.setSku(json.getString("sku"));
					
					contractItem.setCreateUserId(userId);
					contractItem.setCreateUser(userName);
					contractItem.setCreateTime(new Date());
					contractItemList.add(contractItem);
				}
			}
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(format.parse(stopDate));
			calendar.add(Calendar.DATE, -1);
			Date newStopDate = calendar.getTime();
			
			FXContractChangeDto contractChange = new FXContractChangeDto();
			contractChange.setContractId(Long.valueOf(contractId));
			contractChange.setContractCode(contractCode);
			contractChange.setSupplierId(Long.valueOf(supplierId));
			contractChange.setRemark(remark);
			contractChange.setStopDate(newStopDate);
			contractChange.setChangeType(Integer.valueOf("4"));//合同商品价格变更
			
			contractChange.setStatus(status);
			contractChange.setCreateUserId(userId);
			contractChange.setCreateUser(userName);
			contractChange.setCreateTime(new Date());
			
			Map<String,Object> paramsMap = new HashMap<String,Object>();
			paramsMap.put("contractChange", contractChange);
			paramsMap.put("contractItemList", contractItemList);
			//保存数据
			Long changePaperId = contractChangeClientService.saveItemPriceChange(paramsMap);
			if(changePaperId!=null){
				//更新变更单号
				contractChangeClientService.createChangePaperCode(changePaperId);
			}
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(changePaperId.toString());
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getName());//事件类型
				if(status.intValue()==1){
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_1.getName());//事件类型
				}
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败:"+ex.getMessage());
			}
			retJson.put("success", 1);
			retJson.put("retMsg", "操作成功！");
			return retJson;
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "操作失败！");
			return retJson;
		}
	}
	
	@RequestMapping(value="restContractChange/{status}/editContractItemStop")
	public JSONObject editContractItemStop(HttpServletRequest request,@PathVariable("status") Integer status){
		JSONObject retJson = new JSONObject();
		try{
			String changeId = request.getParameter("changeId");
			String stopDate = request.getParameter("stopDate");
			String remark = request.getParameter("remark");
			String attr = request.getParameter("jsonAttr");
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			List<FXContractItemChangeDto> contractItemList = new ArrayList<FXContractItemChangeDto>();
			JSONArray jsonAttr = JSONArray.parseArray(attr);
			if(jsonAttr!=null && jsonAttr.size()>0){
				for(Object obj : jsonAttr){
					JSONObject json = (JSONObject) obj;
					FXContractItemChangeDto contractItem = new FXContractItemChangeDto();
					contractItem.setItemId(json.getLong("itemId"));
					contractItem.setItemName(json.getString("itemName"));
					contractItem.setMerchantId(json.getLong("merchantId"));
					contractItem.setUnit(json.getString("unit"));
					contractItem.setNum(json.getInteger("num"));
					contractItem.setTaxPrice(json.getBigDecimal("taxPrice"));
					contractItem.setTaxRate(json.getFloat("taxRate")==null ? null : json.getFloat("taxRate")/100);
					contractItem.setSku(json.getString("sku"));
					
					contractItemList.add(contractItem);
				}
			}
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
			FXContractChangeDto contractChange = contractChangeClientService.selectByPrimaryKey(Long.valueOf(changeId));
			contractChange.setRemark(remark);
			contractChange.setStopDate(format.parse(stopDate));
			contractChange.setStatus(status);
			contractChange.setUpdateTime(new Date());
			contractChange.setUpdateUser(userName);
			contractChange.setUpdateUserId(userId);
			
			Map<String,Object> paramsMap = new HashMap<String,Object>();
			paramsMap.put("contractChange", contractChange);
			paramsMap.put("contractItemList", contractItemList);
			contractChangeClientService.editItemPriceChange(paramsMap, userId, userName);
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(changeId);
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getName());//事件类型
				if(status.intValue()==1){
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_1.getName());//事件类型
				}
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败:"+ex.getMessage());
			}
			retJson.put("success", 1);
			retJson.put("retMsg", "操作成功！");
			return retJson;
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "操作失败！");
			return retJson;
		}
	}
	
	/**
	 * 新建基本信息变更
	 * @param
	 * @return
	 * */
	@RequestMapping(value = "/restContractChange/saveBasicInfoChange")
	public Map<String, Object> saveBasicInfoChange(HttpServletRequest request ,FXContractChangeDto fxContractChange){
		Map<String, Object> result  = new HashMap<String, Object>();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			String contractAvailableBeginStr = request.getParameter("contractAvailableBeginStr");
			String contractAvailableEndStr = request.getParameter("contractAvailableEndStr");
			Date availableBegin = new SimpleDateFormat("yyyy-MM-dd").parse(contractAvailableBeginStr);
			Date availableEnd = new SimpleDateFormat("yyyy-MM-dd").parse(contractAvailableEndStr);
			//判断有效期是否符合
			boolean flag = contractClientService.compareContractAvailable(fxContractChange.getSupplierId(),fxContractChange.getContractId(), availableBegin, availableEnd);
			if(!flag){
				result.put("result", "error");
				return result;
			}
			fxContractChange.setChangeType(FxPurchaseStateEnum.CONTRACT_CHANGE_TYPE_1.getIndex());//基本信息变更
			fxContractChange.setCreateUserId(userId);
			fxContractChange.setCreateUser(userName);
			fxContractChange.setCreateTime(new Date());
			fxContractChange.setUpdateUserId(userId);
			fxContractChange.setUpdateUser(userName);
			fxContractChange.setUpdateTime(new Date());
			fxContractChange.setAvailableBegin(availableBegin);
			fxContractChange.setAvailableEnd(availableEnd);
			Map<String,Object> paramsMap = new HashMap<String,Object>();
			paramsMap.put("contractChange", fxContractChange);
			Long changePaperId = contractChangeClientService.saveItemPriceChange(paramsMap);
			if(changePaperId!=null){
				//更新变更单号
				contractChangeClientService.createChangePaperCode(changePaperId);
			}
			if(fxContractChange.getStatus() != null && fxContractChange.getStatus() == FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getIndex()){
				try{
					FXOperationLogDto optLog = new FXOperationLogDto();
					optLog.setBizCode(changePaperId.toString());
					optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getName());//事件类型
					optLog.setUserId(userId);
					optLog.setUserName(userName);
					optLog.setOpDate(new Date());
					optLog.setRemark(null);
					operationLogClientService.saveOpLog(optLog);
				}catch(Exception ex){
					log.error("保存日志失败:"+ex.getMessage());
				}
			}else {
				try{
					FXOperationLogDto optLog = new FXOperationLogDto();
					optLog.setBizCode(changePaperId.toString());
					optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_1.getName());//事件类型
					optLog.setUserId(userId);
					optLog.setUserName(userName);
					optLog.setOpDate(new Date());
					optLog.setRemark(null);
					operationLogClientService.saveOpLog(optLog);
				}catch(Exception ex){
					log.error("保存日志失败:"+ex.getMessage());
				}
			}
			result.put("result", "success");
			result.put("id",fxContractChange.getId());
		} catch (Exception e) {
			result.put("result", "fail");
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 新建账户信息变更
	 * @param
	 * @return
	 * */
	@RequestMapping(value = "/restContractChange/saveAccountInfoChange")
	public Map<String, Object> saveAccountInfoChange(HttpServletRequest request ,FXContractChangeDto fxContractChange,String tag){
		Map<String, Object> result  = new HashMap<String, Object>();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			fxContractChange.setChangeType(Integer.valueOf(tag));//账户信息变更
			fxContractChange.setCreateUserId(userId);
			fxContractChange.setCreateUser(userName);
			fxContractChange.setCreateTime(new Date());
			fxContractChange.setUpdateUserId(userId);
			fxContractChange.setUpdateUser(userName);
			fxContractChange.setUpdateTime(new Date());
			if(fxContractChange!=null&&fxContractChange.getPrepayRate()!=null){
				fxContractChange.setPrepayRate(new java.math.BigDecimal(fxContractChange.getPrepayRate()).divide(new java.math.BigDecimal(100)).setScale(2,java.math.BigDecimal.ROUND_UP).floatValue());
			}
			
			Map<String,Object> paramsMap = new HashMap<String,Object>();
			paramsMap.put("contractChange", fxContractChange);
			Long changePaperId = contractChangeClientService.saveItemPriceChange(paramsMap);
			if(changePaperId!=null){
				//更新变更单号
				contractChangeClientService.createChangePaperCode(changePaperId);
			}
			if(fxContractChange.getStatus() != null && fxContractChange.getStatus() == FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getIndex()){
				try{
					FXOperationLogDto optLog = new FXOperationLogDto();
					optLog.setBizCode(changePaperId.toString());
					optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getName());//事件类型
					optLog.setUserId(userId);
					optLog.setUserName(userName);
					optLog.setOpDate(new Date());
					optLog.setRemark(null);
					operationLogClientService.saveOpLog(optLog);
				}catch(Exception ex){
					log.error("保存日志失败:"+ex.getMessage());
				}
			}else {
				try{
					FXOperationLogDto optLog = new FXOperationLogDto();
					optLog.setBizCode(changePaperId.toString());
					optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_1.getName());//事件类型
					optLog.setUserId(userId);
					optLog.setUserName(userName);
					optLog.setOpDate(new Date());
					optLog.setRemark(null);
					operationLogClientService.saveOpLog(optLog);
				}catch(Exception ex){
					log.error("保存日志失败:"+ex.getMessage());
				}
			}
			result.put("result", "success");
			result.put("id",fxContractChange.getId());
		} catch (Exception e) {
			result.put("result", "fail");
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 新建结算信息变更
	 * @param
	 * @return
	 * */
	@RequestMapping(value = "/restContractChange/saveBalanceInfoChange")
	public Map<String, Object> saveBalanceInfoChange(HttpServletRequest request ,FXContractChangeDto fxContractChange){
		Map<String, Object> result  = new HashMap<String, Object>();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			fxContractChange.setChangeType(FxPurchaseStateEnum.CONTRACT_CHANGE_TYPE_5.getIndex());//结算变更
			fxContractChange.setCreateUserId(userId);
			fxContractChange.setCreateUser(userName);
			fxContractChange.setCreateTime(new Date());
			fxContractChange.setUpdateUserId(userId);
			fxContractChange.setUpdateUser(userName);
			fxContractChange.setUpdateTime(new Date());
			
			Map<String,Object> paramsMap = new HashMap<String,Object>();
			paramsMap.put("contractChange", fxContractChange);
			Long changePaperId = contractChangeClientService.saveItemPriceChange(paramsMap);
			if(changePaperId!=null){
				//更新变更单号
				contractChangeClientService.createChangePaperCode(changePaperId);
			}
			if(fxContractChange.getStatus() != null && fxContractChange.getStatus() == FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getIndex()){
				try{
					FXOperationLogDto optLog = new FXOperationLogDto();
					optLog.setBizCode(changePaperId.toString());
					optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0.getName());//事件类型
					optLog.setUserId(userId);
					optLog.setUserName(userName);
					optLog.setOpDate(new Date());
					optLog.setRemark(null);
					operationLogClientService.saveOpLog(optLog);
				}catch(Exception ex){
					log.error("保存日志失败:"+ex.getMessage());
				}
			}else {
				try{
					FXOperationLogDto optLog = new FXOperationLogDto();
					optLog.setBizCode(fxContractChange.getId().toString());
					optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_1.getName());//事件类型
					optLog.setUserId(userId);
					optLog.setUserName(userName);
					optLog.setOpDate(new Date());
					optLog.setRemark(null);
					operationLogClientService.saveOpLog(optLog);
				}catch(Exception ex){
					log.error("保存日志失败:"+ex.getMessage());
				}
			}
			result.put("result", "success");
			result.put("id",fxContractChange.getId());
		} catch (Exception e) {
			result.put("result", "fail");
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 变更审核
	 * */
	@RequestMapping(value = "/restContractChange/{id}/audit")
	public Map<String, Object>  audit(HttpServletRequest request,@PathVariable Long id,Integer status,String reason){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		FXContractChangeDto fxContractChange = new FXContractChangeDto();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			FXContractChangeDto fxContractChange2 = contractChangeClientService.selectByPrimaryKey(id);
			//如果是基本信息变更的提交或审核，判断有效期是否重合
			if(fxContractChange2.getChangeType() == FxPurchaseStateEnum.CONTRACT_CHANGE_TYPE_1.getIndex()){
				boolean flag = contractClientService.compareContractAvailable(fxContractChange2.getSupplierId(),fxContractChange2.getContractId(), fxContractChange2.getAvailableBegin(), fxContractChange2.getAvailableEnd());
				if(!flag){
					resultMap.put("result", "error");
					return resultMap;
				}
			}
			String eventType = "";
			if(status == FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0_1.getIndex()){
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_0_1.getName();
			}else if(status == FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_2.getIndex()){
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_2.getName();
			}else if(status == FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_3.getIndex()){
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_CHANGE_3.getName();
			}
			fxContractChange.setId(id);
			fxContractChange.setStatus(status);
			fxContractChange.setReason(reason);
			if(status != 1){
				fxContractChange.setAuditUser(userName);
				fxContractChange.setAuditUserId(userId);
				fxContractChange.setAuditTime(new Date());
			}
			fxContractChange.setUpdateUser(userName);
			fxContractChange.setUpdateUserId(userId);
			fxContractChange.setUpdateTime(new Date());
			contractChangeClientService.changeFXContractInfo(fxContractChange);
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(id.toString());
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType(eventType);//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				optLog.setRemark(fxContractChange.getReason());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败:"+ex.getMessage());
			}
			resultMap.put("result", "success");
		} catch (Exception e) {
			resultMap.put("result", "failed");
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/**
	 * 基本信息变更编辑保存
	 * */
	@RequestMapping( value = "/restContractChange/{id}/saveBasicInfoEdit")
	public Map<String, Object> saveBasicInfoEdit(HttpServletRequest request,@PathVariable Long id,
			Integer status,String availableBeginStr,String availableEndStr,String remark){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			FXContractChangeDto fxContractChange = null;
			if(id!=null){
				 fxContractChange = contractChangeClientService.selectByPrimaryKey(id);
			}
			Date availableBegin = new SimpleDateFormat("yyyy-MM-dd").parse(availableBeginStr);
			Date availableEnd = new SimpleDateFormat("yyyy-MM-dd").parse(availableEndStr);
			boolean flag = contractClientService.compareContractAvailable(fxContractChange.getSupplierId(),fxContractChange.getContractId(), availableBegin, availableEnd);
			if(!flag){
				resultMap.put("result", "error");
				return resultMap;
			}
			if(fxContractChange!=null){
				fxContractChange.setAvailableBegin(availableBegin);
				fxContractChange.setAvailableEnd(availableEnd);
				fxContractChange.setRemark(remark);
				fxContractChange.setStatus(status);
				fxContractChange.setUpdateUser(userName);
				fxContractChange.setUpdateUserId(userId);
				fxContractChange.setUpdateTime(new Date());
				contractChangeClientService.updateContractChange(fxContractChange);
			}
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(fxContractChange.getId().toString());
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType("编辑");//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败:"+ex.getMessage());
			}
			resultMap.put("result", "success");
		} catch (Exception e) {
			resultMap.put("result", "error");
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/**
	 * 账户信息更改编辑保存
	 * */
	@RequestMapping( value = "/restContractChange/{id}/saveAccountInfoEdit")
	public Map<String, Object> saveAccountInfoEdit(HttpServletRequest request,@PathVariable Long id,FXContractChangeDto fxContractChange){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			FXContractChangeDto fxContractChange1 = null;
			if(id!=null){
				fxContractChange1 = contractChangeClientService.selectByPrimaryKey(id);
			}
			if(fxContractChange1!=null){
				fxContractChange.setUpdateUser(userName);
				fxContractChange.setUpdateUserId(userId);
				fxContractChange.setUpdateTime(new Date());
				if(fxContractChange!=null&&fxContractChange.getPrepayRate()!=null){
					fxContractChange.setPrepayRate(new java.math.BigDecimal(fxContractChange.getPrepayRate()).divide(new java.math.BigDecimal(100)).floatValue());
				}
				contractChangeClientService.updateContractChange(fxContractChange);
			}
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(fxContractChange.getId().toString());
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_3.getIndex());//业务类型：2表示合同
				optLog.setEventType("编辑");//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败:"+ex.getMessage());
			}
			resultMap.put("result", "success");
		} catch (Exception e) {
			resultMap.put("result", "error");
			e.printStackTrace();
		}
		return resultMap;
	}
}
