package com.ule.wholesale.fxpurchase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.Bean;

import com.ule.rural.opc.sdk.filter.AuthorizationFilter;
import com.ule.wholesale.common.CommonApplication;
import com.ule.wholesale.common.util.LocalDeveloyEnv;
import com.ule.wholesale.fxpurchase.web.filter.LoginFilter;
import com.ule.wholesale.fxpurchase.web.util.UploadImgServlet;

@EnableCircuitBreaker
@EnableHystrixDashboard
@EnableFeignClients("com.ule.wholesale.fxpurchase.api.*")
//@PropertySource("classpath:selfproperties.yml")引入自定义配置文件
public class FxWebApplication extends CommonApplication{
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		
        return builder.sources(FxWebApplication.class);
	}

	public static void main(String[] args) {
        SpringApplication.run(FxWebApplication.class, args);
    }
	//图片上传的servlet
	@Bean
	public ServletRegistrationBean initUploadImgServlet() {
		ServletRegistrationBean registration = new ServletRegistrationBean(new UploadImgServlet());
		registration.addUrlMappings("/uploadImgServlet");
		return registration;
	}
	//登录验证的Filter
	@Bean
	public FilterRegistrationBean userLoginStatusFilter() {
		FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
			filterRegistrationBean.setFilter(new LoginFilter());
			filterRegistrationBean.addUrlPatterns(LocalDeveloyEnv.isDev?"":"/*");
			filterRegistrationBean.addInitParameter("exclusions", "*.js,*.gif,*.jpg,*.png,*.css,*.ico,/druid/*,/health");
		return filterRegistrationBean;
	}
	//授权的Filter
	@Bean
	public FilterRegistrationBean authorizationFilter() {
		FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
			filterRegistrationBean.setFilter(new AuthorizationFilter());
			filterRegistrationBean.addUrlPatterns(LocalDeveloyEnv.isDev?"":"/*");
			filterRegistrationBean.addInitParameter("exclusions", "*.js,*.gif,*.jpg,*.png,*.css,*.ico,/druid/*,/health");
		return filterRegistrationBean;
	}
}
