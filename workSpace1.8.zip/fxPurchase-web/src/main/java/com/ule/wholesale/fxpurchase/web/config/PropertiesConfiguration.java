package com.ule.wholesale.fxpurchase.web.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
//@ConfigurationProperties(prefix="properties")
public class PropertiesConfiguration{
	
//	private static Logger logger = LoggerFactory.getLogger(PropertiesConfiguration.class);
	public static String clientName;
	public static String clientKey;
	public static String itemAppkey;
	public static String merchantWarehouse;
	public static String itemsStorage;
	public static String warehouseInfo;
	public static String cancelPurchaseOrder;
	public static String cancelReturnOrder;
	public static String uleSelfSupport;
	public static String betaTestMerchant;
	

	@Value("${clientName}")
	public void setClientName(String clientName) {
		PropertiesConfiguration.clientName = clientName;
	}
	@Value("${clientKey}")
	public void setClientKey(String clientKey) {
		PropertiesConfiguration.clientKey = clientKey;
	}
	@Value("${itemAppkey}")
	public void setItemAppkey(String itemAppkey) {
		PropertiesConfiguration.itemAppkey = itemAppkey;
	}
	@Value("${merchantWarehouse}")
	public void setMerchantWarehouse(String merchantWarehouse) {
		PropertiesConfiguration.merchantWarehouse = merchantWarehouse;
	}
	@Value("${itemsStorage}")
	public void setItemsStorage(String itemsStorage) {
		PropertiesConfiguration.itemsStorage = itemsStorage;
	}
	@Value("${warehouseInfo}")
	public void setWarehouseInfo(String warehouseInfo) {
		PropertiesConfiguration.warehouseInfo = warehouseInfo;
	}
	@Value("${cancelPurchaseOrder}")
	public void setCancelPurchaseOrder(String cancelPurchaseOrder) {
		PropertiesConfiguration.cancelPurchaseOrder = cancelPurchaseOrder;
	}
	@Value("${cancelReturnOrder}")
	public void setCancelReturnOrder(String cancelReturnOrder) {
		PropertiesConfiguration.cancelReturnOrder = cancelReturnOrder;
	}
	@Value("${uleSelfSupport}")
	public void setUleSelfSupport(String uleSelfSupport) {
		PropertiesConfiguration.uleSelfSupport = uleSelfSupport;
	}
	@Value("${betaTestMerchant:}")
	public void setBetaTestMerchant(String betaTestMerchant) {
		PropertiesConfiguration.betaTestMerchant = betaTestMerchant;
	}
}
