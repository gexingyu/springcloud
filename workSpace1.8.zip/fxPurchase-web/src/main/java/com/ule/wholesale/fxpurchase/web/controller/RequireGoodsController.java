package com.ule.wholesale.fxpurchase.web.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.BeanUtils;
import com.ule.wholesale.common.util.HttpClientUtil;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.ContractItemClientService;
import com.ule.wholesale.fxpurchase.api.client.GoodsComparisonClientService;
import com.ule.wholesale.fxpurchase.api.client.OrderClientService;
import com.ule.wholesale.fxpurchase.api.client.RequireGoodsClientService;
import com.ule.wholesale.fxpurchase.api.client.SupplierInfoClientService;
import com.ule.wholesale.fxpurchase.api.client.WholesaleOrderClientController;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemListDto;
import com.ule.wholesale.fxpurchase.api.dto.FXPurchaseOrderDto;
import com.ule.wholesale.fxpurchase.api.dto.FXPurchaseOrderGoodsDto;
import com.ule.wholesale.fxpurchase.api.dto.FXRequireGoodsListDto;
import com.ule.wholesale.fxpurchase.api.dto.FXSupplierInfoDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderGoodsDto;
import com.ule.wholesale.fxpurchase.web.config.PropertiesConfiguration;
import com.ule.wholesale.fxpurchase.web.service.CommonService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Controller
public class RequireGoodsController {
	
	public static final Integer PAGESIZE = 10;
	private Log logger = LogFactory.getLog(RequireGoodsController.class);
	@Autowired
	private RequireGoodsClientService requireGoodsClientService;
	@Autowired
	private GoodsComparisonClientService goodsComparisonClientService;
	@Autowired
	private SupplierInfoClientService supplierInfoClientService;
	@Autowired
	private ContractItemClientService contractItemClientService;
	@Autowired
	private WholesaleOrderClientController wholesaleOrderClientController;
	@Autowired
	private OrderClientService orderClientService;
	@Autowired
	private CommonService commonService;
	
	@RequestMapping(value="require/list")
	public String toRequireList(HttpServletRequest request){
		return "require/require_list";
	}
	
	@RequestMapping(value="require/{currentPage}/{flag}/doQuery")
	public String doQuery(HttpServletRequest request, @PathVariable("currentPage")Integer currentPage, @PathVariable("flag")String flag){
		try{
			
			Map<String,Object> params = new HashMap<String,Object>();
			if(flag!=null && flag.equals("general")){
				//查询条件
				String signProvinceCode = request.getParameter("signProvinceCode");//机构省code
				if(signProvinceCode!=null && !"".equals(signProvinceCode)) params.put("signProvinceCode", signProvinceCode);
				String signCityCode = request.getParameter("signCityCode");//机构市code
				if(signCityCode!=null && !"".equals(signCityCode)) params.put("signCityCode", signCityCode);
				String signRegionCode = request.getParameter("signRegionCode");//机构县code
				if(signRegionCode!=null && !"".equals(signRegionCode)) params.put("signRegionCode", signRegionCode);
				String sourceOrderNo = request.getParameter("sourceOrderNo");//来源单号
				if(sourceOrderNo!=null && !"".equals(sourceOrderNo)) params.put("sourceOrderNo", sourceOrderNo);
				String dmsItemCode = request.getParameter("dmsItemCode");//机构商品编码
				if(dmsItemCode!=null && !"".equals(dmsItemCode)) params.put("dmsItemCode", dmsItemCode);
				String dmsItemName = request.getParameter("dmsItemName");//机构商品名称
				if(dmsItemName!=null && !"".equals(dmsItemName)) params.put("dmsItemName", dmsItemName);
				String state = request.getParameter("state");//状态
				if(state!=null && !"".equals(state)) params.put("state", state);
				String itemCode = request.getParameter("itemCode");//商品编码
				if(itemCode!=null && !"".equals(itemCode)) params.put("itemCode", itemCode);
				String itemName = request.getParameter("itemName");//商品名称
				if(itemName!=null && !"".equals(itemName)) params.put("itemName", itemName);
				String bizOrderType = request.getParameter("bizOrderType");//业务单据类型，1采购订单2批发单3寄售单
				if(bizOrderType!=null && !"".equals(bizOrderType)) params.put("bizOrderType", bizOrderType);
				String bizOrderNo = request.getParameter("bizOrderNo");//业务单据号
				if(bizOrderNo!=null && !"".equals(bizOrderNo)) params.put("bizOrderNo", bizOrderNo);
			}else if(flag!=null && flag.equals("fast")){
				//标签查询
				String stateStr = request.getParameter("stateStr");//状态
				String[] stateAttr = null;
				if(stateStr!=null && !"".equals(stateStr)){
					if(stateStr.indexOf(",")==-1){
						stateAttr = new String[]{stateStr};
					}else{
						stateAttr = stateStr.split(",");
					}
				}
				if(stateAttr!=null && stateAttr.length>0){
					params.put("stateAttr", stateAttr);
				}
			}
			
			ResultDTO<Map<String,Object>> rstDTO = requireGoodsClientService.getPageByParams(params, currentPage, PAGESIZE, "create_time desc");
			request.setAttribute("retList", rstDTO.getData().get("list"));
			request.setAttribute("currentPage", rstDTO.getData().get("pageNum"));
			request.setAttribute("totalPage", rstDTO.getData().get("pages"));
		}catch(Exception e){
			logger.error("error", e);
		}
		return "require/require_list_record";
	}
	
	@RequestMapping("require/downloadTemplate")
	public String downloadTemplate( HttpServletRequest request, HttpServletResponse response) {
		OutputStream os = null;
		FileInputStream fs = null;
		try {
			String FileName = URLDecoder.decode(request.getParameter("fileName"), "utf-8");
			System.out.println("FileName===" + FileName);
			String baseDir = request.getRealPath("");
			String filePath = baseDir + "/template/" + FileName;
			File tempFile = new File(filePath);
			if (!tempFile.exists()){
				System.out.println("filePath=" + filePath + " not exists.");
				return null;
			}
			String agent = request.getHeader("User-Agent");
			boolean isFireFox = (agent != null && agent.toLowerCase().indexOf("firefox") != -1); 
			if (isFireFox) { 
				FileName = new String(FileName.getBytes("UTF-8"), "ISO8859-1"); 
			} else { 
				FileName = URLEncoder.encode(String.valueOf(FileName), "utf-8");
			}
			os = response.getOutputStream();
			response.reset();
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-disposition", "attachment; filename=" + FileName);
			fs = new FileInputStream(filePath);
			byte[] bytes = new byte[1024];
			int c;
			while ((c = fs.read(bytes)) != -1) {
				os.write(bytes, 0, c);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (fs != null)
				fs.close();
				if (os != null) {
				os.flush();
				os.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return null;
	}
	
	@RequestMapping("require/toImportPage")
	public String toImportPage(){
		return "require/importPage";
	}
	
	@RequestMapping("require/fileImport")
	@ResponseBody
	public JSONObject fileImport(HttpServletRequest request, @RequestParam("fileUrl") MultipartFile fileUrl){
		JSONObject retJson = new JSONObject();
		try{
			//获取上传文件后缀
			String postfix = fileUrl.getOriginalFilename().substring(fileUrl.getOriginalFilename().lastIndexOf(".")
					,fileUrl.getOriginalFilename().length());
			if(postfix==null || !(".xls".equals(postfix) || ".xlsx".equals(postfix))){
				retJson.put("success", 0);
				retJson.put("retMsg", "上传的文件类型不正确！只能上传excel");
				return retJson;
			}
			InputStream is = fileUrl.getInputStream();
			List<FXRequireGoodsListDto> rqGoodsList = null;
			try{
				//读取excel里的信息
				rqGoodsList = commonService.readExcel(is, request);
			}catch(Exception e){
				retJson.put("success", 0);
				retJson.put("retMsg", e.getMessage());
				return retJson;
			}
			if(rqGoodsList!=null && rqGoodsList.size()>0){
//				ExecutorService executorService = Executors.newFixedThreadPool(10);
//				for(final FXRequireGoodsListDto rqGoodsDto : rqGoodsList){
//					executorService.execute(new Runnable() {
//						public void run() {
//							logger.info(Thread.currentThread().getName()+"被调用了");
//							try {
//								requireGoodsClientService.saveRequireGoods(rqGoodsDto);
//							} catch (Exception e) {
//								logger.error(e.getMessage());
//							}
//						}
//					});
//				}
				List<String> ingoreData = requireGoodsClientService.saveRequireGoodsOfBatch(rqGoodsList);
				if(ingoreData!=null && ingoreData.size()>0){
					retJson.put("success", 0);
					retJson.put("retMsg", ingoreData.toString());
					return retJson;
				}
			}
			
			retJson.put("success", 1);
			retJson.put("retMsg", "操作成功！");
			return retJson;
		}catch(Exception e){
			logger.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "系统出错！");
			return retJson;
		}
	}
	
	@RequestMapping("require/doCancel")
	@ResponseBody
	public JSONObject doCancel(HttpServletRequest request){
		JSONObject retJson = new JSONObject();
		try{
			String requireIds = request.getParameter("requireIds");
			logger.info("requireIds="+requireIds);
			if(requireIds==null || "".equals(requireIds)){
				throw new Exception("requireIds is null!");
			}
			if(requireIds.indexOf(",")==-1){
				Long requireId = Long.valueOf(requireIds);
				FXRequireGoodsListDto rqGoods = requireGoodsClientService.selectByPrimaryKey(requireId);
				if(rqGoods.getState().intValue()==FxPurchaseStateEnum.REQUIRE_STATUS_0.getIndex()){//未分配
					rqGoods.setState(FxPurchaseStateEnum.REQUIRE_STATUS_3.getIndex());//已作废
					rqGoods.setCancelTime(new Date());
					requireGoodsClientService.updateRequireGoods(rqGoods);
				}
			}else{
				List<FXRequireGoodsListDto> rqGoodsList = new ArrayList<FXRequireGoodsListDto>();
				for(int i=0;i<requireIds.split(",").length;i++){
					Long requireId = Long.valueOf(requireIds.split(",")[i]);
					FXRequireGoodsListDto rqGoods = requireGoodsClientService.selectByPrimaryKey(requireId);
					if(rqGoods.getState().intValue()==FxPurchaseStateEnum.REQUIRE_STATUS_0.getIndex()){//未分配
						rqGoods.setState(FxPurchaseStateEnum.REQUIRE_STATUS_3.getIndex());//已作废
						rqGoods.setCancelTime(new Date());
						rqGoodsList.add(rqGoods);
					}
				}
				requireGoodsClientService.updateBatchRequireGoods(rqGoodsList);
			}
			
			retJson.put("success", 1);
			retJson.put("retMsg", "操作成功！");
			return retJson;
		}catch(Exception e){
			logger.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "系统出错！");
			return retJson;
		}
	}
	
	@RequestMapping("require/toAllocationPage/{flag}")
	public String toAllocationPage(HttpServletRequest request, @PathVariable("flag")String flag){
		try{
			//要货清单id
			String requireIds = request.getParameter("requireIds");
			logger.info("flag="+flag+",requireIds="+requireIds);
			if(requireIds==null || "".equals(requireIds)){
				throw new Exception("requireIds=========="+requireIds);
			}
			request.setAttribute("requireIds", requireIds);
			
			List<Long> itemIdList = new ArrayList<Long>();
			String[] attr = requireIds.split(",");
			for(String str : attr){
				Long requireId = Long.valueOf(str);
				FXRequireGoodsListDto rqGoods = requireGoodsClientService.selectByPrimaryKey(requireId);
				if(rqGoods.getItemCode()!=null && !"".equals(rqGoods.getItemCode())){//存在对照商品
					itemIdList.add(Long.valueOf(rqGoods.getItemCode()));
				}
			}
			logger.info("itemIdList="+itemIdList.toString());
			if("new".equals(flag)){//获取供应商
				List<FXSupplierInfoDto> supplierList = supplierInfoClientService.getSupplierInfoByItemId(itemIdList);
				logger.info("supplierList="+supplierList.toString());
				request.setAttribute("supplierList", supplierList);
			}else if("now".equals(flag)){//获取出货仓库
				List<Long> merchantIdList = contractItemClientService.getMerchantIdsByItemIds(itemIdList);
				List<Map<String,Object>> warehouseList = new ArrayList<Map<String,Object>>();
				if(merchantIdList!=null && merchantIdList.size()>0){
					for(Long merchantId : merchantIdList){
						Map<String,Object> paramMap = new HashMap<String, Object>();
						paramMap.put("merchantOnlyId",merchantId);
						String result = HttpClientUtil.sendPost(PropertiesConfiguration.merchantWarehouse,null,paramMap, null);
						JSONArray jsonAttr = JSONArray.parseArray(JSONObject.parseObject(result).get("warehouseList").toString());
						for(int i=0; i<jsonAttr.size(); i++){
							JSONObject obj = JSONObject.parseObject(jsonAttr.get(i).toString());
							Map<String,Object> map = new HashMap<String,Object>();
							map.put("merchantId", merchantId);
							map.put("warehouseId",obj.get("warehouseId"));
							map.put("warehouseName",obj.get("warehouseName"));
							warehouseList.add(map);
						}
					}
				}
				logger.info("warehouseList="+warehouseList.toString());
				request.setAttribute("warehouseList", warehouseList);
			}
			
		}catch(Exception e){
			logger.error("error", e);
		}
		logger.info("flag=============="+flag);
		request.setAttribute("flag", flag);
		return "require/allocationPage";
	}
	
	@RequestMapping("require/doAllocation")
	@ResponseBody
	public JSONObject doAllocation(HttpServletRequest request){
		JSONObject retJson = new JSONObject();
		try{
			String flag = request.getParameter("flag");
			if("new".equals(flag)){//新采库存
				Long supplierId = request.getParameter("supplierId")==null ? null : Long.valueOf(request.getParameter("supplierId"));
				String supplierName = request.getParameter("supplierName");
				String requireIds = request.getParameter("requireIds");
				logger.info("supplierId="+supplierId+",requireIds="+requireIds+",flag="+flag);
				if(requireIds==null || "".equals(requireIds)){
					throw new Exception("requireIds======="+requireIds);
				}
				
				List<String> errorList = new ArrayList<String>();
				String[] attr = requireIds.split(",");
				for(String str : attr){
					Long requireId = Long.valueOf(str);
					FXRequireGoodsListDto rqGoods = requireGoodsClientService.selectByPrimaryKey(requireId);
					if(rqGoods.getItemCode()!=null && !"".equals(rqGoods.getItemCode())){
						//根据itemCode查询商品是否在供应商合同中
						Long itemId = rqGoods.getItemCode()==null ? null : Long.valueOf(rqGoods.getItemCode());
						Map<String,Object> map = contractItemClientService.selectBySupplierIdAndItemId(supplierId, itemId);
						if(map.size()>0){
							for(String key : map.keySet()){
								Long merchantId = Long.valueOf(key);
								List<Map> retList = (List<Map>) map.get(key);
								
								FXPurchaseOrderDto order = new FXPurchaseOrderDto();
								order.setSourceOrderNo(rqGoods.getSourceOrderNo());
								order.setSourceOrderType(1);
								order.setVersion(0);
								order.setSupplierId(supplierId);
								order.setSupplierName(supplierName);
								order.setMerchantId(merchantId);
//							order.setMerchantName(merchantName);
								//根据merchantId查询仓库信息
								Map<String,Object> paramMap = new HashMap<String, Object>();
								paramMap.put("merchantOnlyId",merchantId);
								String result = HttpClientUtil.sendPost(PropertiesConfiguration.merchantWarehouse,null,paramMap, null);
								JSONObject obj = JSONObject.parseObject(JSONArray.parseArray(JSONObject.parseObject(result).get("warehouseList").toString()).get(0).toString());
								order.setReceivingWarehouseId(obj.getLong("warehouseId"));
								order.setReceivingWarehouse(obj.getString("warehouseName"));
								order.setState(0);
								
								Integer orderGoodsNum = 0;
								Double orderAmt = 0.00;
								List<FXPurchaseOrderGoodsDto> itemList = new ArrayList<FXPurchaseOrderGoodsDto>();
								for(Map lMap : retList){
									FXContractItemListDto item = new FXContractItemListDto();
									BeanUtils.copyProperties(item, lMap);
									FXPurchaseOrderGoodsDto goods = new FXPurchaseOrderGoodsDto();
									goods.setBoxNum(item.getNum());
									goods.setItemId(item.getItemId());
									goods.setItemName(item.getItemName());
									goods.setPlanAmt(rqGoods.getAmount());
									goods.setPlanNum(rqGoods.getNumber());
									goods.setTaxRate(item.getTaxPrice());
									goods.setUnit(item.getUnit());
									goods.setUnitPrice(rqGoods.getDmsItemPrice());
									orderGoodsNum += rqGoods.getNumber();
									orderAmt += rqGoods.getAmount().doubleValue();
									itemList.add(goods);
								}
								order.setGoodsNum(orderGoodsNum);
								order.setOrderAmt(new BigDecimal(orderAmt));
								order.setDeleteFlag(0);
								order.setCreateTime(new Date());
								order.setCreateUserId(OpcSDKTools.getUserOnlyId(request));
								order.setCreateUser(OpcSDKTools.getUserName(request));
								
								ChinaPostOrgunit orgUnit = OpcSDKTools.getChinapostOrgunit(request);
								order.setOrgName(orgUnit.getName());
								Integer level = OpcSDKTools.getUserLevel(request);
								if(level > 0){
									if(level == 1){
										order.setProvinceOrgCode(orgUnit.getCode());
									}else if(level == 2){
										order.setProvinceOrgCode(orgUnit.getProvinceCode());
										order.setCityOrgCode(orgUnit.getCode());
									}else if(level == 3){
										order.setProvinceOrgCode(orgUnit.getProvinceCode());
										order.setCityOrgCode(orgUnit.getParentCode());
										order.setRegionOrgCode(orgUnit.getCode());
									}
								}
								order.setOrgLevel(level+"");
								
								//生成采购订单并更新要货清单状态
								Map<String,Object> orderMap = new HashMap<String,Object>();
								orderMap.put("order", order);
								orderMap.put("itemList", itemList);
								ResultDTO<FXPurchaseOrderDto> rstDTO = orderClientService.saveOrderInfo(orderMap);
								if("0".equals(rstDTO.getCode())){
									rqGoods.setState(1);//状态1已分配
									rqGoods.setBizOrderType(1);//类型1采购订单
									rqGoods.setBizOrderId(rstDTO.getData().getId());//采购订单ID
									rqGoods.setDistributeTime(new Date());//分配时间
									rqGoods.setBizOrderNo(rstDTO.getData().getOrderNo());
									requireGoodsClientService.updateRequireGoods(rqGoods);
								}
							}
						}else{
							errorList.add(rqGoods.getItemCode()+"商品不在供应商"+supplierId+"的合同中！");
						}
					}
				}
				
				if(errorList.size()>0){
					retJson.put("success", 0);
					retJson.put("retMsg", errorList.toString());
					return retJson;
				}
			}else if("now".equals(flag)){//现有库存
				String requireIds = request.getParameter("requireIds");
				String merchantId = request.getParameter("merchantId");
				String warehouseId = request.getParameter("warehouseId");
				String warehouseName = request.getParameter("warehouseName");
				logger.info("requireIds="+requireIds+",merchantId="+merchantId+",warehouseId="+warehouseId+",warehouseName="+warehouseName);
				
				if(requireIds!=null && !"".equals(requireIds)){
					String[] attr = requireIds.split(",");
					for(String str : attr){
						Long requireId = Long.valueOf(str);
						FXRequireGoodsListDto rqGoods = requireGoodsClientService.selectByPrimaryKey(requireId);
						if(rqGoods.getItemCode()!=null && !"".equals(rqGoods.getItemCode())){//存在商品对照
							FXWholesaleOrderDto order = new FXWholesaleOrderDto();
							order.setVersion(0);
							order.setSourceOrderType(FxPurchaseStateEnum.SOURCE_TYPE_1.getIndex());
							order.setSignProvinceCode(rqGoods.getOrderOrgCode());
							order.setSignProvinceName(rqGoods.getOrderOrgName());
							order.setMerchantId(Long.valueOf(merchantId));
//							order.setMerchantName(merchantName);
							order.setWarehouseId(Long.valueOf(warehouseId));
							order.setWarehouseName(warehouseName);
							order.setState(0);
							ChinaPostOrgunit orgUnit;
							try {
								orgUnit = OpcSDKTools.getChinapostOrgunit(request);
								order.setOrgName(orgUnit.getName());
								Integer level = OpcSDKTools.getUserLevel(request);
								if(level > 0){
									if(level == 1){
										order.setProvinceOrgCode(orgUnit.getCode());
									}else if(level == 2){
										order.setProvinceOrgCode(orgUnit.getProvinceCode());
										order.setCityOrgCode(orgUnit.getCode());
									}else if(level == 3){
										order.setProvinceOrgCode(orgUnit.getProvinceCode());
										order.setCityOrgCode(orgUnit.getParentCode());
										order.setRegionOrgCode(orgUnit.getCode());
									}
								}
								order.setOrgLevel(level+"");
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							order.setCreateTime(new Date());
							try {
								order.setCreateUserId(OpcSDKTools.getUserOnlyId(request));
								order.setCreateUser(OpcSDKTools.getUserName(request));
							} catch (Exception e) {
								e.printStackTrace();
							}
							
							List<FXWholesaleOrderGoodsDto> goodsList = new ArrayList<FXWholesaleOrderGoodsDto>();
							Integer orderGoodsNum = 0;
							Double orderAmt = 0.00;
							//更加itemcode查询合同商品
							List<FXContractItemListDto> itemList = contractItemClientService.selectByItemId(Long.valueOf(rqGoods.getItemCode()));
							if(itemList!=null && itemList.size()>0){
								
								for(FXContractItemListDto item : itemList){
									FXWholesaleOrderGoodsDto goods = new FXWholesaleOrderGoodsDto();
									goods.setBoxNum(item.getNum());
									goods.setItemId(item.getItemId());
									goods.setItemName(item.getItemName());
									goods.setTaxRate(new BigDecimal(item.getTaxRate()));
									goods.setUnit(item.getUnit());
									goods.setUnitPrice(item.getTaxPrice());
									orderGoodsNum += rqGoods.getNumber();
									orderAmt += rqGoods.getAmount().doubleValue();
									goodsList.add(goods);
								}
							}
							order.setPlanNum(orderGoodsNum);
							order.setPlanAmt(new BigDecimal(orderAmt));
							//保存订单和订单商品
							Map<String,Object> params = new HashMap<String, Object>();
							params.put("order", order);
							params.put("itemList", itemList);
							ResultDTO<FXWholesaleOrderDto> rstDTO = wholesaleOrderClientController.saveOrderInfo(params);
							if("0000".equals(rstDTO.getCode())){
								rqGoods.setState(1);//状态1已分配
								rqGoods.setBizOrderType(2);//类型2批发单
								rqGoods.setBizOrderId(rstDTO.getData().getId());//采购订单ID
								rqGoods.setDistributeTime(new Date());//分配时间
								rqGoods.setBizOrderNo(rstDTO.getData().getOrderNo());
								requireGoodsClientService.updateRequireGoods(rqGoods);
							}
						}
					}
				}
			}
			
			retJson.put("success", 1);
			retJson.put("retMsg", "操作成功！");
			return retJson;
		}catch(Exception e){
			logger.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "系统出错！");
			return retJson;
		}
	}
	
}

