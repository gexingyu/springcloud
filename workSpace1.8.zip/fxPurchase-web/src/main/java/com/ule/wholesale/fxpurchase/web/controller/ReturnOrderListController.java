package com.ule.wholesale.fxpurchase.web.controller;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.OperationLogClientService;
import com.ule.wholesale.fxpurchase.api.client.OrderClientService;
import com.ule.wholesale.fxpurchase.api.client.ReturnOrderClientService;
import com.ule.wholesale.fxpurchase.api.client.SupplierInfoClientService;
import com.ule.wholesale.fxpurchase.api.dto.FXPurchaseOrderGoodsDto;
import com.ule.wholesale.fxpurchase.api.dto.FXReturnOrderDto;
import com.ule.wholesale.fxpurchase.api.dto.FXReturnOrderGoodsDto;
import com.ule.wholesale.fxpurchase.api.dto.FXSupplierInfoDto;
import com.ule.wholesale.fxpurchase.web.service.CommonService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;



@Controller
public class ReturnOrderListController {
	private static Log logger = LogFactory.getLog(ReturnOrderListController.class);  
	@Autowired
	private SupplierInfoClientService supplierService;
	@Autowired
	OrderClientService purchaseOrderService;
	@Autowired
	CommonService commonService;
	@Autowired
	ReturnOrderClientService orderService;
	@Autowired
	OperationLogClientService operationLogService;
	//主页面
	@RequestMapping("/returnOrder/list")
	public String list(HttpServletRequest request,Model model){
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
			//设置权限
			commonService.showROButton(request);
		} catch (Exception e) {
			logger.error("list============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		return "returnOrder/returnOrderList";
	}
	@RequestMapping(value = "/returnOrder/listRecord2",method=RequestMethod.POST)
	public String orderListRecordState(HttpServletRequest request,Integer state,Integer pageNum,Integer pageSize,Model molde){
		pageNum = (pageNum == null || pageNum == 0) ? 1 : pageNum;
		pageSize = (pageSize == null || pageSize < 1) ? 10 :pageSize;
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("state", state);
		try {
			Integer level = OpcSDKTools.getUserLevel(request);
			params.put("orgLevel",level);
			if(level != 0){
				ChinaPostOrgunit orgUnit = OpcSDKTools.getChinapostOrgunit(request);
				if(level == 1 )params.put("provinceOrgCode",orgUnit.getCode());
				if(level == 2 )params.put("cityOrgCode",orgUnit.getCode());
				if(level == 3 )params.put("regionOrgCode",orgUnit.getCode());
			}
		} catch (Exception e) {
			logger.error("orderListRecordState >>>>获取用户机构信息异常，"+e.getMessage());
		}
		ResultDTO<PageInfo<FXReturnOrderDto>> pageInfo = orderService.findReturnOrderList(params, pageNum,pageSize);
		molde.addAttribute("orderList", pageInfo.getData().getList());
		molde.addAttribute("currentPage", pageInfo.getData().getPageNum());
		molde.addAttribute("totalPage", pageInfo.getData().getPages());
		
		return "returnOrder/orderListRecord";
	}
	@RequestMapping(value = "/returnOrder/listRecord",method=RequestMethod.POST)
	public String orderListRecord(HttpServletRequest request,FXReturnOrderDto order,String startTime,String endTime,String whStartTime,String whEndTime,Integer pageNum,Integer pageSize,Model molde){
		pageNum = (pageNum == null || pageNum == 0) ? 1 : pageNum;
		pageSize = (pageSize == null || pageSize < 1) ? 10 :pageSize;
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("orderNo", (order.getOrderNo()== null || order.getOrderNo().trim().equals("")) ? null : order.getOrderNo());
		params.put("supplierId", order.getSupplierId());
		params.put("supplierName", (order.getSupplierName() == null || order.getSupplierName().trim().equals("")) ? null : order.getSupplierName());
		params.put("state", order.getState());
		params.put("merchantId", order.getMerchantId());
		params.put("receivingWarehouseId", order.getReceivingWarehouseId());
		params.put("provinceOrgCode", order.getProvinceOrgCode());
		params.put("cityOrgCode", order.getCityOrgCode());
		params.put("regionOrgCode", order.getRegionOrgCode());
		params.put("startTime", "".equals(startTime) ? null : startTime );
		params.put("endTime", "".equals(endTime)?null:endTime);
		params.put("whStartTime", "".equals(whStartTime)?null:whStartTime);
		params.put("whEndTime", "".equals(whEndTime)?null:whEndTime);
		try {
			Integer level = OpcSDKTools.getUserLevel(request);
			params.put("orgLevel",level);
			if(level != 0){
				ChinaPostOrgunit orgUnit = OpcSDKTools.getChinapostOrgunit(request);
				if(level == 1 )params.put("provinceOrgCode",orgUnit.getCode());
				if(level == 2 )params.put("cityOrgCode",orgUnit.getCode());
				if(level == 3 )params.put("regionOrgCode",orgUnit.getCode());
			}
		} catch (Exception e) {
			logger.error("orderListRecord >>>>获取用户机构信息异常，"+e.getMessage());
		}
		ResultDTO<PageInfo<FXReturnOrderDto>> pageInfo = orderService.findReturnOrderList(params, pageNum,pageSize);
		molde.addAttribute("orderList", pageInfo.getData().getList());
		molde.addAttribute("currentPage", pageInfo.getData().getPageNum());
		molde.addAttribute("totalPage", pageInfo.getData().getPages());
		
		return "returnOrder/orderListRecord";
	}
	//退货单详情
	@RequestMapping("/returnOrder/{orderId}/detail")
	public String orderDetail(HttpServletRequest request,@PathVariable("orderId")Long orderId,Model model){
		try{
			ResultDTO<Map<String, Object>> orderDetail = orderService.orderDetail(orderId);
			FXReturnOrderDto order = new FXReturnOrderDto();
			try{
				Map<String,Object> objMap = (Map<String,Object>)orderDetail.getData().get("order");
				com.ule.wholesale.common.util.BeanUtils.copyProperties(order, objMap);
			}catch(Exception e){
				logger.error("BeanUtils.copyProperties(order, orderDetail.getData().get(\"order\")); error:"+e.getMessage());
				e.printStackTrace();
			}
			model.addAttribute("order", order);
			model.addAttribute("itemList", orderDetail.getData().get("itemList"));
			model.addAttribute("opLogList", operationLogService.getOperationLogList(order.getOrderNo(), FxPurchaseStateEnum.OPLOG_TYPE_5.getIndex()));
			//设置权限
			commonService.showROButton(request);
			return "returnOrder/returnOrderDetail";
		}catch(Exception e){
			logger.error("error", e);
		}
		return null;
	}
	@RequestMapping("/returnOrder/{orderId}/edit")
	public String editOrder(HttpServletRequest request,@PathVariable("orderId")Long orderId,Model model){
		FXSupplierInfoDto fxSupplierInfo = new FXSupplierInfoDto();
		fxSupplierInfo.setStatus(2);
		try {
			String orgCode = OpcSDKTools.getOrgunitCode(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxSupplierInfo.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxSupplierInfo.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxSupplierInfo.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxSupplierInfo.setRegionOrgCode(orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		ResultDTO<Map<String, Object>> pageInfo = supplierService.getSupplierListByPage(fxSupplierInfo, 1, Integer.MAX_VALUE, null);
		model.addAttribute("supplierList",pageInfo.getData().get("supplierList"));
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
		} catch (Exception e) {
			logger.error("editOrder============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		
		ResultDTO<Map<String, Object>> orderDetail = orderService.orderDetail(orderId);
		model.addAttribute("order", orderDetail.getData().get("order"));
		model.addAttribute("itemList", orderDetail.getData().get("itemList"));
		
		return "returnOrder/returnOrderAdd";
	}
	//新增采购退货单页面
	@RequestMapping("/returnOrder/create")
	public String createOrder(HttpServletRequest request,Model model){
		FXSupplierInfoDto fxSupplierInfo = new FXSupplierInfoDto();
		fxSupplierInfo.setStatus(2);
		try {
			String orgCode = OpcSDKTools.getOrgunitCode(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxSupplierInfo.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxSupplierInfo.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxSupplierInfo.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxSupplierInfo.setRegionOrgCode(orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		ResultDTO<Map<String, Object>> pageInfo = supplierService.getSupplierListByPage(fxSupplierInfo, 1, Integer.MAX_VALUE, null);
		model.addAttribute("supplierList",pageInfo.getData().get("supplierList"));
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
		} catch (Exception e) {
			logger.error("createOrder============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		return "returnOrder/returnOrderAdd";
	}
	/**
	 * 退货定单添加的2年内的已收货的采购订单对应的供应商的商品
	 * @param supplierId
	 * @param pageNum
	 * @param pageSize
	 * @param itemId
	 * @param itemName
	 * @param flag
	 * @param index
	 * @param model
	 * @return
	 */
	@RequestMapping("/returnOrder/addGoods/{supplierId}")
	public String addgoods(@PathVariable("supplierId")Long supplierId,Long merchantId,Long whId,Integer pageNum,Integer pageSize,Long itemId,String itemName,String flag,String index,Model model){
		pageNum = (pageNum == null || pageNum < 0) ? 1 : pageNum;
		pageSize = (pageSize == null || pageSize < 1 ) ? 10 : pageSize;
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("supplierId", supplierId);
		params.put("merchantId", merchantId);
		params.put("itemId", null);
		ResultDTO<PageInfo<FXPurchaseOrderGoodsDto>> pageInfo = purchaseOrderService.findPurchaseItemList(params, pageNum, pageSize);
		List<FXPurchaseOrderGoodsDto> itemList = pageInfo.getData().getList();
		List<Long> itemIdList = new ArrayList<Long>();
		for(FXPurchaseOrderGoodsDto item : itemList){
			itemIdList.add(item.getItemId());
		}
		if(itemList.size() > 0){
			String itemStorage = commonService.getMerchantItemStorage(merchantId, whId, itemIdList);
			JSONObject json = (JSONObject) JSONObject.parse(itemStorage);
			if(json != null && json.get("code") != null && "0000".equals(json.getString("code"))){
				
				List<Map<String,Object>> isList = (List<Map<String, Object>>) json.get("inventoryList");
				Map<Long,Integer> itemStorageMap = new HashMap<Long, Integer>();
				for(Map<String,Object> m : isList){
					itemStorageMap.put(Long.valueOf(m.get("itemId").toString()), Integer.valueOf(m.get("quantity").toString()));
				}
				model.addAttribute("itemStorage", itemStorageMap);
			}
		}
		model.addAttribute("supplierId", supplierId);
		model.addAttribute("merchantId", merchantId);
		model.addAttribute("whId", whId);
		model.addAttribute("itemId", itemId);
		model.addAttribute("itemName", itemName);
		model.addAttribute("flag", flag);
		model.addAttribute("index", index);
		model.addAttribute("itemList", itemList);
		model.addAttribute("currentPage", pageInfo.getData().getPageNum());
		model.addAttribute("totalPage", pageInfo.getData().getPages());
		return "returnOrder/addGoods";
	}
	//批量增加商品页面
	@RequestMapping("/returnOrder/addgoods")
	public String returnOrderAddgoods(){
		return "returnOrder/returnOrderAddgoods";
	}
	@RequestMapping("/returnOrder/edit")
	//编辑页面
	public String returnOrderEdit(){
		return "returnOrder/returnOrderEdit";
	}
	
	
	@RestController
	class ReturnOrderListRestController{
		
		@Autowired
		private ReturnOrderClientService returnOrderService;
		
		@RequestMapping("/returnOrder/addGoods/{supplierId}/{itemId}")
		public FXPurchaseOrderGoodsDto addgoods(@PathVariable("supplierId")Long supplierId,@PathVariable("itemId")Long itemId){
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("supplierId", supplierId);
			params.put("itemId", itemId);
			ResultDTO<PageInfo<FXPurchaseOrderGoodsDto>> pageInfo = purchaseOrderService.findPurchaseItemList(params, 1, 10);
			List<FXPurchaseOrderGoodsDto> itemList = pageInfo.getData().getList();
			return (itemList == null || itemList.size() == 0) ? null : itemList.get(0);
		}
		
		@RequestMapping("/returnOrder/save")
		//alert(supplierId+"="+supplierName+"="+merchantId+"="+merchantName+"="+warehouseId+"="+warehouseName+"="+planSendTime+"="+preAmt+"="+orderRemark+"="+itemInfo);
		public Object saveOrder(HttpServletRequest request,Long orderId,String orderNo,Long supplierId,String supplierName,Long merchantId,String merchantName,Long warehouseId,String warehouseName,String planDeliveryTime,String orderRemark,Integer status,String itemInfo,Integer version){
			JSONObject rstJson = new JSONObject();
			FXReturnOrderDto order = new FXReturnOrderDto();
			if(orderId != null){
				ResultDTO<FXReturnOrderDto> rstDto = orderService.fingdOrderByOrderId(orderId);
				order = rstDto.getData();
				order.setVersion(version);
			}else{
				order.setVersion(0);
			}
			order.setId(orderId);
			order.setSupplierId(supplierId);
			order.setSupplierName(supplierName);
			order.setMerchantId(merchantId);
			order.setMerchantName(merchantName);
			order.setReceivingWarehouseId(warehouseId);
			order.setReceivingWarehouse(warehouseName);
			order.setState(status);
			order.setRemark(orderRemark);
			ChinaPostOrgunit orgUnit;
			try {
				orgUnit = OpcSDKTools.getChinapostOrgunit(request);
				order.setOrgName(orgUnit.getName());
				Integer level = OpcSDKTools.getUserLevel(request);
				if(level > 0){
					if(level == 1){
						order.setProvinceOrgCode(orgUnit.getCode());
					}else if(level == 2){
						order.setProvinceOrgCode(orgUnit.getProvinceCode());
						order.setCityOrgCode(orgUnit.getCode());
					}else if(level == 3){
						order.setProvinceOrgCode(orgUnit.getProvinceCode());
						order.setCityOrgCode(orgUnit.getParentCode());
						order.setRegionOrgCode(orgUnit.getCode());
					}
				}
				order.setOrgLevel(level+"");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			if(planDeliveryTime != null && !"".equals(planDeliveryTime.trim())){
				try {
					order.setPlanReturnTime(sdf.parse(planDeliveryTime));
				} catch (ParseException e) {
					order.setPlanReturnTime(new Date());
				}
			}
			if(orderId == null){
				order.setCreateTime(new Date());
				try {
					order.setCreateUserId(OpcSDKTools.getUserOnlyId(request));
					order.setCreateUser(OpcSDKTools.getUserName(request));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else{
				order.setUpdateTime(new Date());
				try {
					order.setUpdateUserId(OpcSDKTools.getUserOnlyId(request));
					order.setUpdateUser(OpcSDKTools.getUserName(request));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			logger.info("遍历itemList");
			JSONArray itemJsonList = JSONArray.parseArray(itemInfo);
			List<FXReturnOrderGoodsDto> itemList = new ArrayList<FXReturnOrderGoodsDto>();
			Integer orderGoodsNum = 0;
			Double orderAmt = 0.00;
			if(itemJsonList!=null && itemJsonList.size() > 0){
				for(Object item : itemJsonList){
					JSONObject json = (JSONObject) item;
					FXReturnOrderGoodsDto goods = new FXReturnOrderGoodsDto();
					goods.setOrderId(orderId);
					goods.setOrderNo(orderNo);
					goods.setBoxNum(json.getInteger("num"));
					goods.setItemId(json.getLong("itemId"));
					goods.setItemName(json.getString("itemName"));
					goods.setPlanAmt(json.getBigDecimal("amount"));
					goods.setPlanNum(json.getInteger("purchaseNum"));
//					goods.setSku("");
					goods.setTaxRate(json.getBigDecimal("rate"));
					goods.setUnit(json.getString("unit"));
					goods.setUnitPrice(json.getBigDecimal("price"));
					orderGoodsNum += json.getInteger("purchaseNum");
					orderAmt += json.getDouble("amount");
					itemList.add(goods);
				}
				order.setDeleteFlag(0);
				order.setGoodsNum(orderGoodsNum);
				order.setOrderAmt(new BigDecimal(orderAmt));
				//保存订单和订单商品
				Map<String,Object> params = new HashMap<String, Object>();
				params.put("order", order);
				params.put("itemList", itemList);
				ResultDTO<Object> rst = orderService.saveOrder(params);
				
				rstJson.put("state", rst.getCode());
				rstJson.put("msg", rst.getMsg());
			}else{
				rstJson.put("state", "0001");
				rstJson.put("msg", "订单商品信息为空");
			}
			return rstJson;
		}
		
		@RequestMapping("/returnOrder/{orderId}/submit")
		public Object submitOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId,Integer state,String auditResult,Integer version){
			JSONObject rstJson = new JSONObject();
			rstJson.put("state", "0001");
			rstJson.put("msg", "数据提交异常");
			try {
				Map<String,Object> params = new HashMap<String, Object>();
				params.put("orderId", orderId);
				params.put("state", state);
				params.put("auditResult", auditResult);
				params.put("version", version);
				params.put("userName", OpcSDKTools.getUserName(request));
				params.put("userId", OpcSDKTools.getUserOnlyId(request));
				ResultDTO<Object> rstDto = orderService.updateOrderState(params);
				
					rstJson.put("state", rstDto.getCode());
					rstJson.put("msg", rstDto.getMsg());
			} catch (Exception e) {
				rstJson.put("msg", e.getMessage());
				e.printStackTrace();
			}
			return rstJson;
		}
		@RequestMapping("/returnOrder/{orderId}/delete")
		public Object deleteOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId){
			JSONObject rstJson = new JSONObject();
			rstJson.put("state", "0001");
			rstJson.put("msg", "数据提交异常");
			try {
				ResultDTO<Object> rst = orderService.deleteOrder(orderId, OpcSDKTools.getUserName(request), OpcSDKTools.getUserOnlyId(request));
				rstJson.put("state", rst.getCode());
				rstJson.put("msg", rst.getMsg());
			} catch (Exception e) {
				rstJson.put("msg", e.getMessage());
				e.printStackTrace();
			}
			return rstJson;
		}
		
	}
	
	
}
