package com.ule.wholesale.fxpurchase.web.util;

import java.awt.Image;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ule.dfs.client.util.UploadFile;
import com.ule.wholesale.common.constants.CommonConstants;

public class UploadImgServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private Log logger = LogFactory.getLog(UploadImgServlet.class);
	
	public UploadImgServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		uploadImg(request, response);
	}
	
	//图片上传
	private void uploadImg(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		logger.debug("method == uploadImg");
		
		DiskFileItemFactory fac = new DiskFileItemFactory();
		
		//图片上传的本地路劲
		String uploadTempDir = CommonConstants.uploadTempDir;
		if (uploadTempDir == null || uploadTempDir.equals("")) {
			uploadTempDir = "/tmp";
		}
		fac.setRepository(new File(uploadTempDir));

		ServletFileUpload upload = new ServletFileUpload(fac);

		upload.setHeaderEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		List<FileItem> fileList = null;
		try {
			fileList = upload.parseRequest(request);
		} catch (FileUploadException ex) {
			logger.error("err",ex);
			return;
		}

		Iterator<FileItem> it = fileList.iterator();
		while (it.hasNext()) {
			FileItem item = it.next();
			if (!item.isFormField()) {

				String name = item.getName();//图片名称
				if (name == null || name.trim().equals("")) {
					continue;
				}
				
				String paramstr = request.getParameter("paramstr");//接收参数
				logger.info("paramstr="+paramstr);
				JSONObject paramsJson = JSONObject.fromObject(paramstr);
				String userId = (String) paramsJson.get("userId");//用户id
				String appName = (String) paramsJson.get("appName");//应用名称
				String length_width = (String) paramsJson.get("length_width");//长宽，逗号隔开
				
				if (userId==null || "".equals(userId)) {
					userId = "9999";
				}
				
				if(length_width!=null && !"".equals(length_width) && length_width.indexOf(",")!=-1){
					String length = length_width.split(",")[0];
					String width = length_width.split(",")[1];
					try {
						File FileBendi = new File("/tmp/"+item.getName());
						logger.info(FileBendi.getCanonicalPath());
						logger.info("fileBendi create success");
						byte buffer[] = new byte[10240];
						InputStream ins= item.getInputStream();
						OutputStream out = new FileOutputStream(FileBendi);
						 int bytesRead = 0;
					        while ((bytesRead = ins.read(buffer, 0, 8192))
					                != -1){
					        	out.write(buffer, 0, bytesRead);
					        }
					        ins.close();
					        out.close();
						if(!FileBendi.exists()){
							try {
								FileBendi.createNewFile();
							} catch (IOException e) {
								JSONObject json = new JSONObject();
								json.put("returnMessage","");
								json.put("returnCode", "0003");
								response.getWriter().print(json.toString());
								return;
							}
						}
						
						Image img = ImageIO.read(FileBendi);
						
						if(!length.equals("null") && width.equals("null")){//限宽
							if(img.getWidth(null) != Integer.valueOf(length)){
								JSONObject json = new JSONObject();
								json.put("returnMessage","当前尺寸为"+img.getWidth(null)+"*"+img.getHeight(null)+"不符合,请选择宽度为" + Integer.valueOf(length) +"px,高度没有限制。");
								json.put("returnCode", "0001");
								response.getWriter().print(json.toString());
								return;
							}
						}else if(length.equals("null") && !width.equals("null")){// 限高
							if(img.getHeight(null) != Integer.valueOf(width)){
								JSONObject json = new JSONObject();
								json.put("returnMessage","当前尺寸为"+img.getWidth(null)+"*"+img.getHeight(null)+"不符合,请选择高度为" + Integer.valueOf(width) +"px,宽度没有限制。");
								json.put("returnCode", "0001");
								response.getWriter().print(json.toString());
								return;
							}
						}else if(!length.equals("null") && !width.equals("null")){
							if(img.getWidth(null) != Integer.valueOf(length)||img.getHeight(null) != Integer.valueOf(width)){
								JSONObject json = new JSONObject();
								json.put("returnMessage","当前尺寸为"+img.getWidth(null)+"*"+img.getHeight(null)+"不符合,请选择尺寸为"+Integer.valueOf(length)+"*"+Integer.valueOf(width));
								json.put("returnCode", "0001");
								response.getWriter().print(json.toString());
								return;
							}
						}
					} catch(Exception e){
						logger.error(e);
					}
				}
				
				InputStream in = null;
				try {
					in = item.getInputStream();
					if (in == null) {
						throw new Exception("error FileItem item is null");
					}
	
					String picType = name.substring(name.lastIndexOf(".") + 1);//图片的后缀名
					if(!picType.toUpperCase().equals("JPG") && !picType.toUpperCase().equals("GIF") 
							&& !picType.toUpperCase().equals("PNG") && !picType.toUpperCase().equals("BMP")){
						JSONObject json = new JSONObject();
						json.put("returnMessage","文件格式要求为JPG、GIF、PNG、BMP中的一种");
						json.put("returnCode", "0001");
						response.getWriter().print(json.toString());
						return;
					}
					String uploadUrl = CommonConstants.uploadFileUrl;
					logger.info("uploadUrl:"+uploadUrl);
					String fullName = null;
					String result = null;
					if(appName!=null && appName.indexOf("fxMerchant")!=-1){
						fullName = "/app_"+appName+"/file#/*." + picType;
						logger.info("fullName:"+fullName);
						//目前版本不支持水印，要到2.0版本
//						String process2 = "resize 60x60|watermark http://i0.ulecdn.com/ule/header/images/logo.png;1;30";
						result = UploadFile.upload(uploadUrl,"file",fullName,in,null);
					}else{
						fullName = "/user_"+userId+"/store_"+userId+"/images/#/*"+"."+picType;
						logger.info("fullName:"+fullName);
						result = UploadFile.upload(uploadUrl,"mstore",fullName,in,null);
					}
	
					if (result == null || result.length()==0) {
						response.getWriter().print("{\"returnMessage\":\"\u4e0a\u4f20\u5931\u8d25\uff0c\u670d\u52a1\u5668\u54cd\u5e94\u4e2d\u65ad\uff0c\u8bf7\u518d\u8bd5\u4e00\u6b21\u3002\",\"returnCode\":\"1024\"}");
					} else {
						JSONObject json=JSONObject.fromObject(result);
						String returnCode=json.getString("status");
					
						if ("success".equals(returnCode)) {
							String url = json.getString("url");
							if(!(appName!=null && appName.indexOf("fxMerchantJoin")!=-1)){
								if(url.indexOf("https")!=-1){//包含https
									url = url.replaceFirst(CommonConstants.globalStaticServer1,CommonConstants.uploadFileToDFSUrl); 
								}else{
									url = url.replaceFirst("http:"+CommonConstants.globalStaticServer1,"https:"+CommonConstants.uploadFileToDFSUrl);
								}
							}
							logger.info("imgUrl="+url);
							response.getWriter().print("{\"fileName\":\""+name+"\",\"returnMessage\":\"\",\"returnCode\":\"0000\",\"imgUrl\":\"" + url + "\"}");
						} else {
							logger.info("return result:"+json.getString("reason"));
							response.getWriter().print("{\"returnMessage\":\"\u4e0a\u4f20\u5931\u8d25\uff0c\u670d\u52a1\u5668\u54cd\u5e94\u4e2d\u65ad\uff0c\u8bf7\u518d\u8bd5\u4e00\u6b21\u3002\",\"returnCode\":\"1024\"}");
						}
					}
	
				} catch (Exception e) {
					logger.error(e);
				} finally {
					if (in != null) {
						try {
							in.close();
						} catch (Exception ex) {
							logger.error(ex, ex);
							ex.printStackTrace();
						}
						in = null;
					}
				}
			}
		}
	}
}
