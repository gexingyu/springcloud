package com.ule.wholesale.fxpurchase.web.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Service
public class SupplierInfoService {

	public void showButton(HttpServletRequest request) throws Exception {
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if (str.equals(FxPurchaseStateEnum.SUPPLIER_ADD.getName())) {
					request.setAttribute("supplier_add", "show");
				} else if (str.equals(FxPurchaseStateEnum.SUPPLIER_EDIT.getName())) {
					request.setAttribute("supplier_edit", "show");
				} else if (str.equals(FxPurchaseStateEnum.SUPPLIER_SUBMIT.getName())) {
					request.setAttribute("supplier_submit", "show");
				} else if (str.equals(FxPurchaseStateEnum.SUPPLIER_DEL.getName())) {
					request.setAttribute("supplier_del", "show");
				} else if (str.equals(FxPurchaseStateEnum.SUPPLIER_AUDIT.getName())) {
					request.setAttribute("supplier_audit", "show");
				} else if (str.equals(FxPurchaseStateEnum.SUPPLIER_ANO_EDIT.getName())) {// 审核后修改
					request.setAttribute("supplier_ano_edit", "show");
				}

			}
		}
	}

}
