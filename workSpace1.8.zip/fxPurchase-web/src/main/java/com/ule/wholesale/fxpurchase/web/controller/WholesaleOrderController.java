package com.ule.wholesale.fxpurchase.web.controller;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.GoodsComparisonClientService;
import com.ule.wholesale.fxpurchase.api.client.OperationLogClientService;
import com.ule.wholesale.fxpurchase.api.client.WholesaleOrderClientController;
import com.ule.wholesale.fxpurchase.api.dto.FXGoodsCompareListDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderGoodsDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderParam;
import com.ule.wholesale.fxpurchase.web.service.CommonService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;
@Controller
@RequestMapping("/whOrder")
public class WholesaleOrderController {
	private static Log logger = LogFactory.getLog(WholesaleOrderController.class); 
	
	@Autowired
	CommonService commonService;
	@Autowired
	private GoodsComparisonClientService goodsComparisonClientService;
	@Autowired
	private WholesaleOrderClientController wholesaleOrderClientController;
	@Autowired
	OperationLogClientService operationLogService;

	@RequestMapping("/create")
	public String createOrder(HttpServletRequest request,Model model){
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
		} catch (Exception e) {
			logger.error("createOrder============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		return "wholesaleOrder/createOrder";
	}
	
	@RequestMapping("/list")
	public String orderList(HttpServletRequest request,Model model){
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
		} catch (Exception e) {
			logger.error("createOrder============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		return "wholesaleOrder/orderList";
	}
	
	@RequestMapping("/{orderId}/edit")
	public String editOrder(HttpServletRequest request,@PathVariable("orderId")Long orderId,Model model){

		ResultDTO<Map<String,Object>> orderDetail = wholesaleOrderClientController.fingdOrderDetailByOrderId(orderId);
		FXWholesaleOrderDto order = new FXWholesaleOrderDto();
		try {
			com.ule.wholesale.common.util.BeanUtils.copyProperties(order, orderDetail.getData().get("order"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("order", order);
		model.addAttribute("itemList", orderDetail.getData().get("itemList"));
		return "wholesaleOrder/createOrder";
	}

	@RequestMapping("/{orderId}/detail")
	public String orderDetail(HttpServletRequest request,@PathVariable("orderId")Long orderId,Model model){
		ResultDTO<Map<String,Object>> orderDetail = wholesaleOrderClientController.fingdOrderDetailByOrderId(orderId);
		Object orderObj = orderDetail.getData().get("order");
		FXWholesaleOrderDto order = new FXWholesaleOrderDto();
		try {
			com.ule.wholesale.common.util.BeanUtils.copyProperties(order, orderObj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("order", order);
		model.addAttribute("itemList", orderDetail.getData().get("itemList"));
		model.addAttribute("opLogList", operationLogService.getOperationLogList(order.getOrderNo(), FxPurchaseStateEnum.OPLOG_TYPE_6.getIndex()));
		//设置权限
		/*commonService.showButton(request);*/
		return "wholesaleOrder/orderDetail";
	}
	
	@RequestMapping("/addGoods/{signCode}")
	public String addgoods(@PathVariable("signCode")String signCode,Long merchantId,Long whId,String itemCode,String itemName,Integer pageNum,Integer pageSize,String flag,String index,Model model){
		pageNum = (pageNum == null || pageNum < 0) ? 1 : pageNum;
		pageSize = (pageSize == null || pageSize < 1 ) ? 10 : pageSize;
		FXGoodsCompareListDto dto = new FXGoodsCompareListDto();
		dto.setSignProvinceCode(signCode);
		dto.setMerchantId(merchantId);
		if(itemCode !=null && !itemCode.isEmpty()){
		dto.setItemCode(itemCode);
		}
		dto.setItemName(itemName);
		ResultDTO<PageInfo<FXGoodsCompareListDto>> pageInfo = goodsComparisonClientService.findItemList(dto, pageNum, pageSize);
		List<FXGoodsCompareListDto> itemList = pageInfo.getData().getList();
		List<FXGoodsCompareListDto> items = new ArrayList<FXGoodsCompareListDto>();
		List<Long> itemIdList = new ArrayList<Long>();
		for(FXGoodsCompareListDto item : itemList){
			if(item != null && item.getItemCode() != null && !"".equals(item.getItemCode())){
				itemIdList.add(Long.valueOf(item.getItemCode()));
				items.add(item);
			}
		}
		
		if(items.size() > 0){
			String itemStorage = commonService.getMerchantItemStorage(merchantId, whId, itemIdList);
			JSONObject json = (JSONObject) JSONObject.parse(itemStorage);
			if("0000".equals(json.getString("code"))){
				
				List<Map<String,Object>> isList = (List<Map<String, Object>>) json.get("inventoryList");
				Map<String,Integer> itemStorageMap = new HashMap<String, Integer>();
				for(Map<String,Object> m : isList){
					itemStorageMap.put(m.get("itemId").toString(), Integer.valueOf(m.get("quantity").toString()));
				}
				model.addAttribute("itemStorage", itemStorageMap);
			}
		}
		model.addAttribute("signCode", signCode);
		model.addAttribute("merchantId", merchantId);
		model.addAttribute("whId", whId);
		model.addAttribute("itemCode", itemCode);
		model.addAttribute("itemName", itemName);
		model.addAttribute("flag", flag);
		model.addAttribute("index", index);
		model.addAttribute("itemList", items);
		model.addAttribute("currentPage", pageInfo.getData().getPageNum());
		model.addAttribute("totalPage", pageInfo.getData().getPages());
		
		return "/wholesaleOrder/addGoods";
	}
}

@RestController
@RequestMapping("/whOrderRest")
class WholesaleOrderRestController{
	private static Log logger = LogFactory.getLog(WholesaleOrderRestController.class); 
	
	@Autowired
	private WholesaleOrderClientController wholesaleOrderClientController;
	@Autowired
	private GoodsComparisonClientService goodsComparisonClientService;
	
	@RequestMapping( value = "/save")
	public Map<String, Object> saveOrder(HttpServletRequest request,FXWholesaleOrderDto dto,String time,String itemInfo,Integer version){
		JSONObject rstJson = new JSONObject();
		FXWholesaleOrderDto order = new FXWholesaleOrderDto();
		if(dto.getId() != null){
			ResultDTO<FXWholesaleOrderDto> rstOrder = wholesaleOrderClientController.fingdOrderByOrderId(dto.getId());
			order = rstOrder.getData();
			order.setVersion(version);
		}else{
			order.setVersion(0);
			order.setSourceOrderType(FxPurchaseStateEnum.SOURCE_TYPE_0.getIndex());
		}
		order.setId(dto.getId());
		order.setSignProvinceCode(dto.getSignProvinceCode());
		order.setSignProvinceName(dto.getSignProvinceName());
		order.setMerchantId(dto.getMerchantId());
		order.setMerchantName(dto.getMerchantName());
		order.setWarehouseId(dto.getWarehouseId());
		order.setWarehouseName(dto.getWarehouseName());
		order.setState(dto.getState());
		order.setRemark(dto.getRemark());
		order.setAddress(dto.getAddress());
		ChinaPostOrgunit orgUnit;
		try {
			orgUnit = OpcSDKTools.getChinapostOrgunit(request);
			order.setOrgName(orgUnit.getName());
			Integer level = OpcSDKTools.getUserLevel(request);
			if(level > 0){
				if(level == 1){
					order.setProvinceOrgCode(orgUnit.getCode());
				}else if(level == 2){
					order.setProvinceOrgCode(orgUnit.getProvinceCode());
					order.setCityOrgCode(orgUnit.getCode());
				}else if(level == 3){
					order.setProvinceOrgCode(orgUnit.getProvinceCode());
					order.setCityOrgCode(orgUnit.getParentCode());
					order.setRegionOrgCode(orgUnit.getCode());
				}
			}
			order.setOrgLevel(level+"");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(time != null && !"".equals(time.trim())){
			try {
				order.setPlanReciptTime(sdf.parse(time));
			} catch (ParseException e) {
				order.setPlanReciptTime(new Date());
			}
		}
		if(dto.getId() == null){
			order.setCreateTime(new Date());
			try {
				order.setCreateUserId(OpcSDKTools.getUserOnlyId(request));
				order.setCreateUser(OpcSDKTools.getUserName(request));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else{
			order.setUpdateTime(new Date());
			try {
				order.setUpdateUserId(OpcSDKTools.getUserOnlyId(request));
				order.setUpdateUser(OpcSDKTools.getUserName(request));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		logger.info("遍历itemList");
		JSONArray itemJsonList = JSONArray.parseArray(itemInfo);
		List<FXWholesaleOrderGoodsDto> itemList = new ArrayList<FXWholesaleOrderGoodsDto>();
		Integer orderGoodsNum = 0;
		Double orderAmt = 0.00;
		if(itemJsonList!=null && itemJsonList.size() > 0){
			for(Object item : itemJsonList){
				JSONObject json = (JSONObject) item;
				FXWholesaleOrderGoodsDto goods = new FXWholesaleOrderGoodsDto();
				goods.setOrderId(order.getId());
				goods.setOrderNo(order.getOrderNo());
				goods.setBoxNum(json.getInteger("num") == null ? 0:json.getInteger("num"));
				goods.setItemId(json.getLong("itemId"));
				goods.setItemName(json.getString("itemName"));
				goods.setPlanAmt(json.getBigDecimal("amount"));
				goods.setPlanNum(json.getInteger("purchaseNum"));
//				goods.setSku("");
				goods.setTaxRate(json.getBigDecimal("rate"));
				goods.setUnit(json.getString("unit"));
				goods.setUnitPrice(json.getBigDecimal("price") == null ? new BigDecimal(0) : json.getBigDecimal("price"));
				orderGoodsNum += json.getInteger("purchaseNum");
				orderAmt += json.getDouble("amount");
				itemList.add(goods);
			}
			order.setPlanNum(orderGoodsNum);
			order.setPlanAmt(new BigDecimal(orderAmt));
			//保存订单和订单商品
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("order", order);
			params.put("itemList", itemList);
			ResultDTO<FXWholesaleOrderDto> rst = wholesaleOrderClientController.saveOrderInfo(params);
			rstJson.put("state", rst.getCode());
			rstJson.put("msg", rst.getMsg());
		}else{
			rstJson.put("state", "0001");
			rstJson.put("msg", "订单商品信息为空");
		}
		return rstJson;
	}
	
	@RequestMapping(value = "/getList")
	public Map<String, Object> getList(HttpServletRequest request,FXWholesaleOrderDto fxWholesaleOrderDto,FXWholesaleOrderParam fxWholesaleOrderParam,Integer pageNum){
		String orgCode;
		Map<String,Object> params = new HashMap<String, Object>();
		try {
			if(fxWholesaleOrderDto.getState() != null && fxWholesaleOrderDto.getState() == -1){
				fxWholesaleOrderDto.setState(null);
			}
			params.put("orderNo", fxWholesaleOrderDto.getOrderNo());
			params.put("signProvinceCode", fxWholesaleOrderDto.getSignProvinceCode());
			params.put("state",  fxWholesaleOrderDto.getState());
			params.put("merchantId", fxWholesaleOrderDto.getMerchantId());
			params.put("warehouseId", fxWholesaleOrderDto.getWarehouseId());
			params.put("sourceOrderType", fxWholesaleOrderDto.getSourceOrderType());
			params.put("sourceOrderNo", fxWholesaleOrderDto.getSourceOrderNo());
			params.put("deliveryBeginTime", fxWholesaleOrderParam.getDeliveryBeginTime());
			params.put("deliveryEndTime", fxWholesaleOrderParam.getDeliveryEndTime());
			params.put("planReciptBeginTime", fxWholesaleOrderParam.getPlanReciptBeginTime());
			params.put("planReciptEndTime", fxWholesaleOrderParam.getPlanReciptEndTime());
			params.put("whReceiptBeginTime", fxWholesaleOrderParam.getWhReceiptBeginTime());
			params.put("whReceiptEndTime", fxWholesaleOrderParam.getWhReceiptEndTime());
			
			orgCode = OpcSDKTools.getOrgunitCode(request);
			String orgName = OpcSDKTools.getOrgunitName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxWholesaleOrderDto.setOrgName(orgName);
			fxWholesaleOrderDto.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				params.put("provinceOrgCode", orgCode);
			}
			if(userLevel.intValue()==2){
				params.put("cityOrgCode", orgCode);
			}
			if(userLevel.intValue()==3){
				params.put("regionOrgCode", orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(pageNum==null){
			pageNum = 1;
		}
		Integer pageSize = 10;
		ResultDTO<Map<String,Object>> infos =  wholesaleOrderClientController.getList(params, pageNum, pageSize,null);
		return infos.getData();
	}
	
	@RequestMapping("/{orderId}/submit")
	public Object submitOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId,Integer state,String auditResult,Integer version){
		JSONObject rstJson = new JSONObject();
		rstJson.put("state", "0001");
		rstJson.put("msg", "数据请求异常");
		try {
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("orderId", orderId);
			params.put("state", state);
			params.put("auditResult", auditResult);
			params.put("version", version);
			params.put("username", OpcSDKTools.getUserName(request));
			params.put("userId", OpcSDKTools.getUserOnlyId(request));
			ResultDTO<Object> rst  = wholesaleOrderClientController.updateOrderState(params);
			rstJson.put("state", rst.getCode());
			rstJson.put("msg", rst.getMsg());
		} catch (Exception e) {
			rstJson.put("msg", e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	
	@RequestMapping("/{orderId}/delete")
	public Object deleteOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId){
		JSONObject rstJson = new JSONObject();
		rstJson.put("state", "0001");
		rstJson.put("msg", "数据请求异常");
		try {
			ResultDTO<Object> orderNo = wholesaleOrderClientController.deleteOrder(orderId, OpcSDKTools.getUserName(request), OpcSDKTools.getUserOnlyId(request));
				rstJson.put("state", orderNo.getCode());
				rstJson.put("msg", orderNo.getMsg());
		} catch (Exception e) {
			rstJson.put("msg", e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	
	@RequestMapping("/addGoods/{signCode}/{itemId}")
	public FXGoodsCompareListDto addgoods(@PathVariable("signCode")Long signCode,@PathVariable("itemId")Long itemId){
		FXGoodsCompareListDto dto = new FXGoodsCompareListDto();
		dto.setSignProvinceCode(String.valueOf(signCode));
		dto.setItemCode(String.valueOf(itemId));
		ResultDTO<PageInfo<FXGoodsCompareListDto>> pageInfo = goodsComparisonClientService.findItemList(dto, 1, 10);
		List<FXGoodsCompareListDto> itemList = pageInfo.getData().getList();
		return (itemList == null || itemList.size() == 0) ? null : itemList.get(0);
	}
}
