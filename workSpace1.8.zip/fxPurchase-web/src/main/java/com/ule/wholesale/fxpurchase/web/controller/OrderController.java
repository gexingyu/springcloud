package com.ule.wholesale.fxpurchase.web.controller;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.HttpClientUtil;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.CommonClientService;
import com.ule.wholesale.fxpurchase.api.client.ContractItemClientService;
import com.ule.wholesale.fxpurchase.api.client.OperationLogClientService;
import com.ule.wholesale.fxpurchase.api.client.OrderClientService;
import com.ule.wholesale.fxpurchase.api.client.RequireGoodsClientService;
import com.ule.wholesale.fxpurchase.api.client.SupplierInfoClientService;
import com.ule.wholesale.fxpurchase.api.client.WholesaleOrderClientController;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemListDto;
import com.ule.wholesale.fxpurchase.api.dto.FXPurchaseOrderDto;
import com.ule.wholesale.fxpurchase.api.dto.FXPurchaseOrderGoodsDto;
import com.ule.wholesale.fxpurchase.api.dto.FXRequireGoodsListDto;
import com.ule.wholesale.fxpurchase.api.dto.FXSupplierInfoDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderGoodsDto;
import com.ule.wholesale.fxpurchase.web.config.PropertiesConfiguration;
import com.ule.wholesale.fxpurchase.web.service.CommonService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;
/**
 * @author zhengmingzhi
 *
 */
@Controller
public class OrderController {
	private static Log logger = LogFactory.getLog(OrderController.class);  
	@Autowired
	private SupplierInfoClientService supplierClientService;
//	@Autowired
//	FXContractItemListService itemService;
	@Autowired
	CommonClientService commonClientService;
	@Autowired
	CommonService commonService;
	@Autowired
	OrderClientService orderClientService;
	@Autowired
	OperationLogClientService operationLogService;
	
	@RequestMapping("/order/create")
	public String createOrder(HttpServletRequest request,Model model){
		FXSupplierInfoDto fxSupplierInfo = new FXSupplierInfoDto();
		fxSupplierInfo.setStatus(2);
		try {
			String orgCode = "99310006";OpcSDKTools.getOrgunitCode(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxSupplierInfo.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxSupplierInfo.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxSupplierInfo.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxSupplierInfo.setRegionOrgCode(orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		ResultDTO<Map<String,Object>> pageInfo = supplierClientService.getSupplierListByPage(fxSupplierInfo, 1, Integer.MAX_VALUE, null);
		model.addAttribute("supplierList",pageInfo.getData().get("supplierList"));
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
		} catch (Exception e) {
			logger.error("createOrder============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		return "order/createOrder";
	}
	@RequestMapping("/order/addGoods/{supplierId}")
	public String addgoods(@PathVariable("supplierId")Long supplierId,Long merchantId,Long whId,Integer pageNum,Integer pageSize,Long itemId,String itemName,String flag,String index,Model model){
		pageNum = (pageNum == null || pageNum < 0) ? 1 : pageNum;
		pageSize = (pageSize == null || pageSize < 1 ) ? 10 : pageSize;
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("supplierId", supplierId);
		params.put("merchantId", merchantId);
		params.put("itemId", itemId);
		params.put("itemName", itemName);
		params.put("pageNum", pageNum);
		params.put("pageSize", pageSize);
		ResultDTO<PageInfo<FXContractItemListDto>> pageInfo = orderClientService.findEffectiveItemList(params);
		List<FXContractItemListDto> itemList = pageInfo.getData().getList();
		List<Long> itemIdList = new ArrayList<Long>();
		for(FXContractItemListDto item : itemList){
			itemIdList.add(item.getItemId());
		}
		if(itemList.size() > 0){
			String itemStorage = commonService.getMerchantItemStorage(merchantId, whId, itemIdList);
			JSONObject json = (JSONObject) JSONObject.parse(itemStorage);
			if("0000".equals(json.getString("code"))){
				
				List<Map<String,Object>> isList = (List<Map<String, Object>>) json.get("inventoryList");
				Map<Long,Integer> itemStorageMap = new HashMap<Long, Integer>();
				for(Map<String,Object> m : isList){
					itemStorageMap.put(Long.valueOf(m.get("itemId").toString()), Integer.valueOf(m.get("quantity").toString()));
				}
				model.addAttribute("itemStorage", itemStorageMap);
			}
		}
		model.addAttribute("supplierId", supplierId);
		model.addAttribute("merchantId", merchantId);
		model.addAttribute("whId", whId);
		model.addAttribute("itemId", itemId);
		model.addAttribute("itemName", itemName);
		model.addAttribute("flag", flag);
		model.addAttribute("index", index);
		model.addAttribute("itemList", itemList);
		model.addAttribute("currentPage", pageInfo.getData().getPageNum());
		model.addAttribute("totalPage", pageInfo.getData().getPages());
		
		return "order/addGoods";
	}
	@RequestMapping("/order/{orderId}/edit")
	public String editOrder(HttpServletRequest request,@PathVariable("orderId")Long orderId,Model model){
		FXSupplierInfoDto fxSupplierInfo = new FXSupplierInfoDto();
		fxSupplierInfo.setStatus(2);
		try {
			String orgCode = OpcSDKTools.getOrgunitCode(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxSupplierInfo.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxSupplierInfo.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxSupplierInfo.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxSupplierInfo.setRegionOrgCode(orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		ResultDTO<Map<String, Object>> pageInfo = supplierClientService.getSupplierListByPage(fxSupplierInfo, 1, Integer.MAX_VALUE,null);
		model.addAttribute("supplierList",pageInfo.getData().get("supplierList"));
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
		} catch (Exception e) {
			logger.error("editOrder============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		ResultDTO<Map<String,Object>> orderDetail = orderClientService.fingdOrderDetailByOrderId(orderId);
		FXPurchaseOrderDto order = new FXPurchaseOrderDto();
		try {
			com.ule.wholesale.common.util.BeanUtils.copyProperties(order, orderDetail.getData().get("order"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("order", order);
		model.addAttribute("itemList", orderDetail.getData().get("itemList"));
		return "order/createOrder";
	}
//	static {
//	    //注册sql.date的转换器，即允许BeanUtils.copyProperties时的源目标的sql类型的值允许为空
//	    ConvertUtils.register(new SqlDateConverter(), java.util.Date.class);
//	    //ConvertUtils.register(new SqlTimestampConverter(), java.sql.Timestamp.class);
//	    //注册util.date的转换器，即允许BeanUtils.copyProperties时的源目标的util类型的值允许为空
//	    ConvertUtils.register(new UtilDateConverter(), java.util.Date.class);
//	  }
	@RequestMapping("/order/{orderId}/detail")
	public String orderDetail(HttpServletRequest request,@PathVariable("orderId")Long orderId,Model model){
		try{
			ResultDTO<Map<String,Object>> orderDetail = orderClientService.fingdOrderDetailByOrderId(orderId);
			Object orderObj = orderDetail.getData().get("order");
			FXPurchaseOrderDto order = new FXPurchaseOrderDto();
			try {
				com.ule.wholesale.common.util.BeanUtils.copyProperties(order, orderObj);
			} catch (Exception e) {
				e.printStackTrace();
			}
			ResultDTO<FXSupplierInfoDto> fxSupplierInfo = supplierClientService.getSupplierDetail(order.getSupplierId());
			model.addAttribute("supplierAdress", fxSupplierInfo.getData().getCompAddress());
			model.addAttribute("order", order);
			model.addAttribute("itemList", orderDetail.getData().get("itemList"));
			model.addAttribute("opLogList", operationLogService.getOperationLogList(order.getOrderNo(), FxPurchaseStateEnum.OPLOG_TYPE_4.getIndex()));
			//设置权限
			commonService.showButton(request);
			return "order/orderDetail";
		}catch(Exception e){
			logger.error("error", e);
		}
		return null;
	}
	@RequestMapping("/order/list")
	public String orderList(HttpServletRequest request,Model model){
//		FXSupplierInfo fxSupplierInfo = new FXSupplierInfo();
//		fxSupplierInfo.setStatus(2);
//		PageInfo<FXSupplierInfo> pageInfo = supplierService.getSupplierListByPage(fxSupplierInfo, 1, Integer.MAX_VALUE);
//		model.addAttribute("supplierList",pageInfo.getList());
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
			//设置权限
			commonService.showButton(request);
		} catch (Exception e) {
			logger.error("orderList============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		return "order/orderList";
	}
	
	@RequestMapping(value = "/order/listRecord1",method=RequestMethod.POST)
	public String orderListRecordState(HttpServletRequest request,Integer state,Integer pageNum,Integer pageSize,Model model){
		pageNum = (pageNum == null || pageNum == 0) ? 1 : pageNum;
		pageSize = (pageSize == null || pageSize < 1) ? 10 :pageSize;
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("state",state);
		try {
			Integer level = OpcSDKTools.getUserLevel(request);
			params.put("orgLevel",level);
			if(level != 0){
				ChinaPostOrgunit orgUnit = OpcSDKTools.getChinapostOrgunit(request);
				if(level == 1 )params.put("provinceOrgCode",orgUnit.getCode());
				if(level == 2 )params.put("cityOrgCode",orgUnit.getCode());
				if(level == 3 )params.put("regionOrgCode",orgUnit.getCode());
			}
		} catch (Exception e) {
			logger.error("orderListRecordState >>>>获取用户机构信息异常，"+e.getMessage());
		}
		ResultDTO<Map<String,Object>> pageInfo = orderClientService.findOrderList(params);
		model.addAttribute("orderList", pageInfo.getData().get("orderList"));
		model.addAttribute("currentPage", pageInfo.getData().get("currentPage"));
		model.addAttribute("totalPage", pageInfo.getData().get("totalPage"));
		
		return "order/orderListRecord";
	}
	@RequestMapping(value = "/order/listRecord",method=RequestMethod.POST)
	public String orderListRecord(HttpServletRequest request,FXPurchaseOrderDto order,String startTime,String endTime,String whStartTime,String whEndTime,Integer pageNum,Integer pageSize,Model model){
		pageNum = (pageNum == null || pageNum == 0) ? 1 : pageNum;
		pageSize = (pageSize == null || pageSize < 1) ? 10 :pageSize;
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("pageNum", pageNum);
		params.put("pageSize", pageSize);
		params.put("orderNo", (order.getOrderNo()== null || order.getOrderNo().trim().equals("")) ? null : order.getOrderNo());
		params.put("supplierId", order.getSupplierId());
		params.put("supplierName", (order.getSupplierName() == null || order.getSupplierName().trim().equals("")) ? null : order.getSupplierName());
		params.put("state", order.getState());
		params.put("merchantId", order.getMerchantId());
		params.put("receivingWarehouseId", order.getReceivingWarehouseId());
		params.put("provinceOrgCode", order.getProvinceOrgCode());
		params.put("cityOrgCode", order.getCityOrgCode());
		params.put("sourceOrderType", order.getSourceOrderType());
		params.put("sourceOrderNo", order.getSourceOrderNo());
		params.put("regionOrgCode", order.getRegionOrgCode());
		params.put("startTime", "".equals(startTime) ? null : startTime );
		params.put("endTime", "".equals(endTime)?null:endTime);
		params.put("whStartTime", "".equals(whStartTime)?null:whStartTime);
		params.put("whEndTime", "".equals(whEndTime)?null:whEndTime);
		try {
			Integer level = OpcSDKTools.getUserLevel(request);
			params.put("orgLevel",level);
			if(level != 0){
				ChinaPostOrgunit orgUnit = OpcSDKTools.getChinapostOrgunit(request);
				if(level == 1 )params.put("provinceOrgCode",orgUnit.getCode());
				if(level == 2 )params.put("cityOrgCode",orgUnit.getCode());
				if(level == 3 )params.put("regionOrgCode",orgUnit.getCode());
			}
		} catch (Exception e) {
			logger.error("orderListRecord >>>>获取用户机构信息异常，"+e.getMessage());
		}
		ResultDTO<Map<String,Object>> pageInfo = orderClientService.findOrderList(params);
		model.addAttribute("orderList", pageInfo.getData().get("orderList"));
		model.addAttribute("currentPage", pageInfo.getData().get("currentPage"));
		model.addAttribute("totalPage", pageInfo.getData().get("totalPage"));
		
		return "order/orderListRecord";
	}
	
	/**
	 * 分页获取指定商家的商品列表
	 * @param merchantId
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/getProductListByPage", method = RequestMethod.POST)
	public List<Object> getProductListByPage(Long merchantId,Integer pageNum,Integer pageSize){
		long start = System.currentTimeMillis();
		logger.info("ProductController >>> getProductListByPage start ... merchantId="+merchantId);
		//根据条件获取分页后的数据结构
		List<Map<String,Object>> productList = new ArrayList<Map<String,Object>>();
    	//获取分页信息
    	PageInfo<Map<String,Object>> page = new PageInfo<Map<String,Object>> (productList);
        int pages = page.getPages();
        int []navPageNums = page.getNavigatepageNums();
        Map<String,Object> pageMap = new HashMap<String, Object>();
        pageMap.put("pages", pages);
        pageMap.put("pageNum", pageNum);
        pageMap.put("navPageNums", navPageNums);
        
        logger.info("ProductController >>> getProductListByPage end . total use time "+(System.currentTimeMillis() - start)+" ms");
		return null;
	}
}
/**
 * RestController不能进行页面跳转，适用于ajax请求
 * 免去使用ResponseBody的注解
 * @author zhengmingzhi
 *
 */
@RestController
class OrderRestController {
	private static Log logger = LogFactory.getLog(OrderRestController.class);  
	@Autowired
	private SupplierInfoClientService supplierService;
	@Autowired
	ContractItemClientService conitemService;
	@Autowired
	OrderClientService orderService;
	@Autowired
	OperationLogClientService operationLogService;
	@Autowired
	private WholesaleOrderClientController wholesaleOrderClientController;
	@Autowired
	private RequireGoodsClientService requireGoodsClientService;
	@Autowired
	CommonService commonService;
	
	
	/**
	 * 根据商家ID获取商家仓库列表
	 * @param merchantId
	 * @return
	 */
	@RequestMapping("/order/merchantWarehouse/{mId}")
	public String getMerchantWarehouseList(@PathVariable("mId")Long merchantId){
		logger.info("getMerchantWarehouseList  merchantId="+merchantId);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("merchantOnlyId",merchantId);
		String result = "";
		try {
			result = HttpClientUtil.sendPost(PropertiesConfiguration.merchantWarehouse,null,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 根据仓库ID获取仓库收货人和地址信息
	 * @param whId
	 * @return
	 */
	@RequestMapping("/order/warehouse/{whId}")
	public String getWhReceivingInfo(@PathVariable("whId")Long whId){
		logger.info("getMerchantWarehouseList  whId="+whId);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("whId",whId);
		//?merchantOnlyId=1&whId=1&itemIds
		String result = "";
		try {
			result = HttpClientUtil.sendPost(PropertiesConfiguration.warehouseInfo,null,paramMap, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	@RequestMapping("/order/addGoods/{supplierId}/{itemId}")
	public FXContractItemListDto addgoods(@PathVariable("supplierId")Long supplierId,@PathVariable("itemId")Long itemId){
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("supplierId", supplierId);
		params.put("itemId", itemId);
		ResultDTO<PageInfo<FXContractItemListDto>> pageInfo = conitemService.findEffectiveItemList(params, 1, 10);
		List<FXContractItemListDto> itemList = pageInfo.getData().getList();
		return (itemList == null || itemList.size() == 0) ? null : itemList.get(0);
	}
	@RequestMapping("/order/save")
	//alert(supplierId+"="+supplierName+"="+merchantId+"="+merchantName+"="+warehouseId+"="+warehouseName+"="+planSendTime+"="+preAmt+"="+orderRemark+"="+itemInfo);
	public Object saveOrder(HttpServletRequest request,Long orderId,String orderNo,Long supplierId,String supplierName,Long merchantId,String merchantName,Long warehouseId,String warehouseName,String planDeliveryTime,Double prepayAmt,String orderRemark,Integer status,String itemInfo,Integer version){
		JSONObject rstJson = new JSONObject();
		FXPurchaseOrderDto order = new FXPurchaseOrderDto();
		if(orderId != null){
			ResultDTO<FXPurchaseOrderDto> rstOrder = orderService.fingdOrderByOrderId(orderId);
			order = rstOrder.getData();
			order.setVersion(version);
		}else{
			order.setVersion(0);
		}
		order.setId(orderId);
		order.setSupplierId(supplierId);
		order.setSupplierName(supplierName);
		order.setMerchantId(merchantId);
		order.setMerchantName(merchantName);
		order.setIsPrepay(0);
		if(prepayAmt != null && prepayAmt > 0)
			order.setPrepayAmt(new BigDecimal(prepayAmt));
		order.setReceivingWarehouseId(warehouseId);
		order.setReceivingWarehouse(warehouseName);
		order.setState(status);
		order.setRemark(orderRemark);
		ChinaPostOrgunit orgUnit;
		try {
			orgUnit = OpcSDKTools.getChinapostOrgunit(request);
			order.setOrgName(orgUnit.getName());
			Integer level = OpcSDKTools.getUserLevel(request);
			if(level > 0){
				if(level == 1){
					order.setProvinceOrgCode(orgUnit.getCode());
				}else if(level == 2){
					order.setProvinceOrgCode(orgUnit.getProvinceCode());
					order.setCityOrgCode(orgUnit.getCode());
				}else if(level == 3){
					order.setProvinceOrgCode(orgUnit.getProvinceCode());
					order.setCityOrgCode(orgUnit.getParentCode());
					order.setRegionOrgCode(orgUnit.getCode());
				}
			}
			order.setOrgLevel(level+"");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(planDeliveryTime != null && !"".equals(planDeliveryTime.trim())){
			try {
				order.setPlanDeliveryTime(sdf.parse(planDeliveryTime));
			} catch (ParseException e) {
				order.setPlanDeliveryTime(new Date());
			}
		}
		if(orderId == null){
			order.setCreateTime(new Date());
			try {
				order.setCreateUserId(OpcSDKTools.getUserOnlyId(request));
				order.setCreateUser(OpcSDKTools.getUserName(request));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else{
			order.setUpdateTime(new Date());
			try {
				order.setUpdateUserId(OpcSDKTools.getUserOnlyId(request));
				order.setUpdateUser(OpcSDKTools.getUserName(request));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		logger.info("遍历itemList");
		JSONArray itemJsonList = JSONArray.parseArray(itemInfo);
		List<FXPurchaseOrderGoodsDto> itemList = new ArrayList<FXPurchaseOrderGoodsDto>();
		Integer orderGoodsNum = 0;
		Double orderAmt = 0.00;
		if(itemJsonList!=null && itemJsonList.size() > 0){
			for(Object item : itemJsonList){
				JSONObject json = (JSONObject) item;
				FXPurchaseOrderGoodsDto goods = new FXPurchaseOrderGoodsDto();
				goods.setOrderId(orderId);
				goods.setOrderNo(orderNo);
				goods.setBoxNum(json.getInteger("num"));
				goods.setItemId(json.getLong("itemId"));
				goods.setItemName(json.getString("itemName"));
				goods.setPlanAmt(json.getBigDecimal("amount"));
				goods.setPlanNum(json.getInteger("purchaseNum"));
//				goods.setSku("");
				goods.setTaxRate(json.getBigDecimal("rate"));
				goods.setUnit(json.getString("unit"));
				goods.setUnitPrice(json.getBigDecimal("price"));
				orderGoodsNum += json.getInteger("purchaseNum");
				orderAmt += json.getDouble("amount");
				itemList.add(goods);
			}
			order.setGoodsNum(orderGoodsNum);
			order.setOrderAmt(new BigDecimal(orderAmt));
			order.setDeleteFlag(0);
			//保存订单和订单商品
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("order", order);
			params.put("itemList", itemList);
			ResultDTO<FXPurchaseOrderDto> rst = orderService.saveOrderInfo(params);
			rstJson.put("state", rst.getCode());
			rstJson.put("msg", rst.getMsg());
		}else{
			rstJson.put("state", "0001");
			rstJson.put("msg", "订单商品信息为空");
		}
		return rstJson;
	}
	@RequestMapping("/order/{orderId}/submit")
	public Object submitOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId,Integer state,String auditResult,Integer version){
		JSONObject rstJson = new JSONObject();
		rstJson.put("state", "0001");
		rstJson.put("msg", "数据请求异常");
		try {
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("orderId", orderId);
			params.put("state", state);
			params.put("auditResult", auditResult);
			params.put("version", version);
			params.put("username", OpcSDKTools.getUserName(request));
			params.put("userId", OpcSDKTools.getUserOnlyId(request));
			ResultDTO<Object> rst  = orderService.updateOrderState(params);
			rstJson.put("state", rst.getCode());
			rstJson.put("msg", rst.getMsg());
		} catch (Exception e) {
			rstJson.put("msg", e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	@RequestMapping("/order/{orderId}/receive")
	public Object receiveOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId,Integer state,Integer version){
		JSONObject rstJson = new JSONObject();
		rstJson.put("state", "0001");
		rstJson.put("msg", "数据请求异常");
		try {
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("orderId", orderId);
			params.put("state", state);
			params.put("version", version);
			params.put("username", OpcSDKTools.getUserName(request));
			params.put("userId", OpcSDKTools.getUserOnlyId(request));
			Map<String, Object> paramMap = this.creatWhorder(orderId,request);
			params.putAll(paramMap);
			//收货并且生成批发单
			ResultDTO<Object> rst  = orderService.receiveOrder(params);
			rstJson.put("state", rst.getCode());
			rstJson.put("msg", rst.getMsg());
		} catch (Exception e) {
			rstJson.put("msg", e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	
	private Map<String,Object> creatWhorder(Long orderId,HttpServletRequest request) throws Exception{
		Map<String,Object> params = new HashMap<String, Object>();
		ResultDTO<Map<String,Object>> orderDetail = orderService.fingdOrderDetailByOrderId(orderId);
		Object orderObj = orderDetail.getData().get("order");
		List<Map<String,Object>> objList = (List<Map<String,Object>>)orderDetail.getData().get("itemList");
		FXPurchaseOrderDto order = new FXPurchaseOrderDto();
		List<FXPurchaseOrderGoodsDto> itemList = new ArrayList<FXPurchaseOrderGoodsDto>();
		com.ule.wholesale.common.util.BeanUtils.copyProperties(order, orderObj);
		for(Map<String,Object> map :objList){
			FXPurchaseOrderGoodsDto g = new FXPurchaseOrderGoodsDto();
			org.apache.commons.beanutils.BeanUtils.copyProperties(g, map);
			itemList.add(g);
		}
		if(order != null ){
			FXRequireGoodsListDto dto = requireGoodsClientService.getFXRequireGoodsListDtoByOrderNo(order.getOrderNo(),"1");
			FXWholesaleOrderDto whorder = new FXWholesaleOrderDto();
			whorder.setVersion(0);
			whorder.setSourceOrderType(FxPurchaseStateEnum.SOURCE_TYPE_1.getIndex());
			whorder.setSourceOrderNo(order.getSourceOrderNo());
			if(dto != null){
				whorder.setSignProvinceCode(dto.getOrderOrgCode());
				whorder.setSignProvinceName(dto.getOrderOrgName());
			}
			whorder.setMerchantId(Long.valueOf(order.getMerchantId()));
			whorder.setMerchantName(order.getMerchantName());
			whorder.setWarehouseId(Long.valueOf(order.getReceivingWarehouseId()));
			whorder.setWarehouseName(order.getReceivingWarehouse());
			whorder.setState(FxPurchaseStateEnum.WHOLESALE_ORDER_8.getIndex());
			whorder.setPlanNum(order.getGoodsNum());
			whorder.setPlanAmt(order.getOrderAmt());
			whorder.setAddress(order.getAddress());
			whorder.setPurchaseOrderId(order.getId());
			ChinaPostOrgunit orgUnit;
			try {
				orgUnit = OpcSDKTools.getChinapostOrgunit(request);
				whorder.setOrgName(orgUnit.getName());
				Integer level = OpcSDKTools.getUserLevel(request);
				if(level > 0){
					if(level == 1){
						whorder.setProvinceOrgCode(orgUnit.getCode());
					}else if(level == 2){
						whorder.setProvinceOrgCode(orgUnit.getProvinceCode());
						whorder.setCityOrgCode(orgUnit.getCode());
					}else if(level == 3){
						whorder.setProvinceOrgCode(orgUnit.getProvinceCode());
						whorder.setCityOrgCode(orgUnit.getParentCode());
						whorder.setRegionOrgCode(orgUnit.getCode());
					}
				}
				whorder.setOrgLevel(level+"");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			whorder.setCreateTime(new Date());
			try {
				whorder.setCreateUserId(OpcSDKTools.getUserOnlyId(request));
				whorder.setCreateUser(OpcSDKTools.getUserName(request));
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			List<FXWholesaleOrderGoodsDto> goodsList = new ArrayList<FXWholesaleOrderGoodsDto>();
			if(itemList!=null && itemList.size()>0){
				for(FXPurchaseOrderGoodsDto item : itemList){
					FXWholesaleOrderGoodsDto goods = new FXWholesaleOrderGoodsDto();
					goods.setBoxNum(item.getBoxNum());
					goods.setItemId(item.getItemId());
					goods.setItemName(item.getItemName());
					goods.setTaxRate(item.getTaxRate());
					goods.setUnit(item.getUnit());
					goods.setUnitPrice(item.getUnitPrice());
					goodsList.add(goods);
				}
			}
			//生成批发单和批发单商品
			params.put("order", whorder);
			params.put("itemList", itemList);
		}
		return params;
	}
	
	@RequestMapping("/order/{orderId}/pay")
	public Object payOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId,Integer version){
		JSONObject rstJson = new JSONObject();
		rstJson.put("state", "0001");
		rstJson.put("msg", "数据请求异常");
		try {
			//预付款支付状态 1:已支付
			ResultDTO<Object> rst  = orderService.payOrder(orderId,version,OpcSDKTools.getUserName(request), OpcSDKTools.getUserOnlyId(request));
				rstJson.put("state", rst.getCode());
				rstJson.put("msg", rst.getMsg());
		} catch (Exception e) {
			rstJson.put("msg", e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	@RequestMapping("/order/{orderId}/delete")
	public Object deleteOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId){
		JSONObject rstJson = new JSONObject();
		rstJson.put("state", "0001");
		rstJson.put("msg", "数据请求异常");
		try {
			ResultDTO<Object> orderNo = orderService.deleteOrder(orderId, OpcSDKTools.getUserName(request), OpcSDKTools.getUserOnlyId(request));
				rstJson.put("state", orderNo.getCode());
				rstJson.put("msg", orderNo.getMsg());
		} catch (Exception e) {
			rstJson.put("msg", e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	
}
