package com.ule.wholesale.fxpurchase.web.util;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.ule.rural.opc.sdk.client.Tools;
import com.ule.vpsUser.api.chinapost.impl.ChinaPostOrgunitManager;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;

/**
 * 获取opc信息
 * @author biwei
 *
 */
public class OpcSDKTools{
	
	public static Long getOrgunitId(HttpServletRequest request) throws Exception {
		Long orgunitId = Tools.getOrgunitId(request);
		if(orgunitId == null)
			orgunitId = 46991L;//测试 16382-河南 16391-商丘 16457-虞城
		return orgunitId;
	}
	
	public static ChinaPostOrgunit getChinapostOrgunit(HttpServletRequest request) throws Exception{
		Long orgunitId = getOrgunitId(request);
		return ChinaPostOrgunitManager.getInstance().getChinaPostOrgunitById(orgunitId);
	}
	
	public static String getOrgunitCode(HttpServletRequest request) throws Exception{
		return getChinapostOrgunit(request).getCode();
	}
	
	public static String getOrgunitName(HttpServletRequest request) throws Exception{
		return getChinapostOrgunit(request).getName();
	}
	
	public static Integer getUserLevel(HttpServletRequest request) throws Exception {
		Integer userLevel = Tools.getUserLevel(request);
		if(userLevel==null){
			userLevel = 3;//测试 1-省 2-市 3-县
		}
		return userLevel;
	}
	
	public static String getLoginName(HttpServletRequest request) throws Exception {
		String loginName = Tools.getLoginName(request);
		return loginName;
	}
	
	public static Long getUserOnlyId(HttpServletRequest request) throws Exception {
		Long userOnlyId = Tools.getUserOnlyId(request);
		if(userOnlyId==null){
			userOnlyId = 9999L;
		}
		return userOnlyId;
	}
	
	public static String getUserName(HttpServletRequest request) throws Exception {
		String userName = Tools.getUserName(request);
		if(userName==null){
			userName = "biwei";
		}
		return userName;
	}
	
	
	public static List<String> getButtonPermissions(HttpServletRequest request) throws Exception{
		List<String> list = new ArrayList<String>();
		for(int i=0;i<FxPurchaseStateEnum.values().length;i++){
			list.add(FxPurchaseStateEnum.values()[i].getName());
		}
//		List<RecResource> resList = UserRoleClient.getResourceList(request);
//		if(resList!=null && resList.size()>0){
//			for(RecResource rec : resList){
//				list.add(rec.getResName());
//			}
//		}
		return list;
	}

}
