package com.ule.wholesale.fxpurchase.web.redis;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
@Service
public class RedisService {
	@Resource
	private RedisTemplate<String, Object> redisTemplate;
	@Resource(name="redisTemplate")
	ValueOperations<String, Object> valueOps;
	public void set(String key, Object value) {
//		ValueOperations<String, Object> vo = redisTemplate.opsForValue();
		valueOps.set(key, value);
	}
	/**
	 * 设置过期的key/value，过期时间单位为分钟
	 * @param key
	 * @param value
	 * @param mins
	 */
	public void set(String key, Object value,Integer mins) {
		ValueOperations<String, Object> vo = redisTemplate.opsForValue();
		vo.set(key, value, mins, TimeUnit.MINUTES);
	}

	public Object get(String key) {
		ValueOperations<String, Object> vo = redisTemplate.opsForValue();
		return vo.get(key);
	}
}
