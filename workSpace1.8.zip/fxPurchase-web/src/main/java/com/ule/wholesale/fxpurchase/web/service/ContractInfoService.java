package com.ule.wholesale.fxpurchase.web.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Service
public class ContractInfoService {

	public void showButton(HttpServletRequest request) throws Exception {
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if (str.equals(FxPurchaseStateEnum.CONTRACT_ADD.getName())) {
					request.setAttribute("contract_add", "show");
				} else if (str.equals(FxPurchaseStateEnum.CONTRACT_EDIT.getName())) {
					request.setAttribute("contract_edit", "show");
				} else if (str.equals(FxPurchaseStateEnum.CONTRACT_SUBMIT.getName())) {
					request.setAttribute("contract_submit", "show");
				} else if (str.equals(FxPurchaseStateEnum.CONTRACT_DEL.getName())) {
					request.setAttribute("contract_del", "show");
				} else if (str.equals(FxPurchaseStateEnum.CONTRACT_CANCEL.getName())) {
					request.setAttribute("contract_cancel", "show");
				} else if (str.equals(FxPurchaseStateEnum.CONTRACT_PURCHASE_AUDIT.getName())) {
					request.setAttribute("contract_purchase_audit", "show");
				} else if (str.equals(FxPurchaseStateEnum.CONTRACT_FINANCIAL_AUDIT.getName())) {
					request.setAttribute("contract_financial_audit", "show");
				} else if (str.equals(FxPurchaseStateEnum.CONTRACT_LAW_AUDIT.getName())) {
					request.setAttribute("contract_law_audit", "show");
				} else if (str.equals(FxPurchaseStateEnum.CONTRACT_CHANGE.getName())) {
					request.setAttribute("contract_change", "show");
				}
			}
		}

	}

}
