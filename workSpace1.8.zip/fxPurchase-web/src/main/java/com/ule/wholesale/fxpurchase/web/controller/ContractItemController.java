package com.ule.wholesale.fxpurchase.web.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.ContractItemClientService;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemListDto;

@Controller
public class ContractItemController {
	
	@RequestMapping(value="contractItem/list")
	public String toContractItemPage(){
		return "contract/contractItem/contractItemPage";
	}
	
}

@RestController
class ContractItemRestController {
	
	private Log log = LogFactory.getLog(ContractItemRestController.class);
	@Autowired
	private ContractItemClientService contractItemClientService;
	private static final Integer PAGESIZE = 10;
	
	@RequestMapping(value="contractItemRest/{currentPage}/{contractId}/query")
	public PageInfo<FXContractItemListDto> doQuery(@PathVariable("currentPage") Integer currentPage,@PathVariable("contractId") Long contractId,Long itemId,String itemName,Integer deleteFlag){
		try{
			if(contractId==null){
				throw new Exception("contractId=="+contractId);
			}
			Map<String,Object> params = new HashMap<String,Object>();
			if(itemId!=null && !"".equals(itemId)) params.put("itemId", itemId);
			if(itemName!=null && !"".equals(itemName)) params.put("itemName", itemName);
			if(deleteFlag!=null && !"".equals(deleteFlag)) params.put("deleteFlag", deleteFlag);
			params.put("contractId", contractId);
			ResultDTO<PageInfo<FXContractItemListDto>> retDTO = contractItemClientService.getPageByParams(params, currentPage, PAGESIZE , null);
			return retDTO.getData();
		}catch(Exception e){
			log.error("error", e);
			return null;
		}
	}
	
}