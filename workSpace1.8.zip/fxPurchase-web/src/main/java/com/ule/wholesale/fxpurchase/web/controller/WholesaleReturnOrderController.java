package com.ule.wholesale.fxpurchase.web.controller;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.OperationLogClientService;
import com.ule.wholesale.fxpurchase.api.client.WholesaleOrderClientController;
import com.ule.wholesale.fxpurchase.api.client.WholesaleReturnOrderClientController;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderGoodsDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleOrderParam;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleReturnOrderDto;
import com.ule.wholesale.fxpurchase.api.dto.FXWholesaleReturnOrderGoodsDto;
import com.ule.wholesale.fxpurchase.web.service.CommonService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Controller
@RequestMapping("/whReturnOrder")
public class WholesaleReturnOrderController {
	
	private static Log logger = LogFactory.getLog(WholesaleOrderController.class); 
	
	@Autowired
	CommonService commonService;
	@Autowired
	private WholesaleOrderClientController wholesaleOrderClientController;
	@Autowired
	private WholesaleReturnOrderClientController wholesaleReturnOrderClientController;
	@Autowired
	OperationLogClientService operationLogService;
	
	//新增批发退货单页面
	@RequestMapping("/create")
	public String createOrder(HttpServletRequest request,Model model){
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
		} catch (Exception e) {
			logger.error("createOrder============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		return "wholesaleReturnOrder/returnOrderAdd";
	}
	
	@RequestMapping("/list")
	public String returnOrderList(HttpServletRequest request,Model model){
		try {
			model.addAttribute("merchantList",commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request)+""));
		} catch (Exception e) {
			logger.error("createOrder============》》》》获取当前用户所属机构ID异常，"+e.getMessage());
			e.printStackTrace();
		}
		return "wholesaleReturnOrder/returnOrderList";
	}
	
	@RequestMapping("/{orderId}/detail")
	public String orderDetail(HttpServletRequest request,@PathVariable Long orderId,Model model){
		ResultDTO<Map<String,Object>> orderDetail = wholesaleReturnOrderClientController.fingdReturnOrderDetailByOrderId(orderId);
		Object orderObj = orderDetail.getData().get("order");
		FXWholesaleReturnOrderDto order = new FXWholesaleReturnOrderDto();
		try {
			com.ule.wholesale.common.util.BeanUtils.copyProperties(order, orderObj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("order", order);
		model.addAttribute("itemList", orderDetail.getData().get("itemList"));
		model.addAttribute("opLogList", operationLogService.getOperationLogList(order.getOrderNo(), FxPurchaseStateEnum.OPLOG_TYPE_7.getIndex()));
		return "wholesaleReturnOrder/returnOrderDetail";
	}
	
	@RequestMapping("/{orderId}/edit")
	public String editOrder(HttpServletRequest request,@PathVariable("orderId")Long orderId,Model model){

		ResultDTO<Map<String,Object>> orderDetail =wholesaleReturnOrderClientController.fingdReturnOrderDetailByOrderId(orderId);
		FXWholesaleReturnOrderDto order = new FXWholesaleReturnOrderDto();
		try {
			com.ule.wholesale.common.util.BeanUtils.copyProperties(order, orderDetail.getData().get("order"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("order", order);
		model.addAttribute("itemList", orderDetail.getData().get("itemList"));
		return "wholesaleReturnOrder/returnOrderAdd";
	}
	/**
	 * 批发退货单添加的2年内的已发货的批发单对应购买机构的商品
	 * @return
	 */
	@RequestMapping("/addGoods/{provinceOrg}")
	public String addgoods(@PathVariable("provinceOrg")String provinceOrg,Long merchantId,Long whId,Integer pageNum,Integer pageSize,Long itemId,String itemName,String flag,String index,Model model){
		pageNum = (pageNum == null || pageNum < 0) ? 1 : pageNum;
		pageSize = (pageSize == null || pageSize < 1 ) ? 10 : pageSize;
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("signProvinceCode", provinceOrg);
		params.put("merchantId", merchantId);
		params.put("itemId", itemId);
		params.put("itemName", itemName);
		params.put("state", 8);
		ResultDTO<PageInfo<FXWholesaleOrderGoodsDto>> pageInfo = wholesaleOrderClientController.findOrderItemList(params, pageNum, pageSize);
		List<FXWholesaleOrderGoodsDto> itemList = pageInfo.getData().getList();
		List<Long> itemIdList = new ArrayList<Long>();
		for(FXWholesaleOrderGoodsDto item : itemList){
			itemIdList.add(item.getItemId());
		}
		if(itemList.size() > 0){
			String itemStorage = commonService.getMerchantItemStorage(merchantId, whId, itemIdList);
			JSONObject json = (JSONObject) JSONObject.parse(itemStorage);
			if(json != null && json.get("code") != null && "0000".equals(json.getString("code"))){
				
				List<Map<String,Object>> isList = (List<Map<String, Object>>) json.get("inventoryList");
				Map<Long,Integer> itemStorageMap = new HashMap<Long, Integer>();
				for(Map<String,Object> m : isList){
					itemStorageMap.put(Long.valueOf(m.get("itemId").toString()), Integer.valueOf(m.get("quantity").toString()));
				}
				model.addAttribute("itemStorage", itemStorageMap);
			}
		}
		model.addAttribute("provinceOrg", provinceOrg);
		model.addAttribute("merchantId", merchantId);
		model.addAttribute("whId", whId);
		model.addAttribute("itemId", itemId);
		model.addAttribute("itemName", itemName);
		model.addAttribute("flag", flag);
		model.addAttribute("index", index);
		model.addAttribute("itemList", itemList);
		model.addAttribute("currentPage", pageInfo.getData().getPageNum());
		model.addAttribute("totalPage", pageInfo.getData().getPages());
		return "wholesaleReturnOrder/addGoods";
	}
}

@RestController
@RequestMapping("/whReturnOrderRest")
 class WholesaleReturnOrderRestController {
	
	private static Log logger = LogFactory.getLog(WholesaleReturnOrderRestController.class); 
	
	@Autowired
	private WholesaleOrderClientController wholesaleOrderClientController;
	@Autowired
	private WholesaleReturnOrderClientController wholesaleReturnOrderClientController;
	@Autowired
	OperationLogClientService operationLogService;
	/**
	 * 获取批发订单中的批发机构
	 * */
	@RequestMapping(value = "/getAgency")
	public Map<String, Object> getAgency(HttpServletRequest request,Long signCode,Long level){
		Map<String, Object> resultMap = new HashMap<String, Object>();		
		ResultDTO<Map<String, Object>>list = wholesaleOrderClientController.getAgency(signCode, level);
		resultMap.put("result", list.getData());
		return resultMap;
	}
	
	@RequestMapping("/save")
	//alert(supplierId+"="+supplierName+"="+merchantId+"="+merchantName+"="+warehouseId+"="+warehouseName+"="+planSendTime+"="+preAmt+"="+orderRemark+"="+itemInfo);
	public Object saveOrder(HttpServletRequest request,FXWholesaleReturnOrderDto dto,String time, String itemInfo,Integer version){
		JSONObject rstJson = new JSONObject();
		FXWholesaleReturnOrderDto order = new FXWholesaleReturnOrderDto();
		if(dto.getId() != null){
			ResultDTO<FXWholesaleReturnOrderDto> rstDto = wholesaleReturnOrderClientController.fingdOrderByOrderId(dto.getId());
			order = rstDto.getData();
			order.setVersion(version);
		}else{
			order.setVersion(0);
		}
		order.setId(dto.getId());
		order.setMerchantId(dto.getMerchantId());
		order.setMerchantName(dto.getMerchantName());
		order.setWarehouseId(dto.getWarehouseId());
		order.setWarehouseName(dto.getWarehouseName());
		order.setState(dto.getState());
		order.setRemark(dto.getRemark());
		order.setSignProvinceCode(dto.getSignProvinceCode());
		order.setSignProvinceName(dto.getSignProvinceName());
		ChinaPostOrgunit orgUnit;
		try {
			orgUnit = OpcSDKTools.getChinapostOrgunit(request);
			order.setOrgName(orgUnit.getName());
			Integer level = OpcSDKTools.getUserLevel(request);
			if(level > 0){
				if(level == 1){
					order.setProvinceOrgCode(orgUnit.getCode());
				}else if(level == 2){
					order.setProvinceOrgCode(orgUnit.getProvinceCode());
					order.setCityOrgCode(orgUnit.getCode());
				}else if(level == 3){
					order.setProvinceOrgCode(orgUnit.getProvinceCode());
					order.setCityOrgCode(orgUnit.getParentCode());
					order.setRegionOrgCode(orgUnit.getCode());
				}
			}
			order.setOrgLevel(level+"");
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(time != null && !"".equals(time.trim())){
			try {
				order.setApplyTime(sdf.parse(time));
			} catch (ParseException e) {
				order.setApplyTime(new Date());
			}
		}
		if(dto.getId() == null){
			order.setCreateTime(new Date());
			try {
				order.setCreateUserId(OpcSDKTools.getUserOnlyId(request));
				order.setCreateUser(OpcSDKTools.getUserName(request));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else{
			order.setUpdateTime(new Date());
			try {
				order.setUpdateUserId(OpcSDKTools.getUserOnlyId(request));
				order.setUpdateUser(OpcSDKTools.getUserName(request));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		logger.info("遍历itemList");
		JSONArray itemJsonList = JSONArray.parseArray(itemInfo);
		List<FXWholesaleReturnOrderGoodsDto> itemList = new ArrayList<FXWholesaleReturnOrderGoodsDto>();
		Integer orderGoodsNum = 0;
		Double orderAmt = 0.00;
		if(itemJsonList!=null && itemJsonList.size() > 0){
			for(Object item : itemJsonList){
				JSONObject json = (JSONObject) item;
				FXWholesaleReturnOrderGoodsDto goods = new FXWholesaleReturnOrderGoodsDto();
				goods.setId(dto.getId());
				goods.setOrderNo(dto.getOrderNo());
				goods.setBoxNum(json.getInteger("num") == null ? 0:json.getInteger("num"));
				goods.setItemId(json.getLong("itemId"));
				goods.setItemName(json.getString("itemName"));
				goods.setPlanAmt(json.getBigDecimal("amount"));
				goods.setPlanNum(json.getInteger("purchaseNum"));
//				goods.setSku("");
				goods.setTaxRate(json.getBigDecimal("rate"));
				goods.setUnit(json.getString("unit"));
				goods.setUnitPrice(json.getBigDecimal("price") == null ? new BigDecimal(0) : json.getBigDecimal("price"));
				orderGoodsNum += json.getInteger("purchaseNum");
				orderAmt += json.getDouble("amount");
				itemList.add(goods);
			}
/*			order.setDeleteFlag(0);*/
			order.setPlanNum(orderGoodsNum);
			order.setPlanAmt(new BigDecimal(orderAmt));
			//保存订单和订单商品
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("order", order);
			params.put("itemList", itemList);
			ResultDTO<Object> rst = wholesaleReturnOrderClientController.saveOrderInfo(params);
			
			rstJson.put("state", rst.getCode());
			rstJson.put("msg", rst.getMsg());
		}else{
			rstJson.put("state", "0001");
			rstJson.put("msg", "订单商品信息为空");
		}
		return rstJson;
	}
	
	@RequestMapping(value = "/getList")
	public Map<String, Object> getList(HttpServletRequest request,FXWholesaleReturnOrderDto fxWholesaleReturnOrderDto,FXWholesaleOrderParam fxWholesaleOrderParam,Integer pageNum){
		String orgCode;
		Map<String,Object> params = new HashMap<String, Object>();
		try {
			if(fxWholesaleReturnOrderDto.getState() != null && fxWholesaleReturnOrderDto.getState() == -1){
				fxWholesaleReturnOrderDto.setState(null);
			}
			params.put("orderNo", fxWholesaleReturnOrderDto.getOrderNo());
			params.put("signProvinceCode", fxWholesaleReturnOrderDto.getSignProvinceCode());
			params.put("state",  fxWholesaleReturnOrderDto.getState());
			params.put("merchantId", fxWholesaleReturnOrderDto.getMerchantId());
			params.put("warehouseId", fxWholesaleReturnOrderDto.getWarehouseId());
			params.put("applyBeginTime", fxWholesaleOrderParam.getApplyBeginTime());
			params.put("applyEndTime", fxWholesaleOrderParam.getApplyEndTime());
			params.put("whReturnBeginTime", fxWholesaleOrderParam.getWhReturnBeginTime());
			params.put("whReturnEndTime", fxWholesaleOrderParam.getWhReturnEndTime());
			
			orgCode = OpcSDKTools.getOrgunitCode(request);
			String orgName = OpcSDKTools.getOrgunitName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxWholesaleReturnOrderDto.setOrgName(orgName);
			fxWholesaleReturnOrderDto.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				params.put("provinceOrgCode", orgCode);
			}
			if(userLevel.intValue()==2){
				params.put("cityOrgCode", orgCode);
			}
			if(userLevel.intValue()==3){
				params.put("regionOrgCode", orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(pageNum==null){
			pageNum = 1;
		}
		Integer pageSize = 10;
		ResultDTO<Map<String,Object>> infos =  wholesaleReturnOrderClientController.getList(params, pageNum, pageSize,null);
		return infos.getData();
	}
	
	@RequestMapping("/{orderId}/submit")
	public Object submitOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId,Integer state,String auditResult,Integer version){
		JSONObject rstJson = new JSONObject();
		rstJson.put("state", "0001");
		rstJson.put("msg", "数据请求异常");
		try {
			Map<String,Object> params = new HashMap<String, Object>();
			params.put("orderId", orderId);
			params.put("state", state);
			params.put("auditResult", auditResult);
			params.put("version", version);
			params.put("username", OpcSDKTools.getUserName(request));
			params.put("userId", OpcSDKTools.getUserOnlyId(request));
			ResultDTO<Object> rst  = wholesaleReturnOrderClientController.updateOrderState(params);
			rstJson.put("state", rst.getCode());
			rstJson.put("msg", rst.getMsg());
		} catch (Exception e) {
			rstJson.put("msg", e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	
	
	@RequestMapping("/{orderId}/delete")
	public Object deleteOrder(HttpServletRequest request,@PathVariable("orderId") Long orderId){
		JSONObject rstJson = new JSONObject();
		rstJson.put("state", "0001");
		rstJson.put("msg", "数据请求异常");
		try {
			ResultDTO<Object> orderNo = wholesaleReturnOrderClientController.deleteOrder(orderId, OpcSDKTools.getUserName(request), OpcSDKTools.getUserOnlyId(request));
				rstJson.put("state", orderNo.getCode());
				rstJson.put("msg", orderNo.getMsg());
		} catch (Exception e) {
			rstJson.put("msg", e.getMessage());
			e.printStackTrace();
		}
		return rstJson;
	}
	
	@RequestMapping("/addGoods/{provinceOrg}/{itemId}")
	public FXWholesaleOrderGoodsDto addgoods(@PathVariable("provinceOrg")String provinceOrg,@PathVariable("itemId")Long itemId){
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("signProvinceCode", provinceOrg);
		params.put("itemId", itemId);
		params.put("state", 8);
		ResultDTO<PageInfo<FXWholesaleOrderGoodsDto>> pageInfo = wholesaleOrderClientController.findOrderItemList(params, 1, 10);
		List<FXWholesaleOrderGoodsDto> itemList = pageInfo.getData().getList();
		return (itemList == null || itemList.size() == 0) ? null : itemList.get(0);
	}
}
