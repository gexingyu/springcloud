package com.ule.wholesale.fxpurchase.web.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Service
public class ContractChangeService {
	
	private static Log logger = LogFactory.getLog(ContractChangeService.class);
	
	public void showButton(HttpServletRequest request) throws Exception{
		List<String> retList = OpcSDKTools.getButtonPermissions(request);
		if (retList != null && retList.size() > 0) {
			for (String str : retList) {
				if(str.equals(FxPurchaseStateEnum.CHANGE_EDIT.getName())){
					request.setAttribute("change_edit", "show");
				}else if(str.equals(FxPurchaseStateEnum.CHANGE_SUBMIT.getName())){
					request.setAttribute("change_submit", "show");
				}else if(str.equals(FxPurchaseStateEnum.CHANGE_DEL.getName())){
					request.setAttribute("change_del", "show");
				}else if(str.equals(FxPurchaseStateEnum.CHANGE_AUDIT.getName())){
					request.setAttribute("change_audit", "show");
				}
			}
		}
	}
	
}
