package com.ule.wholesale.fxpurchase.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ule.vpsUser.api.chinapost.impl.ChinaPostOrgunitManager;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.util.DataUtil;

/**
 * 查询邮政机构信息
 * @author Administrator
 *
 */
@Controller
public class OrgUnitController {
	
	private Log log = LogFactory.getLog(OrgUnitController.class);
	
	/**
	 * 中国邮政集团》省》市》县 这里查询的是市一级
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "orgUnit/getOrgUnitParentId")
	@ResponseBody
	public List<ChinaPostOrgunit> getOrgUnitParentId(
			HttpServletRequest request){
		List<ChinaPostOrgunit> list = null;
		try{
			String parentId = DataUtil.parseString(request, "parentId");
			if (!StringUtils.isBlank(parentId)){
				//中国邮政集团公司（ID=100）
				list = ChinaPostOrgunitManager.getInstance().getChinaPostOrgunitsByParentId(Long.valueOf(parentId));
			}
		}catch(Exception e){
			log.error(e.getMessage());
		}
		return list;
	}

}
