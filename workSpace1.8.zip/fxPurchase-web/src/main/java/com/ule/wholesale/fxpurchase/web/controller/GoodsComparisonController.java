package com.ule.wholesale.fxpurchase.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.ule.fenxiao.search.ItemSearchESTools;
import com.ule.fenxiao.search.dto.MerchantItemDTO;
import com.ule.fenxiao.search.dto.PaginationList;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.CommonConstants;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.GoodsComparisonClientService;
import com.ule.wholesale.fxpurchase.api.dto.FXGoodsCompareListDto;
import com.ule.wholesale.fxpurchase.web.config.PropertiesConfiguration;
import com.ule.wholesale.fxpurchase.web.service.CommonService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Controller
@RequestMapping(value = "/goods")
public class GoodsComparisonController {
	
	private static Log logger = LogFactory.getLog(GoodsComparisonController.class);  
	
	public static final Integer PAGESIZE = 10;
	@Autowired
	private GoodsComparisonClientService goodsComparisonClientService;
	@Autowired
	private CommonService commonService;
	
	@RequestMapping(value = "/add")	
	public String toAddGoodsComparison(){
		return "/goodsComparison/addGoodsComparison";
	}
	
	@RequestMapping(value = "/{id}/edit")	
	public String toEditGoodsComparison(HttpServletRequest request,@PathVariable("id") Long id){
		FXGoodsCompareListDto fxGoodsCompareListDto = goodsComparisonClientService.selectfxGoodsComparisonById(id).getData();
		request.setAttribute("fxGoodsCompareList", fxGoodsCompareListDto);
		return "/goodsComparison/editGoodsComparison";
	}
	@RequestMapping(value = "/delete")	
	public String deleteGoodsComparison(HttpServletRequest request,Long id){
		if(id!=null){
			logger.info("------ deleteGoodsComparison id="+id+ "-------");
			goodsComparisonClientService.deleteFXGoodsComparison(id);
		}
		return "redirect:list";
	}
	
	@RequestMapping(value = "/list")	
	public String toList(){
		return "/goodsComparison/goodsComparisonList";
	}
	
	@RequestMapping(value="/{currentPage}/addGoods")
	public String addGoods(HttpServletRequest request,@PathVariable("currentPage") Integer currentPage,Model model,String flag,String index){
		try {
			List<String> merchantIdList = new ArrayList<String>();
			List<Map<String, Object>> merchantList = commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request).toString());
			if(merchantList!=null && merchantList.size()>0){
				for(Map<String, Object> map : merchantList){
					merchantIdList.add(map.get("merchantId").toString());
				}
			}
			logger.info("merchantIdList===="+merchantIdList);
			String itemId = request.getParameter("itemId");
			request.setAttribute("itemId", itemId);
			String itemName = request.getParameter("itemName");
			request.setAttribute("itemName", itemName);
			
			MerchantItemDTO dto = new MerchantItemDTO();
			dto.setIpPort(CommonConstants.searchDistrIpPort);
			dto.setAppKey(PropertiesConfiguration.itemAppkey);
			if(merchantIdList != null && merchantIdList.size()>0){
				dto.setMerchantIds(merchantIdList);
			}else {
				dto.setMerchantId(-System.currentTimeMillis());
			}
			dto.setStartIndex((currentPage-1)*PAGESIZE);
			dto.setPageSize(PAGESIZE);
			
			if(itemId!=null && !"".equals(itemId)) dto.setItemId(Long.valueOf(itemId));
			if(itemName!=null && !"".equals(itemName)) dto.setItemName(itemName);
			
			PaginationList<MerchantItemDTO> itemList = ItemSearchESTools.searchItem(dto);itemList.getTotalPages();
			int total = itemList.getTotalRecords();
			int totalPage = total%PAGESIZE==0 ? total/PAGESIZE : total/PAGESIZE + 1;
			model.addAttribute("flag", flag);
			model.addAttribute("index", index);
			model.addAttribute("itemList",itemList);
			model.addAttribute("totalPage",totalPage);
			model.addAttribute("currentPage", currentPage);
		} catch (Exception e) {
			logger.error("error", e);
		}
		return "goodsComparison/addGoods";
	}

}

@RestController
@RequestMapping(value = "/goodsRest")
class GoodsComparisonRestController{
	
	private static Log logger = LogFactory.getLog(GoodsComparisonRestController.class);  
	
	public static final Integer PAGESIZE = 10;
	
	@Autowired
	private GoodsComparisonClientService goodsComparisonClientService;
	@Autowired
	private CommonService commonService;
	
	@RequestMapping(value = "/saveComparison")
	public Object saveGoodsComparison(HttpServletRequest request,FXGoodsCompareListDto fxGoodsCompareList){
		JSONObject result = new JSONObject();
		try {
			if(fxGoodsCompareList != null && !fxGoodsCompareList.getDmsItemCode().isEmpty()
					&& !fxGoodsCompareList.getDmsItemName().isEmpty()){
				Long userId = OpcSDKTools.getUserOnlyId(request);
				String userName = OpcSDKTools.getUserName(request);
				Integer userLevel = OpcSDKTools.getUserLevel(request);
				String orgName = OpcSDKTools.getOrgunitName(request);
				ChinaPostOrgunit chinapostOrgunit =	OpcSDKTools.getChinapostOrgunit(request);
				fxGoodsCompareList.setOrgName(orgName);
				fxGoodsCompareList.setOrgLevel(userLevel.toString());
				if(userLevel.intValue()==1){
					fxGoodsCompareList.setProvinceOrgCode(chinapostOrgunit.getCode());
				}
				if(userLevel.intValue()==2){
					fxGoodsCompareList.setCityOrgCode(chinapostOrgunit.getCode());
					fxGoodsCompareList.setProvinceOrgCode(chinapostOrgunit.getProvinceCode());
				}
				if(userLevel.intValue()==3){
					fxGoodsCompareList.setRegionOrgCode(chinapostOrgunit.getCode());
					fxGoodsCompareList.setCityOrgCode(chinapostOrgunit.getParentCode());
					fxGoodsCompareList.setProvinceOrgCode(chinapostOrgunit.getProvinceCode());
				}
				fxGoodsCompareList.setCreateUser(userName);
				fxGoodsCompareList.setCreateTime(new Date());
				fxGoodsCompareList.setState(0);
				//检验dms商品编码是否存在
				FXGoodsCompareListDto dto = new FXGoodsCompareListDto();
				dto.setDmsItemCode(fxGoodsCompareList.getDmsItemCode());
				dto.setSignProvinceCode(fxGoodsCompareList.getSignProvinceCode());
				ResultDTO<List<FXGoodsCompareListDto>> resultDTO = goodsComparisonClientService.getFXGoodsCompareListByParam(dto);
				List<FXGoodsCompareListDto> list = resultDTO.getData();
				if(list!=null && list.size()>0){
					result.put("result", "0003");
					result.put("msg", "当前机构下的DMS商品编码已存在");
					return result;
				}
				dto.setDmsItemCode(null);
				dto.setItemCode(fxGoodsCompareList.getItemCode());
				resultDTO = goodsComparisonClientService.getFXGoodsCompareListByParam(dto);
				list = resultDTO.getData();
				if(list!=null && list.size()>0){
					result.put("result", "0004");
					result.put("msg", "当前机构下的OPC商品已存在");
					return result;
				}
				goodsComparisonClientService.saveFXGoodsCompareList(fxGoodsCompareList);
				result.put("result", "0000");
				result.put("msg", "保存成功");
			}else {
				result.put("result", "0001");
				result.put("msg", "保存失败");
			}
		} catch (Exception e) {
			result.put("result", "0001");
			result.put("msg", "保存失败");
			logger.error("saveGoodsComparison error : "+e.getMessage(),e);
		}
		return result;
	}
	@RequestMapping(value = "/editComparison")
	public Object editComparison(HttpServletRequest request,FXGoodsCompareListDto fxGoodsCompareList){
		JSONObject result = new JSONObject();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			if(fxGoodsCompareList != null && fxGoodsCompareList.getId() != 0){
			FXGoodsCompareListDto fxGoodsCompareList2 = 
					goodsComparisonClientService.selectfxGoodsComparisonById(fxGoodsCompareList.getId()).getData();
			if(fxGoodsCompareList2 == null){
				result.put("result", "0002");
				result.put("msg", "保存失败,修改的商品对照记录不存在");
				return result;
			} 
				fxGoodsCompareList.setUpdateUser(userName);
				fxGoodsCompareList.setUpdateTime(new Date());
				//检验dms商品编码是否存在
				FXGoodsCompareListDto dto = new FXGoodsCompareListDto();
				dto.setDmsItemCode(fxGoodsCompareList.getDmsItemCode());
				dto.setSignProvinceCode(fxGoodsCompareList.getSignProvinceCode());
				ResultDTO<List<FXGoodsCompareListDto>> resultDTO = goodsComparisonClientService.getFXGoodsCompareListByParam(dto);
				List<FXGoodsCompareListDto> list = resultDTO.getData();
				if(list!=null && list.size()>1){
					result.put("result", "0003");
					result.put("msg", "当前机构下的DMS商品编码已存在");
					return result;
				}else if(list!=null && list.size()==1) {
					if(list.get(0).getId() != fxGoodsCompareList.getId()){
						result.put("result", "0003");
						result.put("msg", "当前机构下的DMS商品编码已存在");
						return result;
					}
				}
				dto.setDmsItemCode(null);
				dto.setItemCode(fxGoodsCompareList.getItemCode());
				resultDTO = goodsComparisonClientService.getFXGoodsCompareListByParam(dto);
				list = resultDTO.getData();
				if(list!=null && list.size()>1){
					result.put("result", "0004");
					result.put("msg", "当前机构下的OPC商品已存在");
					return result;
				}else if(list!=null && list.size()==1) {
					if(list.get(0).getId() != fxGoodsCompareList.getId()){
						result.put("result", "0004");
						result.put("msg", "当前机构下的OPC商品已存在");
						return result;
					}
				}
				goodsComparisonClientService.updateFXGoodsComparison(fxGoodsCompareList);
				result.put("result", "0000");
				result.put("msg", "保存成功");
			}else {
				result.put("result", "0001");
				result.put("msg", "保存失败");
			}
		} catch (Exception e) {
			result.put("result", "0001");
			result.put("msg", "保存失败");
			logger.error("saveGoodsComparison error : "+e.getMessage(),e);
		}
		return result;
	}
	
	/**
	 * 根据条件分页查询
	 * @param pageNo
	 * @param pageSize
	 * @return pageInfo
	 */
	@RequestMapping(value = "/getList",method = RequestMethod.POST)
	public Map<String, Object> getGoodsCompareListByPage(HttpServletRequest request,
			FXGoodsCompareListDto fxGoodsCompareList,Integer pageNum){
		String orgCode;
		try {
			orgCode = OpcSDKTools.getOrgunitCode(request);
			String orgName = OpcSDKTools.getOrgunitName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxGoodsCompareList.setOrgName(orgName);
			fxGoodsCompareList.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxGoodsCompareList.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxGoodsCompareList.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxGoodsCompareList.setRegionOrgCode(orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(pageNum==null){
			pageNum = 1;
		}
		Integer pageSize = 10;
		ResultDTO<Map<String, Object>> pageInfo = goodsComparisonClientService.getGoodsCompareListByPage(fxGoodsCompareList, pageNum, pageSize);
		return pageInfo.getData();
	}
	
	/**
	 * 获取已启用的批发机构
	 * */
	@RequestMapping(value = "/getAgency")
	public Map<String, Object> getAgency(HttpServletRequest request,Long signCode,Long level){
		Map<String, Object> resultMap = new HashMap<String, Object>();		
		ResultDTO<Map<String, Object>>list = goodsComparisonClientService.getAgency(signCode, level);
		resultMap.put("result", list.getData());
		return resultMap;
	}
	
	@RequestMapping(value="/{itemId}/addGoods")
	public Map<String, Object> addGoods(HttpServletRequest request,@PathVariable("itemId") String itemId,String flag,String index){
		Map<String, Object> resultMap  = new HashMap<String, Object>();
		try {
			List<String> merchantIdList = new ArrayList<String>();
			List<Map<String, Object>> merchantList = commonService.getUleMerchantList(OpcSDKTools.getOrgunitId(request).toString());
			if(merchantList!=null && merchantList.size()>0){
				for(Map<String, Object> map : merchantList){
					merchantIdList.add(map.get("merchantId").toString());
				}
			}		
			MerchantItemDTO dto = new MerchantItemDTO();
			dto.setIpPort(CommonConstants.searchDistrIpPort);
			dto.setAppKey(PropertiesConfiguration.itemAppkey);
			dto.setMerchantIds(merchantIdList);
			dto.setStartIndex(0);
			dto.setPageSize(PAGESIZE);
			
			if(itemId!=null && !"".equals(itemId)) dto.setItemId(Long.valueOf(itemId));
			
			PaginationList<MerchantItemDTO> itemList = ItemSearchESTools.searchItem(dto);itemList.getTotalPages();
			int total = itemList.getTotalRecords();
			if(total > 0){
				resultMap.put("result", "0000");
				resultMap.put("dto", itemList.get(0));
			}else {
				resultMap.put("result", "0001");
			}
		} catch (Exception e) {
			logger.error("error", e);
		}
		return resultMap;
	}
	
	@RequestMapping(value = "/getGoodsCompare",method = RequestMethod.POST)
	public Map<String, Object> getGoodsCompare(HttpServletRequest request,
			FXGoodsCompareListDto fxGoodsCompareList){
		Map<String, Object> resultMap  = new HashMap<String, Object>();
		String orgCode;
		try {
			orgCode = OpcSDKTools.getOrgunitCode(request);
			String orgName = OpcSDKTools.getOrgunitName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxGoodsCompareList.setOrgName(orgName);
			fxGoodsCompareList.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxGoodsCompareList.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxGoodsCompareList.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxGoodsCompareList.setRegionOrgCode(orgCode);
			}
			ResultDTO<List<FXGoodsCompareListDto>> resultDTO = goodsComparisonClientService.getFXGoodsCompareListByParam(fxGoodsCompareList);
			List<FXGoodsCompareListDto> list = resultDTO.getData();
			if(list!=null && list.size()>0){
				resultMap.put("result", "0000");
				resultMap.put("dto", list.get(0));
			}else {
				resultMap.put("result", "0001");
			}
		} catch (Exception e) {
			logger.error("error", e);
		}
			return resultMap;
	}
}
