package com.ule.wholesale.fxpurchase.web.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.BankInfoClientService;
import com.ule.wholesale.fxpurchase.api.client.ContractClientService;
import com.ule.wholesale.fxpurchase.api.client.ContractItemClientService;
import com.ule.wholesale.fxpurchase.api.client.OperationLogClientService;
import com.ule.wholesale.fxpurchase.api.client.SupplierInfoClientService;
import com.ule.wholesale.fxpurchase.api.dto.FXContractInfoDto;
import com.ule.wholesale.fxpurchase.api.dto.FXContractItemListDto;
import com.ule.wholesale.fxpurchase.api.dto.FXOperationLogDto;
import com.ule.wholesale.fxpurchase.api.dto.FXSupplierInfoDto;
import com.ule.wholesale.fxpurchase.web.service.ContractInfoService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

@Controller
public class ContractController {
	
	public static final Integer PAGESIZE = 10;
	
	private Log log = LogFactory.getLog(ContractController.class);
	@Autowired
	private ContractInfoService contractInfoService;
	@Autowired
	private ContractClientService contractClientService;
	@Autowired
	private SupplierInfoClientService supplierInfoClientService;
	@Autowired
	private BankInfoClientService bankInfoClientService;
	@Autowired
	private ContractItemClientService contractItemClientService;
	@Autowired
	private OperationLogClientService operationLogClientService;
	
	 
	@RequestMapping(value="contract/list")
	public String toContractList(HttpServletRequest request){
		try{
			//设置按钮权限
			contractInfoService.showButton(request);
			return "contract/contract_list";
		}catch(Exception e){
			log.error("error", e);
		}
		return null;
	}
	
	/**
	 * 正常的查询
	 * @param request
	 * @param currentPage
	 * @return
	 */
	@RequestMapping(value="contract/{currentPage}/{flag}/doQuery")
	public String doQuery(HttpServletRequest request,@PathVariable("currentPage") Integer currentPage,@PathVariable("flag") String flag){
		try{
			String orgunitCode = OpcSDKTools.getOrgunitCode(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			
			Map<String,Object> params = new HashMap<String,Object>();
			if(flag!=null && flag.equals("general")){
				//查询条件
				String contractCode = request.getParameter("contractCode");
				String supplierId = request.getParameter("supplierId");
				String supplierName = request.getParameter("supplierName");
				String status = request.getParameter("status");
				String settleType = request.getParameter("settleType");
				if(contractCode!=null && !"".equals(contractCode)) params.put("contractCode", contractCode);
				if(supplierId!=null && !"".equals(supplierId)) params.put("supplierId", supplierId);
				if(supplierName!=null && !"".equals(supplierName)) params.put("supplierName", supplierName);
				if(status!=null && !"".equals(status)) params.put("status", status);
				if(settleType!=null && !"".equals(settleType)) params.put("settleType", settleType);
			}else if(flag!=null && flag.equals("fast")){
				//标签查询
				String statusStr = request.getParameter("statusStr");
				String[] statusAttr = null;
				if(statusStr!=null && !"".equals(statusStr)){
					if(statusStr.indexOf(",")==-1){
						statusAttr = new String[]{statusStr};
					}else{
						statusAttr = statusStr.split(",");
					}
				}
				if(statusAttr!=null && statusAttr.length>0){
					params.put("statusAttr", statusAttr);
				}
			}
			params.put("orgLevel", userLevel);
			if(userLevel.intValue()==1){params.put("provinceOrgCode", orgunitCode);}
			if(userLevel.intValue()==2){params.put("cityOrgCode", orgunitCode);}
			if(userLevel.intValue()==3){params.put("regionOrgCode", orgunitCode);}
			
			ResultDTO<Map<String,Object>> rstDTO = contractClientService.getPageByParams(params, currentPage, PAGESIZE, "create_time desc");
			request.setAttribute("retList", rstDTO.getData().get("list"));
			request.setAttribute("currentPage", rstDTO.getData().get("pageNum"));
			request.setAttribute("totalPage", rstDTO.getData().get("pages"));
			
			//设置按钮权限
			contractInfoService.showButton(request);
		}catch(Exception e){
			log.error("error", e);
		}
		return "contract/contract_list_record";
	}
	
	/**
	 * 跳转新建合同页面
	 * @param request
	 * @return
	 */
	@RequestMapping(value="contract/toAdd")
	public String toAdd(HttpServletRequest request){
		try{
			String orgunitCode = OpcSDKTools.getOrgunitCode(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			//获取供应商
			FXSupplierInfoDto fxSupplierInfo = new FXSupplierInfoDto();
			fxSupplierInfo.setStatus(2);//合同审核通过
			fxSupplierInfo.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){fxSupplierInfo.setProvinceOrgCode(orgunitCode);}
			if(userLevel.intValue()==2){fxSupplierInfo.setCityOrgCode(orgunitCode);}
			if(userLevel.intValue()==3){fxSupplierInfo.setRegionOrgCode(orgunitCode);}
			
			ResultDTO<List<FXSupplierInfoDto>> rstDTO = supplierInfoClientService.getSupplierList(fxSupplierInfo);
			request.setAttribute("supplierList", rstDTO.getData());
			//获取银行信息
			ResultDTO<Map<Object, Object>> rstBank = bankInfoClientService.findBankInfoList();
			Map allBankMessage = rstBank.getData();
			request.setAttribute("allBankMessage", allBankMessage);
			//设置最小最大时间
			Calendar calendar = Calendar.getInstance();
			int year = calendar.get(Calendar.YEAR);
			int month = calendar.get(Calendar.MONTH)+1;
			request.setAttribute("minDay", year+"-"+month+"-1");
			request.setAttribute("maxDay", year+"-"+month+"-28");
		}catch(Exception e){
			log.error("error", e);
		}
		return "contract/contract_add";
	}
	
	@RequestMapping(value="contract/{contractId}/toDetail")
	public String toDetail(HttpServletRequest request,@PathVariable("contractId") Long contractId){
		try{
			//根据contractId查询合同信息
			FXContractInfoDto contractInfo = contractClientService.selectDtoByPrimaryKey(contractId);
			request.setAttribute("contractInfo", contractInfo);
			//查询日志
			List<FXOperationLogDto> optLogList = operationLogClientService.getOperationLogList(contractId.toString(),FxPurchaseStateEnum.OPLOG_TYPE_2.getIndex());
			request.setAttribute("optLogList", optLogList);
			//权限
			Integer status = contractInfo.getStatus();
//			int buttonStatus = fxContractInfoService.showButton(request, status);
			request.setAttribute("status", status);
//			request.setAttribute("buttonStatus", buttonStatus);
			//设置按钮权限
			contractInfoService.showButton(request);
		}catch(Exception e){
			log.error("error", e);
		}
		return "contract/contract_detail";
	}
	
	
	@RequestMapping(value="contract/{contractId}/toEdit")
	public String toEdit(HttpServletRequest request,@PathVariable("contractId") Long contractId){
		try{
			//获取供应商
			FXSupplierInfoDto fxSupplierInfo = new FXSupplierInfoDto();
			fxSupplierInfo.setStatus(2);
			ResultDTO<List<FXSupplierInfoDto>> rstDTO = supplierInfoClientService.getSupplierList(fxSupplierInfo);
			request.setAttribute("supplierList", rstDTO.getData());
			//获取银行信息
			ResultDTO<Map<Object, Object>> rstBank = bankInfoClientService.findBankInfoList();
			Map allBankMessage = rstBank.getData();
			request.setAttribute("allBankMessage", allBankMessage);
			//根据合同ID获取合同
			FXContractInfoDto contractInfoDto = contractClientService.selectDtoByPrimaryKey(contractId);
			request.setAttribute("contractInfo", contractInfoDto);
			//设置最小最大时间
			Calendar calendar = Calendar.getInstance();
			int year = calendar.get(Calendar.YEAR);
			int month = calendar.get(Calendar.MONTH)+1;
			request.setAttribute("minDay", year+"-"+month+"-1");
			request.setAttribute("maxDay", year+"-"+month+"-28");
			Date begin = contractInfoDto.getContractAvailableBegin();
			Date now = new Date();
			if(begin.getTime()>now.getTime()){
				request.setAttribute("minDate", now);
			}else{
				request.setAttribute("minDate", begin);
			}
		}catch(Exception e){
			log.error("error", e);
		}
		return "contract/contract_edit";
	}
	
	
	/**
	 * 跳转合同变更页面
	 * @param request
	 * @return
	 */
	@RequestMapping(value="contract/{contractId}/toChange")
	public String toContractChangePage(HttpServletRequest request,@PathVariable("contractId") Long contractId){
		String contractItemIds = request.getParameter("contractItemIds");
		if(contractItemIds!=null && !"".equals(contractItemIds)){
			List<FXContractItemListDto> contractItemList = new ArrayList<FXContractItemListDto>();
			for(int i=0; i<contractItemIds.split(",").length; i++){
				FXContractItemListDto contractItem = contractItemClientService.selectByPrimaryKey(Long.valueOf(contractItemIds.split(",")[i]));
				contractItemList.add(contractItem);
			}
			request.setAttribute("contractItemList", contractItemList);
		}
		
		FXContractInfoDto contractInfo = contractClientService.selectDtoByPrimaryKey(contractId);
		request.setAttribute("contractInfo", contractInfo);
		return "contract/contract_change";
	}
	
	@RequestMapping(value="contract/{contractId}/toContractItemStopPage")
	public String toContractItemStopPage(HttpServletRequest request,@PathVariable("contractId") Long contractId){
		String contractItemIds = request.getParameter("contractItemIds");
		if(contractItemIds!=null && !"".equals(contractItemIds)){
			List<FXContractItemListDto> contractItemList = new ArrayList<FXContractItemListDto>();
			for(int i=0; i<contractItemIds.split(",").length; i++){
				FXContractItemListDto contractItem = contractItemClientService.selectByPrimaryKey(Long.valueOf(contractItemIds.split(",")[i]));
				contractItemList.add(contractItem);
			}
			request.setAttribute("contractItemList", contractItemList);
		}
		FXContractInfoDto contractInfo = contractClientService.selectDtoByPrimaryKey(contractId);
		request.setAttribute("contractInfo", contractInfo);
		if(contractInfo!=null && contractInfo.getSupplierId()!=null){
			ResultDTO<FXSupplierInfoDto> rstDTO = supplierInfoClientService.getSupplierDetail(contractInfo.getSupplierId());
			request.setAttribute("supplierName", rstDTO.getData()==null ? "" : rstDTO.getData().getSupplierName());
		}
		return "contract/contract_item_stop";
	}
	
}

@RestController
class ContractManageRestController{
	
	private Log log = LogFactory.getLog(ContractManageRestController.class);
	@Autowired
	private ContractClientService contractClientService;
	@Autowired
	private OperationLogClientService operationLogClientService;
	
	@RequestMapping(value="restContract/addContract")
	public JSONObject addContract(HttpServletRequest request, FXContractInfoDto fxContractInfo){
		JSONObject retJson = new JSONObject();
		try{
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			ChinaPostOrgunit chinaPostOrgunit = OpcSDKTools.getChinapostOrgunit(request);
			String availableBegin = request.getParameter("availableBegin");
			String availableEnd = request.getParameter("availableEnd");
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			boolean blean = contractClientService.compareContractAvailable(fxContractInfo.getSupplierId(), null, format.parse(availableBegin), format.parse(availableEnd));
			if(!blean){
				retJson.put("success", 9);
				retJson.put("retMsg", "同一个供应商合同有效期不能重叠！");
				return retJson;
			}
			
			fxContractInfo.setPrepayRate(fxContractInfo.getPrepayRate()==null ? null : fxContractInfo.getPrepayRate()/100);
			fxContractInfo.setCreateUser(userName);
			fxContractInfo.setCreateUserId(userId);
			fxContractInfo.setCreateTime(new Date());
			fxContractInfo.setOrgName(chinaPostOrgunit.getName());
			fxContractInfo.setOrgLevel(userLevel.toString());
			fxContractInfo.setContractAvailableBegin(format.parse(availableBegin));
			fxContractInfo.setContractAvailableEnd(format.parse(availableEnd));
			if(userLevel.intValue()==1){
				fxContractInfo.setProvinceOrgCode(chinaPostOrgunit.getCode());
			}
			if(userLevel.intValue()==2){
				fxContractInfo.setProvinceOrgCode(chinaPostOrgunit.getProvinceCode());
				fxContractInfo.setCityOrgCode(chinaPostOrgunit.getCode());
			}
			if(userLevel.intValue()==3){
				fxContractInfo.setProvinceOrgCode(chinaPostOrgunit.getProvinceCode());
				fxContractInfo.setCityOrgCode(chinaPostOrgunit.getParentCode());
				fxContractInfo.setRegionOrgCode(chinaPostOrgunit.getCode());
			}
			//保存合同
			Long contractId = contractClientService.addContract(fxContractInfo);
			if(contractId!=null){
				//生成合同编号
				contractClientService.createContractCode(contractId);
			}
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(contractId.toString());//存放被执行操作表的主键
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_2.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_0.getName());//事件类型
				if(fxContractInfo.getStatus().intValue()==1){
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_1.getName());//事件类型
				}
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败："+ex.getMessage());
			}
			retJson.put("success", 1);
			return retJson;
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			return retJson;
		}
	}
	
	@RequestMapping(value="restContractManage/editContract")
	public JSONObject editContract(HttpServletRequest request, FXContractInfoDto fxContractInfo){
		JSONObject retJson = new JSONObject();
		try{
			String contractId = request.getParameter("contractId");
			if(contractId==null || "".equals(contractId)){
				throw new Exception("contractId===="+contractId);
			}
			
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			String availableBegin = request.getParameter("availableBegin");
			String availableEnd = request.getParameter("availableEnd");
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			boolean blean = contractClientService.compareContractAvailable(fxContractInfo.getSupplierId(),Long.valueOf(contractId), format.parse(availableBegin), format.parse(availableEnd));
			if(!blean){
				retJson.put("success", 9);
				retJson.put("retMsg", "同一个供应商合同有效期不能重叠！");
				return retJson;
			}
			
			fxContractInfo.setId(Long.valueOf(contractId));
			fxContractInfo.setPrepayRate(fxContractInfo.getPrepayRate()==null ? null : fxContractInfo.getPrepayRate()/100);
			fxContractInfo.setUpdateUser(userName);
			fxContractInfo.setUpdateUserId(userId);
			fxContractInfo.setUpdateTime(new Date());
			fxContractInfo.setContractAvailableBegin(format.parse(availableBegin));
			fxContractInfo.setContractAvailableEnd(format.parse(availableEnd));
			contractClientService.editContract(fxContractInfo);
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(contractId);
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_2.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_0.getName());//事件类型
				if(fxContractInfo.getStatus().intValue()==1){
					optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_1.getName());//事件类型
				}
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败："+ex.getMessage());
			}
			retJson.put("success", 1);
			return retJson;
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			return retJson;
		}
	}
	
	@RequestMapping(value="restContract/{contractId}/delContract")
	public JSONObject delContract(HttpServletRequest request,@PathVariable("contractId") Long contractId){
		JSONObject retJson = new JSONObject();
		try{
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			FXContractInfoDto info = contractClientService.selectDtoByPrimaryKey(contractId);
			info.setDeleteFlag(FxPurchaseStateEnum.STATE_CONTRACT_0_2.getIndex());//删除状态 1已删除
			info.setUpdateTime(new Date());
			info.setUpdateUser(userName);
			info.setUpdateUserId(userId);
			contractClientService.delContract(info);
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(contractId.toString());//存放被执行操作表的主键
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_2.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_0_2.getName());//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败："+ex.getMessage());
			}
			
			retJson.put("success", 1);
			retJson.put("retMsg", "删除成功！");
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "删除失败！");
		}
		return retJson;
	}
	
	@RequestMapping(value="restContractManage/{contractId}/submitContract")
	public JSONObject submitContract(HttpServletRequest request,@PathVariable("contractId") Long contractId){
		JSONObject retJson = new JSONObject();
		try{
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			
			FXContractInfoDto info = contractClientService.selectDtoByPrimaryKey(contractId);
			info.setStatus(FxPurchaseStateEnum.STATE_CONTRACT_0_1.getIndex());//提交审核
			info.setUpdateTime(new Date());
			info.setUpdateUser(userName);
			info.setUpdateUserId(userId);
			contractClientService.submitContract(info);
			
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(contractId.toString());//存放被执行操作表的主键
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_2.getIndex());//业务类型：2表示合同
				optLog.setEventType(FxPurchaseStateEnum.STATE_CONTRACT_0_1.getName());//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败："+ex.getMessage());
			}
			
			retJson.put("success", 1);
			retJson.put("retMsg", "提交成功！");
		}catch(Exception e){
			log.error("error", e);
			retJson.put("success", 0);
			retJson.put("retMsg", "提交失败！");
		}
		return retJson;
	}
	
	/**
	* @Description: 审核合同 
	* @param request
	* @param id
	* @param status
	* @param reason
	* @return String    返回类型 
	* @throws
	 */
	@RequestMapping(value="contract/contractCheck")
	public JSONObject contractCheck(HttpServletRequest request,@RequestParam("id") Long id,
			@RequestParam("status") Integer status,String reason,String eventType){
		JSONObject retJson = new JSONObject();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			FXContractInfoDto contractInfo = contractClientService.selectDtoByPrimaryKey(id);
			if(status.intValue()==2){//采购审核通过
				contractInfo.setPurchaseAuditUserId(userId);
				contractInfo.setPurchaseAuditUser(userName);
				contractInfo.setPurchaseAuditTime(new Date());
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_2.getName();
			}
			if(status.intValue()==3){//采购审核拒绝
				contractInfo.setPurchaseAuditUserId(userId);
				contractInfo.setPurchaseAuditUser(userName);
				contractInfo.setPurchaseAuditTime(new Date());
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_3.getName();
			}
			if(status.intValue()==4){//财务审核通过
				contractInfo.setFinancialAuditUserId(userId);
				contractInfo.setFinancialAuditUser(userName);
				contractInfo.setFinancialAuditTime(new Date());
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_4.getName();
			}
			if(status.intValue()==5){//财务审核拒绝
				contractInfo.setFinancialAuditUserId(userId);
				contractInfo.setFinancialAuditUser(userName);
				contractInfo.setFinancialAuditTime(new Date());
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_5.getName();
			}
			if(status.intValue()==6){//法务审核通过、拒绝
				contractInfo.setLawAuditUserId(userId);
				contractInfo.setLawAuditUser(userName);
				contractInfo.setLawAuditTime(new Date());
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_6.getName();
			}
			if(status.intValue()==7){//法务审核通过、拒绝
				contractInfo.setLawAuditUserId(userId);
				contractInfo.setLawAuditUser(userName);
				contractInfo.setLawAuditTime(new Date());
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_7.getName();
			}
			if(status.intValue()==8){//作废
				contractInfo.setCancelTime(new Date());
				contractInfo.setCancelUser(userName);
				contractInfo.setCancelUserId(userId);
				eventType = FxPurchaseStateEnum.STATE_CONTRACT_7.getName();
			}
			contractInfo.setStatus(status);
			if(null!=reason && ""!=reason){
				contractInfo.setReason(reason);
			}
			contractInfo.setUpdateTime(new Date());
			contractInfo.setUpdateUser(userName);
			contractInfo.setUpdateUserId(userId);
			contractClientService.editContract(contractInfo);
			try{
				FXOperationLogDto optLog = new FXOperationLogDto();
				optLog.setBizCode(id.toString());//存放被执行操作表的主键
				optLog.setType(FxPurchaseStateEnum.OPLOG_TYPE_2.getIndex());//业务类型：2表示合同
				optLog.setEventType(eventType);//事件类型
				optLog.setUserId(userId);
				optLog.setUserName(userName);
				optLog.setOpDate(new Date());
				if(null!=reason && ""!=reason){
					optLog.setRemark(reason);
				}
				operationLogClientService.saveOpLog(optLog);
			}catch(Exception ex){
				log.error("保存日志失败："+ex.getMessage());
			}
			retJson.put("retCode", 1);
			retJson.put("retMsg", eventType+"成功！");
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			retJson.put("retCode", 0);
			retJson.put("retMsg", eventType+"失败！");
		}
		return retJson;
	}
	
}
