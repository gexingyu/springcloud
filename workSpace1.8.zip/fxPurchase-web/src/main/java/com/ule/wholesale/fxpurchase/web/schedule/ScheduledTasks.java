package com.ule.wholesale.fxpurchase.web.schedule;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ule.wholesale.common.util.HttpClientUtil;
import com.ule.wholesale.fxpurchase.api.constants.ClientConstants;
/**
 * spring boot 自带定时
 */
@Component
@Configurable
@EnableScheduling
public class ScheduledTasks {

	private static Logger logger = LoggerFactory.getLogger(ScheduledTasks.class);
	@Autowired
	private LoadBalancerClient loadBalancer;
	@Scheduled(fixedRate = 1000 * 60 * 3)
    public void reportCurrentTime(){
		try {
			logger.info("Scheduling Tasks start: The time is now " + dateFormat ().format (new Date ()));
//			commonService.sendMsg();
			Map<String, String> head = new HashMap<String, String>();
			head.put("appkey", "test1");
			head.put("token", "1sssssssd");
			String uri = getRestUrl(ClientConstants.SERVICE_NAME);
			HttpClientUtil.sendPost(uri+"/"+ClientConstants.SERVER_PATH+"/api/common/sendMsg", head, null, null);
	        logger.info("Scheduling Tasks end: The time is now " + dateFormat ().format (new Date ()));
		} catch (Exception e) {
			logger.error("定时发送消息异常，当前时间"+new Date()+" error:"+e.getMessage());
			e.printStackTrace();
		}
    }

    //6：20点到20：20点，每小时执行一次
	//处理订单创建消息消费反馈和订单收货货、退货的反馈
    @Scheduled(cron = "0 0/2 8-23  * * * ")
    public void handlerOrderStateFeedback(){
        Thread current = Thread.currentThread();  
        logger.info("ScheduledTasks.handlerOrderStateFeedback 定时任务:"+current.getId() + ",name:"+current.getName());
        try {
        	Map<String, String> head = new HashMap<String, String>();
			head.put("appkey", "test1");
			head.put("token", "1sssssssd");
			String uri = getRestUrl(ClientConstants.SERVICE_NAME);
			HttpClientUtil.sendPost(uri+"/"+ClientConstants.SERVER_PATH+"/api/common/handlerMsg", head, null, null);
//        	commonService.handlerOrderStateFeedback();
		} catch (Exception e) {
			e.printStackTrace();
		}
        logger.info("ScheduledTasks.handlerOrderStateFeedback  By Cron: The time is now " + dateFormat ().format (new Date ()));
    }
//    public void reportCurrentByCron(){
//    	// 间隔1分钟,执行工单上传任务              
//    	Thread current = Thread.currentThread();  
//    	System.out.println("定时任务2:"+current.getId());
//    	logger.info("ScheduledTest.executeUploadTask 定时任务2:"+current.getId() + ",name:"+current.getName());
//    	System.out.println ("Scheduling Tasks Examples By Cron: The time is now " + dateFormat ().format (new Date ()));
//    }

    private SimpleDateFormat dateFormat(){
        return new SimpleDateFormat ("HH:mm:ss");
    }
    public String getRestUrl(String serviceId) {
        ServiceInstance instance = loadBalancer.choose(serviceId);
        URI uri = instance.getUri();
        return uri.toString();
    }
}
