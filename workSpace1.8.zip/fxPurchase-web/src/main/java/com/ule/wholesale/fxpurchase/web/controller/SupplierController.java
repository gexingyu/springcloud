package com.ule.wholesale.fxpurchase.web.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ule.merchant.ctoc.basic.dto.MerchantDTO;
import com.ule.merchant.merchant.ejb.client.SysPostMerchantClient;
import com.ule.vpsUser.api.common.vo.ChinaPostOrgunit;
import com.ule.wholesale.common.constants.FxPurchaseStateEnum;
import com.ule.wholesale.common.util.DataUtil;
import com.ule.wholesale.common.util.ResultDTO;
import com.ule.wholesale.fxpurchase.api.client.BankInfoClientService;
import com.ule.wholesale.fxpurchase.api.client.OperationLogClientService;
import com.ule.wholesale.fxpurchase.api.client.SupplierInfoClientService;
import com.ule.wholesale.fxpurchase.api.client.TestClientService;
import com.ule.wholesale.fxpurchase.api.dto.FXOperationLogDto;
import com.ule.wholesale.fxpurchase.api.dto.FXSupplierInfoDto;
import com.ule.wholesale.fxpurchase.api.dto.FXSupplierParam;
import com.ule.wholesale.fxpurchase.web.service.SupplierInfoService;
import com.ule.wholesale.fxpurchase.web.util.OpcSDKTools;

/**
 *  供应商
 * */
@Controller
@RequestMapping(value = "/supplier")
public class SupplierController {
	private static Log logger = LogFactory.getLog(SupplierController.class); 
	@Autowired
	private SupplierInfoService supplierService;
	@Autowired
	private SupplierInfoClientService supplierClientService;
	@Autowired
	private OperationLogClientService opLogService;
	@Autowired
	private BankInfoClientService bankInfoService;
	
	/**
	 * 跳转供应商查询页面
	 * */
	@RequestMapping(value = "/list")
	public String supplierList(HttpServletRequest request){
		return toSupplierPage(request);
	}
	@RequestMapping(value = "/toSupplierPage")
	public String toSupplierPage(HttpServletRequest request){
		try{
			supplierService.showButton(request);
			return "/supplier/supplierList";
		}catch(Exception e){
			logger.error("error", e);
		}
		return null;
	}
	
	/**
	 * 查看供应商详情
	 * @param id
	 * @return FXSupplierInfo
	 * */
	@RequestMapping(value = "/{id}/detail")
	public String supplierDetail(@PathVariable Long id,HttpServletRequest request,Model model){
		return getSupplierDetail(id, request, model);
	}
	@RequestMapping(value = "/{id}/supplierDetail")
	public String getSupplierDetail(@PathVariable Long id,HttpServletRequest request,Model model){
		try{
			FXSupplierInfoDto fxSupplierInfo = null;
			if(id != null){
				ResultDTO<FXSupplierInfoDto> rst = supplierClientService.getSupplierDetail(id);
				fxSupplierInfo = rst.getData();
			}
			List<FXOperationLogDto> optLogList = opLogService.getOperationLogList(id.toString(), FxPurchaseStateEnum.OPLOG_TYPE_1.getIndex());
			request.setAttribute("optLogList", optLogList);
			model.addAttribute("fxSupplierInfo", fxSupplierInfo);
			//设置权限
			supplierService.showButton(request);
			return "/supplier/supplierDetail";
		}catch(Exception e){
			logger.error("error", e);
		}
		return null;
	}
	
	/**
	 * 手动新建供应商
	 * */
	@RequestMapping(value = "/create")
	public String createSupplier(HttpServletRequest request){
		return toAddSupplier(request);
	}
	@RequestMapping(value = "/toAddSupplier")
	public String toAddSupplier(HttpServletRequest request){
		try {
			ResultDTO<Map<Object, Object>> rstBank = bankInfoService.findBankInfoList();
			Map allBankMessage = rstBank.getData();
			request.setAttribute("allBankMessage", allBankMessage);
			request.setAttribute("flag", "add");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/supplier/addSupplier";
	}
	
	/**
	 * 跳转编辑供应商
	 * @param id
	 * @return fxSupplierInfo
	 * */
	@RequestMapping(value = "/{supplierId}/edit")
	public String editSupplier(HttpServletRequest request,@PathVariable("supplierId")Long supplierId,Model model){
		return toEditSupplier(request, supplierId, model);
	}
	@RequestMapping(value = "/toEditSupplier")
	public String toEditSupplier(HttpServletRequest request,Long supplierId,Model model){
		FXSupplierInfoDto fxSupplierInfo = null;
		try {
		if(supplierId != null){
			ResultDTO<FXSupplierInfoDto>  result = supplierClientService.getSupplierDetail(supplierId);
			fxSupplierInfo = result.getData();
		}
		ResultDTO<Map<Object, Object>> rstBank = bankInfoService.findBankInfoList();
			Map<Object,Object> allBankMessage = rstBank.getData();
			request.setAttribute("allBankMessage", allBankMessage);
			request.setAttribute("flag", "add");
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("fxSupplierInfo", fxSupplierInfo);
		return "/supplier/editSupplier";
	}

	/**
	 * 跳转到商家查询页面
	 * */
	@RequestMapping(value = "/toBusSupplier")
	public String toBusSupplier(){
		
		return "/supplier/busSupplier";
	}
	
	/**
	 * 补全供应商信息
	 * */
	@RequestMapping(value = "/{merchantId}/completSupplier")
	public String completSupplier(HttpServletRequest request,@PathVariable Long merchantId,Model model){
		
		try {
			SysPostMerchantClient client1 = com.ule.merchant.merchant.util.MerchantBaseTools.getInstance().getSysPostMerchantClient();
			logger.info("SysPostMerchantClient  init success ...............client="+client1);
			MerchantDTO dto = client1.findMerchantDTOByMerchantId(merchantId);
			FXSupplierInfoDto fxSupplierInfo = new FXSupplierInfoDto();
			if(dto!=null){
				fxSupplierInfo.setCompName(dto.getCompanyName());
				fxSupplierInfo.setCompAddress(dto.getCompanyAddress());
				fxSupplierInfo.setSupplierName(dto.getCompanyName());
				fxSupplierInfo.setMerchantId(dto.getMerchantId());
				fxSupplierInfo.setMerchantName(dto.getUsrTrueName());
				fxSupplierInfo.setCompTel(dto.getCustomize4());
				fxSupplierInfo.setCompPostCode(dto.getInfo11());
				fxSupplierInfo.setContactName(dto.getContactorName());
				fxSupplierInfo.setContactTel(dto.getContactorPhone());
				fxSupplierInfo.setContactEmail(dto.getUsrMailbox());
			}
			model.addAttribute("fxSupplierInfo", fxSupplierInfo);
			ResultDTO<Map<Object, Object>> rstBank = bankInfoService.findBankInfoList();
			Map allBankMessage = rstBank.getData();
			request.setAttribute("allBankMessage", allBankMessage);
			request.setAttribute("flag", "add");
		} catch (Exception e) {
			logger.error("completSupplier SysPostMerchantClient fail");
			e.printStackTrace();
		}
		return "/supplier/busSupplierSecond";
	}
	
	/**
	 * 删除
	 * */
	@RequestMapping(value = "/deleteSupplier")
	public String deleteSupplier(HttpServletRequest request,Long id){
		if(id!=null){
			logger.info("------ deleteSupplier id="+id+ "-------");
			supplierClientService.deleteupdateFXSupplierInfo(id);
		}
		return "redirect:toSupplierPage";
	}
	
}					


@RestController
@RequestMapping(value = "/supplierRest")
class SupplierRestController{
	
	private static Log logger = LogFactory.getLog(SupplierRestController.class); 
	
	@Autowired
	private SupplierInfoClientService supplierService;
	@Autowired
	private OperationLogClientService fxOperationLogService;
	@Autowired
	private TestClientService testClient;
	
	@RequestMapping(value = "/hello")
	public String hello(){
		
		return testClient.hello("mingzhi");
	}
	/**
	 * 根据条件分页查询供应商
	 * @param pageNo
	 * @param pageSize
	 * @return pageInfo
	 */
	@RequestMapping(value = "/getSupplierListByPage",method = RequestMethod.POST)
	public Map<String,Object> getSupplierListByPage(HttpServletRequest request,FXSupplierInfoDto fxSupplierInfo,Integer pageNum){
		String orgCode;
		try {
			orgCode = OpcSDKTools.getOrgunitCode(request);
			String orgName = OpcSDKTools.getOrgunitName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			fxSupplierInfo.setOrgName(orgName);
			fxSupplierInfo.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxSupplierInfo.setProvinceOrgCode(orgCode);
			}
			if(userLevel.intValue()==2){
				fxSupplierInfo.setCityOrgCode(orgCode);
			}
			if(userLevel.intValue()==3){
				fxSupplierInfo.setRegionOrgCode(orgCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(pageNum==null){
			pageNum = 1;
		}
		Integer pageSize = 10;
		if(fxSupplierInfo!=null && fxSupplierInfo.getStatus()!=null && fxSupplierInfo.getStatus() == -1){
			fxSupplierInfo.setStatus(null);
		}
		ResultDTO<Map<String,Object>> fxsupplierInfos =  supplierService.getSupplierListByPage(fxSupplierInfo, pageNum, pageSize,null);
		return fxsupplierInfos.getData();
	}
	
	/**
	 * 审核
	 * */
	@RequestMapping(value = "/audit")
	public Map<String, Object>  audit(HttpServletRequest request,FXSupplierInfoDto fxSupplierInfo){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			String eventType = "";
			if(fxSupplierInfo.getStatus() == 1){
				eventType = "提交";
			}else if(fxSupplierInfo.getStatus() == 2){
				eventType = "审核通过";
			}else if(fxSupplierInfo.getStatus() == 3){
				eventType = "审核不通过";
			}
			logger.info("aduit supplier supplierId = "+fxSupplierInfo.getId()+", status = "+fxSupplierInfo.getStatus());
				fxSupplierInfo.setAuditUser(userName);
				fxSupplierInfo.setAuditUserId(userId);
				fxSupplierInfo.setAuditTime(new Date());
				fxSupplierInfo.setUpdateUser(userName);
				fxSupplierInfo.setUpdateUserId(userId);
				fxSupplierInfo.setUpdateTime(new Date());
				Map<String,Object> supplierInfos = new HashMap<String, Object>();
				supplierInfos.put("fxSupplierInfo", fxSupplierInfo);
			supplierService.updateFXSupplierInfo(supplierInfos);
			FXOperationLogDto log = new FXOperationLogDto();
			log.setBizCode(fxSupplierInfo.getId().toString());
			log.setEventType(eventType);
			log.setOpDate(new Date());
			log.setType(FxPurchaseStateEnum.OPLOG_TYPE_1.getIndex());
			log.setUserId(userId);
			log.setUserName(userName);
			log.setRemark(fxSupplierInfo.getReason());
			fxOperationLogService.saveOpLog(log);
			resultMap.put("result", "success");
		} catch (Exception e) {
			resultMap.put("result", "failed");
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/**
	 * 查询商家
	 * */
	@RequestMapping(value = "/findBusiness")
	public Map<String, Object> findBusiness(HttpServletRequest request){
		Map<String, Object> resultMap = null;
		String merchantId = request.getParameter("merchantId");
		String compName = request.getParameter("compName");
		if(merchantId.isEmpty() && compName.isEmpty()){
			return null;
		}
		if(merchantId.isEmpty()){
			merchantId = null;
		}
		if(compName.isEmpty()){
			compName = null;
		}
		try {
			SysPostMerchantClient client1 = com.ule.merchant.merchant.util.MerchantBaseTools.getInstance().getSysPostMerchantClient();
			logger.info("SysPostMerchantClient  init success ...............client="+client1);
			Map dto = client1.getMerchantListByParams("100", null, merchantId, compName, "11", null, "");
			dto.get(0);
			if(dto != null && dto.size() >0){
				 resultMap = dto;
			}
//			Map<String, Object> resultMap1 = new HashMap<String, Object>();
//			Map<String, Object> resultMap2 = new HashMap<String, Object>();
//			 resultMap = new HashMap<Object, Object>();
//			
//			resultMap1.put("usr_true_name", "hzhDMS省商家不改了hzhDMS省商家不改了hzhDMS省商家不改了hzhDMS省商家不改了");
//			resultMap1.put("usr_onlyid", "101165");
//			resultMap2.put("usr_true_name", "hzhDMS省商家商家不改了");
//			resultMap2.put("usr_onlyid", "101188");
//			resultMap.put(3, resultMap2);
//			resultMap.put(2, resultMap1);
//			resultMap.put(1, resultMap1);
//			resultMap.put(0, resultMap1);
		} catch (Exception e) {
			logger.error("receive SysPostMerchantClient fail !");
			e.printStackTrace();
		}
		return resultMap;
	}

	/**
	 * 新建供应商
	 * @param fxSupplierInfo
	 * @return
	 * */
	@RequestMapping(value = "/saveFxSupplierInfo")
	public  Map<String, Object> saveFxSupplierInfo(HttpServletRequest request,FXSupplierInfoDto fxSupplierInfo,FXSupplierParam fxSupplierParam){
		Map<String, Object> result = new HashMap<String, Object>(); 
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			Integer userLevel = OpcSDKTools.getUserLevel(request);
			String orgName = OpcSDKTools.getOrgunitName(request);
			ChinaPostOrgunit chinapostOrgunit =	OpcSDKTools.getChinapostOrgunit(request);
			fxSupplierInfo.setOrgName(orgName);
			fxSupplierInfo.setOrgLevel(userLevel.toString());
			if(userLevel.intValue()==1){
				fxSupplierInfo.setProvinceOrgCode(chinapostOrgunit.getCode());
			}
			if(userLevel.intValue()==2){
				fxSupplierInfo.setCityOrgCode(chinapostOrgunit.getCode());
				fxSupplierInfo.setProvinceOrgCode(chinapostOrgunit.getProvinceCode());
			}
			if(userLevel.intValue()==3){
				fxSupplierInfo.setRegionOrgCode(chinapostOrgunit.getCode());
				fxSupplierInfo.setCityOrgCode(chinapostOrgunit.getParentCode());
				fxSupplierInfo.setProvinceOrgCode(chinapostOrgunit.getProvinceCode());
			}
			if(!fxSupplierInfo.getBrandName().isEmpty()){
				fxSupplierInfo.setBrandName(DataUtil.ToDBC(fxSupplierInfo.getBrandName()));
			}
			fxSupplierInfo.setCreateUserId(userId);
			fxSupplierInfo.setCreateUser(userName);
			fxSupplierInfo.setCreateTime(new Date());
			fxSupplierInfo.setUpdateUserId(userId);
			fxSupplierInfo.setUpdateUser(userName);
			fxSupplierInfo.setUpdateTime(new Date());
			Map<String,Object> supplierInfos = new HashMap<String, Object>();
			supplierInfos.put("fxSupplierInfo", fxSupplierInfo);
			supplierInfos.put("fxSupplierParam", fxSupplierParam);
			ResultDTO<Integer> resultDTO = supplierService.saveFXSupplierInfo(supplierInfos);
			FXOperationLogDto log = new FXOperationLogDto();
			log.setBizCode(resultDTO.getMsg());
			log.setEventType("保存");
			log.setOpDate(new Date());
			log.setType(FxPurchaseStateEnum.OPLOG_TYPE_1.getIndex());
			log.setUserId(userId);
			log.setUserName(userName);
			fxOperationLogService.saveOpLog(log);
			result.put("result", "0000");
			result.put("msg", "保存成功");
		} catch (Exception e) {
			result.put("result", "0001");
			result.put("msg", "保存失败");
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 编辑供应商
	 * @param fxSupplierInfo
	 * @return
	 * */
	@RequestMapping(value = "/editFxSupplierInfo")
	public Map<String, Object> editFxSupplierInfo(HttpServletRequest request,FXSupplierInfoDto fxSupplierInfo,FXSupplierParam fxSupplierParam){
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			Long userId = OpcSDKTools.getUserOnlyId(request);
			String userName = OpcSDKTools.getUserName(request);
			fxSupplierInfo.setUpdateUser(userName);
			fxSupplierInfo.setUpdateUserId(userId);
			fxSupplierInfo.setUpdateTime(new Date());
			if(!fxSupplierInfo.getBrandName().isEmpty()){
				fxSupplierInfo.setBrandName(DataUtil.ToDBC(fxSupplierInfo.getBrandName()));
			}
			Map<String,Object> supplierInfos = new HashMap<String, Object>();
			supplierInfos.put("fxSupplierInfo", fxSupplierInfo);
			supplierInfos.put("fxSupplierParam", fxSupplierParam);
			supplierService.updateFXSupplierInfo(supplierInfos);
			/*List<Object> list = new ArrayList<Object>();
			list.add(fxSupplierInfo);
			list.add(fxSupplierInfo);
			supplierClientService.updateFXSupplierInfoList(list);
			supplierClientService.updateFXSupplierInfoObj(fxSupplierInfo,fxSupplierParam);*/
			FXOperationLogDto log = new FXOperationLogDto();
			log.setBizCode(fxSupplierInfo.getId().toString());
			log.setEventType("编辑");
			log.setOpDate(new Date());
			log.setType(FxPurchaseStateEnum.OPLOG_TYPE_1.getIndex());
			log.setUserId(userId);
			log.setUserName(userName);
			fxOperationLogService.saveOpLog(log);
			result.put("result", "0000");
			result.put("msg", "保存成功");
		} catch (Exception e) {
			result.put("result", "0001");
			result.put("msg", "保存失败");
			e.printStackTrace();
		}
		return result;
	}
}
