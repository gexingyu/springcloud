package com.ule.wholesale.fxpurchase.web.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="imageHandler")
public class ImageController {

	private Log logger = LogFactory.getLog(ImageController.class);
	
	/**
	 * 测试
	 * @param request
	 * @return
	 */
	@RequestMapping(value="getImage")
	public String getImage(HttpServletRequest request, HttpServletResponse response){
		String imgUrl = request.getParameter("imgUrl");
		logger.info("imgUrl="+imgUrl);
		BufferedInputStream bfi = null;
		BufferedOutputStream bfo = null;
		try{
			URL url = new URL(imgUrl);
			logger.info("url="+url);
			URLConnection con = url.openConnection();
			con.setConnectTimeout(5*1000);
			logger.info("con="+con);
			InputStream is = con.getInputStream();
			logger.info("is="+is);
			bfi = new BufferedInputStream(is);
			logger.info("bfi="+bfi);
			
			response.setContentType("image/*"); // 设置返回的文件类型
			OutputStream out = response.getOutputStream();
			bfo = new BufferedOutputStream(out);
			logger.info("bfo1="+bfo);
			
			int x =0;
			while((x = bfi.read())!=-1){
				bfo.write(x);
			}
			logger.info("bfo2="+bfo);
		}catch(Exception e){
			logger.error("error", e);
		}finally{
			try {
				if(bfi!=null){
					bfi.close();
				}
			} catch (IOException e) {
				logger.error("error", e);
			}
			try {
				if(bfo!=null){
					bfo.close();
				}
			} catch (IOException e) {
				logger.error("error", e);
			}
		}
		return null;
	}
	
}
